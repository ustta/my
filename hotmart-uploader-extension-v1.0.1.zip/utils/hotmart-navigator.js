/**
 * Utilitário para navegação na Hotmart
 * Fornece funções para interação com a plataforma Hotmart
 */

class HotmartNavigator {
  constructor(humanSim, shadowDOM) {
    this.humanSim = humanSim;
    this.shadowDOM = shadowDOM;
    this.config = {
      verificarSucessoUpload: true,
      timeoutDeteccaoPagina: 10000
    };
  }

  /**
   * Configura as opções do navegador
   * @param {Object} config - Objeto com configurações
   */
  configurar(config) {
    this.config = { ...this.config, ...config };
  }

  /**
   * Detecta a página atual da Hotmart
   * @returns {Promise<string>} - Nome da página detectada
   */
  async detectarPagina() {
    const url = window.location.href;

    // Verifica URLs para determinar a página
    if (url.includes('/area-de-membros')) {
      return 'area_membros';
    } else if (url.includes('/produto')) {
      return 'produto';
    } else if (url.includes('/checkout')) {
      return 'checkout';
    } else if (url.includes('/admin')) {
      return 'admin';
    } else if (url.includes('/dashboard')) {
      return 'dashboard';
    } else if (url.includes('/conteudo') || url.includes('/content')) {
      return 'conteudo';
    } else if (url.includes('/precificacao') || url.includes('/pricing')) {
      return 'precificacao';
    } else if (url.includes('/upload')) {
      return 'upload';
    } else {
      // Detecta por elementos na página
      try {
        // Aguarda carregamento mínimo da página
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Procura por elementos que identifiquem a página
        const titulo = document.title.toLowerCase();
        const textosPagina = Array.from(document.querySelectorAll('h1, h2, h3, div.header, div.title'))
          .map(el => el.textContent.toLowerCase())
          .join(' ');
        
        if (textosPagina.includes('upload') || textosPagina.includes('arquivo') || 
            textosPagina.includes('file') || titulo.includes('upload')) {
          return 'upload';
        } else if (textosPagina.includes('precificação') || textosPagina.includes('pricing') || 
                  textosPagina.includes('preço') || textosPagina.includes('price')) {
          return 'precificacao';
        } else if (textosPagina.includes('conteúdo') || textosPagina.includes('content') || 
                  textosPagina.includes('módulo') || textosPagina.includes('module')) {
          return 'conteudo';
        } else if (textosPagina.includes('dashboard') || textosPagina.includes('painel') || 
                  textosPagina.includes('estatística') || textosPagina.includes('stats')) {
          return 'dashboard';
        }
      } catch (e) {
        console.error('Erro ao detectar página por conteúdo:', e);
      }
      
      return 'desconhecida';
    }
  }

  /**
   * Executa a navegação baseada na página atual
   * @param {string} pagina - Nome da página atual
   * @param {Object} config - Configurações específicas para esta navegação
   * @returns {Promise<boolean>} - Se a navegação foi bem-sucedida
   */
  async navegarPagina(pagina, config = {}) {
    console.log(`Navegando na página: ${pagina}`);
    
    switch(pagina) {
      case 'upload':
        return await this.processarPaginaUpload(config);
      case 'precificacao':
        return await this.processarPaginaPrecificacao(config);
      case 'conteudo':
        return await this.processarPaginaConteudo(config);
      default:
        console.log(`Navegação para página "${pagina}" não implementada`);
        return false;
    }
  }

  /**
   * Processa a página de upload de arquivos
   * @param {Object} config - Configurações específicas para upload
   * @returns {Promise<boolean>} - Se o processamento foi bem-sucedido
   */
  async processarPaginaUpload(config = {}) {
    console.log('Processando página de upload');
    
    try {
      // Verifica se há arquivos prontos para upload
      const arquivosProntos = config.arquivos;
      
      // Procura pelo botão/área de upload
      const seletoresBotaoUpload = [
        'input[type="file"]',
        'input[accept*="image"], input[accept*="pdf"], input[accept*="video"]',
        'div[role="button"][data-testid*="upload"]',
        'div.upload-area, div.dropzone, div.file-input',
        'button:contains("Upload"), button:contains("Enviar arquivo"), button:contains("Escolher arquivo")'
      ];
      
      let botaoUpload = null;
      
      for (const seletor of seletoresBotaoUpload) {
        try {
          botaoUpload = await this.shadowDOM.aguardarElemento(
            seletor,
            document.body,
            5000,
            true
          );
          
          if (botaoUpload) {
            console.log(`Botão de upload encontrado: ${seletor}`);
            break;
          }
        } catch (e) {
          // Continua tentando outros seletores
        }
      }
      
      if (botaoUpload) {
        // Encontra o input de arquivo
        // Se o botão encontrado não é um input, procuramos por inputs relacionados
        let inputArquivo = botaoUpload;
        
        if (botaoUpload.tagName !== 'INPUT') {
          // Tenta encontrar o input de arquivo
          let inputBuscado = null;
          
          // Tenta primeiro encontrar filhos do botão
          inputBuscado = botaoUpload.querySelector('input[type="file"]');
          
          // Se não encontrar, busca globalmente, mas prioriza elementos próximos
          if (!inputBuscado) {
            const todosInputs = document.querySelectorAll('input[type="file"]');
            if (todosInputs.length > 0) {
              inputBuscado = todosInputs[0];
            }
          }
          
          if (inputBuscado) {
            inputArquivo = inputBuscado;
            console.log('Input de arquivo encontrado');
          } else {
            // Tenta injetar um input de arquivo temporário para simular a abertura da caixa de diálogo
            const tempInput = document.createElement('input');
            tempInput.type = 'file';
            tempInput.style.position = 'absolute';
            tempInput.style.top = '-1000px';
            tempInput.style.left = '-1000px';
            document.body.appendChild(tempInput);
            
            // Simula clique no botão
            await this.humanSim.clicar(botaoUpload);
            console.log('Clicou no botão de upload');
            
            // Guarda referência ao input temporário
            inputArquivo = tempInput;
            
            // Configuramos um timeout para remover o input temporário
            setTimeout(() => {
              document.body.removeChild(tempInput);
            }, 10000);
          }
        }
        
        if (inputArquivo) {
          // Vamos garantir que o input esteja visível momentaneamente para o FileReader
          const visibilityOriginal = inputArquivo.style.visibility;
          const displayOriginal = inputArquivo.style.display;
          
          inputArquivo.style.visibility = 'visible';
          inputArquivo.style.display = 'block';
          
          // Configura um timeout para restaurar a visibilidade original
          setTimeout(() => {
            inputArquivo.style.display = displayOriginal;
            inputArquivo.style.visibility = visibilityOriginal;
          }, 10000);
          
          // Se temos arquivos para upload, vamos usá-los
          if (arquivosProntos) {
            console.log('Preparando arquivos para upload automático');
            
            // Verifica se existem configurações específicas para o upload
            let modoLote = false;
            let limiteArquivos = 50;
            
            // Obtém configurações do armazenamento
            await new Promise((resolve) => {
              chrome.storage.local.get('configAutomacao', (result) => {
                if (result.configAutomacao) {
                  modoLote = result.configAutomacao.modoLote !== undefined ? 
                             result.configAutomacao.modoLote : false;
                  
                  limiteArquivos = result.configAutomacao.limiteArquivos !== undefined ? 
                                  result.configAutomacao.limiteArquivos : 50;
                }
                resolve();
              });
            });
            
            console.log(`Modo de lote: ${modoLote}, Limite de arquivos por upload: ${limiteArquivos}`);
            
            // Determina qual arquivo usar com base no contexto
            // (capa, conteúdo principal ou arquivos adicionais)
            let arquivosParaUpload = [];
            let tipoUpload = 'desconhecido';
            
            // Tenta identificar qual tipo de upload estamos fazendo baseado na interface/contexto
            const textosPagina = Array.from(document.querySelectorAll('h1, h2, h3, p, label, div, span'))
              .map(el => el.textContent.toLowerCase())
              .join(' ');
            
            const isUploadCapa = textosPagina.includes('capa') || 
                                textosPagina.includes('imagem') || 
                                textosPagina.includes('cover') || 
                                textosPagina.includes('image');
                                
            const isUploadPrincipal = textosPagina.includes('principal') || 
                                      textosPagina.includes('conteúdo') || 
                                      textosPagina.includes('main') || 
                                      textosPagina.includes('content');
            
            const isMultiUpload = textosPagina.includes('múltiplos') || 
                                 textosPagina.includes('multiple') || 
                                 textosPagina.includes('batch') || 
                                 textosPagina.includes('lote') ||
                                 inputArquivo.multiple;
                                 
            if (isUploadCapa && arquivosProntos.capa) {
              arquivosParaUpload = [arquivosProntos.capa];
              tipoUpload = 'capa';
            } else if (isUploadPrincipal && arquivosProntos.conteudo) {
              arquivosParaUpload = [arquivosProntos.conteudo];
              tipoUpload = 'conteúdo principal';
            } else if (isMultiUpload && arquivosProntos.adicionais && arquivosProntos.adicionais.length > 0) {
              arquivosParaUpload = arquivosProntos.adicionais;
              tipoUpload = 'múltiplos arquivos';
            } else if (arquivosProntos.conteudo) {
              arquivosParaUpload = [arquivosProntos.conteudo];
              tipoUpload = 'conteúdo';
            } else if (arquivosProntos.capa) {
              arquivosParaUpload = [arquivosProntos.capa];
              tipoUpload = 'capa';
            } else if (arquivosProntos.adicionais && arquivosProntos.adicionais.length > 0) {
              // Se não conseguimos determinar o tipo mas temos arquivos adicionais
              arquivosParaUpload = [arquivosProntos.adicionais[0]]; // Usamos o primeiro
              tipoUpload = 'arquivo individual';
            }
            
            if (arquivosParaUpload.length > 0) {
              if (modoLote && isMultiUpload && arquivosParaUpload.length > limiteArquivos) {
                console.log(`Iniciando upload em lote de ${arquivosParaUpload.length} arquivos em grupos de ${limiteArquivos}`);
                
                // Divide os arquivos em lotes
                const totalLotes = Math.ceil(arquivosParaUpload.length / limiteArquivos);
                
                for (let loteAtual = 0; loteAtual < totalLotes; loteAtual++) {
                  // Calcula o intervalo do lote atual
                  const inicio = loteAtual * limiteArquivos;
                  const fim = Math.min(inicio + limiteArquivos, arquivosParaUpload.length);
                  const arquivosLote = arquivosParaUpload.slice(inicio, fim);
                  
                  console.log(`Processando lote ${loteAtual + 1}/${totalLotes} com ${arquivosLote.length} arquivos`);
                  
                  // Para cada lote, cria um novo DataTransfer
                  const dataTransfer = new DataTransfer();
                  
                  // Converte e adiciona cada arquivo ao DataTransfer
                  for (const arquivoInfo of arquivosLote) {
                    try {
                      // Converte o dataUrl para Blob
                      const response = await fetch(arquivoInfo.dataUrl);
                      const blob = await response.blob();
                      
                      // Cria um File a partir do Blob
                      const file = new File([blob], arquivoInfo.name, { type: arquivoInfo.type });
                      
                      // Adiciona ao DataTransfer
                      dataTransfer.items.add(file);
                    } catch (e) {
                      console.error(`Erro ao processar arquivo ${arquivoInfo.name}:`, e);
                    }
                  }
                  
                  // Simula comportamento humano: clica no input antes
                  await this.humanSim.clicar(inputArquivo);
                  await this.humanSim.delay(500, 1000);
                  
                  // Define os arquivos no input
                  inputArquivo.files = dataTransfer.files;
                  
                  // Dispara eventos necessários para que o site detecte a mudança
                  inputArquivo.dispatchEvent(new Event('change', { bubbles: true }));
                  
                  console.log(`Lote ${loteAtual + 1} definido no input (${dataTransfer.files.length} arquivos), aguardando processamento...`);
                  await this.humanSim.delay(1000, 2000);
                  
                  // Procura e clica no botão de confirmar
                  const confirmouUpload = await this.confirmarUploadEAguardar();
                  
                  // Se não for o último lote, vamos aguardar mais e depois procurar o botão de adicionar mais arquivos
                  if (loteAtual < totalLotes - 1 && confirmouUpload) {
                    await this.humanSim.delay(3000, 6000);
                    
                    // Tenta encontrar um botão de adicionar mais arquivos
                    console.log("Buscando botão para adicionar mais arquivos...");
                    const botaoAdicionarMais = await this.encontrarBotaoAdicionarMais();
                    
                    if (botaoAdicionarMais) {
                      await this.humanSim.clicar(botaoAdicionarMais);
                      await this.humanSim.delay(1500, 3000);
                    } else {
                      console.log("Não foi possível encontrar botão para adicionar mais arquivos. Interrompendo upload em lote.");
                      break;
                    }
                  }
                }
              } else {
                // Upload normal (não em lote)
                console.log(`Realizando upload de ${tipoUpload}: ${arquivosParaUpload.length} arquivo(s)`);
                
                // Cria um DataTransfer para simular a seleção do arquivo
                const dataTransfer = new DataTransfer();
                
                // Processa todos os arquivos (seja um único ou múltiplos)
                for (const arquivoInfo of arquivosParaUpload) {
                  try {
                    // Converte o dataUrl para Blob
                    const response = await fetch(arquivoInfo.dataUrl);
                    const blob = await response.blob();
                    
                    // Cria um File a partir do Blob
                    const file = new File([blob], arquivoInfo.name, { type: arquivoInfo.type });
                    
                    // Adiciona ao DataTransfer
                    dataTransfer.items.add(file);
                  } catch (e) {
                    console.error(`Erro ao processar arquivo ${arquivoInfo.name}:`, e);
                  }
                }
                
                // Simula comportamento humano: clica no input antes
                await this.humanSim.clicar(inputArquivo);
                await this.humanSim.delay(500, 1000);
                
                // Define o arquivo no input
                inputArquivo.files = dataTransfer.files;
                
                // Dispara eventos necessários para que o site detecte a mudança
                inputArquivo.dispatchEvent(new Event('change', { bubbles: true }));
                
                console.log('Arquivo(s) definido(s) no input, aguardando processamento...');
                await this.humanSim.delay(1000, 2000);
                
                // Confirma o upload e aguarda o resultado
                await this.confirmarUploadEAguardar();
              }
            } else {
              // Não encontramos arquivos compatíveis para esta página
              await this.cancelarUploadVazio();
            }
          } else {
            // Sem arquivos pré-configurados, o usuário precisa selecionar manualmente
            console.log('Nenhum arquivo pré-configurado, precisamos de interação manual');
            
            // Simula comportamento humano
            await this.humanSim.clicar(inputArquivo);
            console.log('Clicou no input de arquivo');
            
            // Alerta o usuário para selecionar o arquivo manualmente
            alert('Por favor, selecione o arquivo para upload na caixa de diálogo que se abrirá. A automação continuará após a seleção.');
            
            // Aguarda um tempo para o usuário selecionar o arquivo
            await this.humanSim.delay(10000, 15000);
            
            // Confirma o upload e aguarda o resultado
            await this.confirmarUploadEAguardar();
          }
        } else {
          console.error('Input de arquivo não encontrado');
          return false;
        }
      } else {
        console.error('Botão de upload não encontrado');
        return false;
      }
      
      return true;
    } catch (erro) {
      console.error('Erro durante o upload de arquivos:', erro);
      return false;
    }
  }
  
  /**
   * Procura e clica no botão de confirmar upload, aguardando o resultado
   * @returns {Promise<boolean>} - Se o upload foi confirmado com sucesso
   */
  async confirmarUploadEAguardar() {
    // Procura pelo botão de confirmar upload
    const seletoresBotaoConfirmar = [
      'button:contains("Confirmar")',
      'button:contains("Confirm")',
      'button:contains("Enviar")',
      'button:contains("Submit")',
      'button:contains("Upload")',
      'button:contains("Salvar")',
      'button:contains("Save")',
      'button[type="submit"]',
      'button.primary',
      'button.btn-primary',
      'button.confirm-button'
    ];
    
    let botaoConfirmar = null;
    for (const seletor of seletoresBotaoConfirmar) {
      try {
        botaoConfirmar = await this.shadowDOM.aguardarElemento(
          seletor,
          document.body,
          3000,
          true
        );
        
        if (botaoConfirmar) {
          console.log(`Botão de confirmar encontrado com seletor: ${seletor}`);
          break;
        }
      } catch (e) {
        // Continua tentando outros seletores
      }
    }
    
    if (botaoConfirmar) {
      // Comportamento humano: espera um pouco antes de clicar no confirmar
      await this.humanSim.delay(1000, 2000);
      
      await this.humanSim.clicar(botaoConfirmar);
      console.log('Clicou no botão de confirmar upload');
      
      // Verifica se o upload foi bem-sucedido
      if (this.config.verificarSucessoUpload) {
        await this.verificarSucessoUpload();
      }
      
      return true;
    } else {
      console.log('Botão de confirmar não encontrado, mas o arquivo foi selecionado');
      // Em alguns casos o upload pode ser automático após a seleção
      return false;
    }
  }
  
  /**
   * Encontra um botão para adicionar mais arquivos após um upload
   * @returns {Promise<Element|null>} - Elemento do botão encontrado ou null
   */
  async encontrarBotaoAdicionarMais() {
    const seletoresBotaoAdicionar = [
      'button:contains("Adicionar mais")',
      'button:contains("Add more")',
      'button:contains("Novo upload")',
      'button:contains("Novo arquivo")',
      'button:contains("Adicionar arquivo")',
      'button:contains("Upload")',
      'button:contains("Adicionar")',
      'button:contains("Add")',
      'a:contains("Adicionar")',
      'a:contains("Upload")',
      '[data-testid*="add-more"]',
      '[data-testid*="upload-button"]'
    ];
    
    let botaoAdicionar = null;
    
    for (const seletor of seletoresBotaoAdicionar) {
      try {
        botaoAdicionar = await this.shadowDOM.aguardarElemento(
          seletor,
          document.body,
          2000,
          true
        );
        
        if (botaoAdicionar) {
          console.log(`Botão para adicionar mais arquivos encontrado: ${seletor}`);
          return botaoAdicionar;
        }
      } catch (e) {
        // Continua tentando outros seletores
      }
    }
    
    return null;
  }
  
  /**
   * Processa situação onde não há arquivos compatíveis para upload
   */
  async cancelarUploadVazio() {
    console.log('Nenhum arquivo compatível encontrado para este upload');
    // Simula comportamento humano cancelando a operação
    await this.humanSim.delay(1000, 2000);
    
    // Tenta encontrar botão de cancelar/fechar
    const botaoCancelar = await this.shadowDOM.encontrarElemento(
      'button:contains("Cancelar"), button:contains("Cancel"), button:contains("Fechar"), button:contains("Close"), button.close-button',
      document.body,
      true
    );
    
    if (botaoCancelar) {
      await this.humanSim.clicar(botaoCancelar);
      console.log('Operação cancelada, nenhum arquivo compatível');
    }
  }
  
  /**
   * Verifica se o upload foi bem-sucedido
   * @returns {Promise<boolean>} - Se o upload foi bem-sucedido
   */
  async verificarSucessoUpload() {
    console.log('Verificando se o upload foi bem-sucedido...');
    
    // Aguarda um tempo para o upload processar
    await this.humanSim.delay(3000, 5000);
    
    // Procura por elementos que indiquem sucesso ou erro
    const elementosSucesso = await this.shadowDOM.encontrarTodosElementos(
      'div:contains("sucesso"), div:contains("success"), div:contains("concluído"), div:contains("completed"), div.success, div.upload-success',
      document.body,
      true
    );
    
    const elementosErro = await this.shadowDOM.encontrarTodosElementos(
      'div:contains("erro"), div:contains("error"), div:contains("falha"), div:contains("failed"), div.error, div.upload-error',
      document.body,
      true
    );
    
    if (elementosSucesso.length > 0) {
      console.log('Upload concluído com sucesso!');
      return true;
    } else if (elementosErro.length > 0) {
      console.log('Erro no upload. Falha detectada.');
      return false;
    } else {
      // Não encontramos elementos explícitos, vamos assumir que foi bem-sucedido
      console.log('Sem confirmação explícita, assumindo que o upload foi bem-sucedido');
      return true;
    }
  }
  
  /**
   * Processa a página de precificação
   * @param {Object} config - Configurações específicas para precificação
   * @returns {Promise<boolean>} - Se o processamento foi bem-sucedido
   */
  async processarPaginaPrecificacao(config = {}) {
    console.log('Processando página de precificação');
    
    try {
      // Implementação para manipular a página de precificação
      // Esta é uma seção complexa da Hotmart que frequentemente usa Shadow DOM
      
      // Detecção de elementos dentro do Shadow DOM
      const campoPreco = await this.shadowDOM.aguardarElemento(
        'input[type="number"], input[placeholder*="preço"], input[placeholder*="valor"], input[placeholder*="price"]',
        document.body,
        10000,
        true
      );
      
      if (campoPreco) {
        console.log('Campo de preço encontrado');
        
        // Define o preço (se fornecido na configuração)
        if (config.preco) {
          await this.humanSim.clicar(campoPreco);
          await this.humanSim.delay(500, 1000);
          
          // Limpa o campo
          campoPreco.value = '';
          campoPreco.dispatchEvent(new Event('input', { bubbles: true }));
          await this.humanSim.delay(300, 600);
          
          // Digita o novo valor
          await this.humanSim.digitar(campoPreco, config.preco.toString());
          console.log(`Definiu preço: ${config.preco}`);
        }
        
        // Procura e clica no botão para salvar/avançar
        const botaoSalvar = await this.shadowDOM.aguardarElemento(
          'button:contains("Salvar"), button:contains("Save"), button:contains("Avançar"), button:contains("Next"), button[type="submit"]',
          document.body,
          5000,
          true
        );
        
        if (botaoSalvar) {
          await this.humanSim.delay(1000, 2000);
          await this.humanSim.clicar(botaoSalvar);
          console.log('Clicou no botão de salvar/avançar');
          
          // Aguarda confirmação
          await this.humanSim.delay(2000, 3000);
          return true;
        } else {
          console.log('Botão de salvar não encontrado');
        }
      } else {
        console.log('Campo de preço não encontrado');
      }
      
      return false;
    } catch (erro) {
      console.error('Erro ao processar página de precificação:', erro);
      return false;
    }
  }
  
  /**
   * Processa a página de conteúdo
   * @param {Object} config - Configurações específicas para conteúdo
   * @returns {Promise<boolean>} - Se o processamento foi bem-sucedido
   */
  async processarPaginaConteudo(config = {}) {
    console.log('Processando página de conteúdo');
    
    try {
      // Implementação para manipular a página de conteúdo
      // Esta seção geralmente envolve criação de módulos e lições
      
      // Verifica se deve criar um novo módulo
      if (config.criarModulo) {
        // Procura o botão de adicionar módulo
        const botaoAdicionarModulo = await this.shadowDOM.aguardarElemento(
          'button:contains("Adicionar módulo"), button:contains("Add module"), button:contains("Novo módulo"), button[data-testid*="module"]',
          document.body,
          5000,
          true
        );
        
        if (botaoAdicionarModulo) {
          await this.humanSim.clicar(botaoAdicionarModulo);
          console.log('Clicou no botão para adicionar módulo');
          await this.humanSim.delay(1000, 2000);
          
          // Procura campo para nome do módulo
          const campoNomeModulo = await this.shadowDOM.aguardarElemento(
            'input[placeholder*="nome"], input[placeholder*="título"], input[placeholder*="name"], input[placeholder*="title"]',
            document.body,
            5000,
            true
          );
          
          if (campoNomeModulo && config.nomeModulo) {
            await this.humanSim.clicar(campoNomeModulo);
            await this.humanSim.delay(300, 600);
            await this.humanSim.digitar(campoNomeModulo, config.nomeModulo);
            console.log(`Definiu nome do módulo: ${config.nomeModulo}`);
            
            // Procura botão para confirmar/salvar
            const botaoSalvarModulo = await this.shadowDOM.aguardarElemento(
              'button:contains("Salvar"), button:contains("Save"), button:contains("Confirmar"), button:contains("Confirm"), button[type="submit"]',
              document.body,
              5000,
              true
            );
            
            if (botaoSalvarModulo) {
              await this.humanSim.delay(500, 1000);
              await this.humanSim.clicar(botaoSalvarModulo);
              console.log('Salvou o novo módulo');
              await this.humanSim.delay(2000, 3000);
            }
          }
        }
      }
      
      // Implementação para outras operações na página de conteúdo
      
      return true;
    } catch (erro) {
      console.error('Erro ao processar página de conteúdo:', erro);
      return false;
    }
  }
}

// Exportação para uso em outros arquivos
if (typeof module !== 'undefined') {
  module.exports = HotmartNavigator;
}