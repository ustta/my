/**
 * Utilitário para manipulação de Shadow DOM
 * Fornece funções para acessar e manipular elementos dentro do Shadow DOM
 */

const ShadowDOMUtils = {
  /**
   * Encontra um elemento dentro do Shadow DOM
   * @param {string} selector - Seletor CSS para encontrar o elemento
   * @param {Element} root - Elemento raiz para iniciar a busca (opcional)
   * @param {boolean} recursivo - Se deve buscar recursivamente em todos os shadow roots
   * @returns {Element|null} - O elemento encontrado ou null
   */
  encontrarElemento(selector, root = document.body, recursivo = true) {
    // Verifica se o elemento está no DOM regular
    let elemento = root.querySelector(selector);
    if (elemento) return elemento;
    
    // Busca entre os elementos com shadow root
    const elementosComShadow = root.querySelectorAll('*');
    for (const el of elementosComShadow) {
      if (el.shadowRoot) {
        // Tenta encontrar no shadow root atual
        elemento = el.shadowRoot.querySelector(selector);
        if (elemento) return elemento;
        
        // Busca recursivamente se necessário
        if (recursivo) {
          elemento = this.encontrarElemento(selector, el.shadowRoot, true);
          if (elemento) return elemento;
        }
      }
    }
    
    return null;
  },
  
  /**
   * Encontra todos os elementos que correspondem ao seletor no Shadow DOM
   * @param {string} selector - Seletor CSS para encontrar os elementos
   * @param {Element} root - Elemento raiz para iniciar a busca (opcional)
   * @param {boolean} recursivo - Se deve buscar recursivamente em todos os shadow roots
   * @returns {Element[]} - Array com os elementos encontrados
   */
  encontrarTodosElementos(selector, root = document.body, recursivo = true) {
    let elementos = [];
    
    // Adiciona elementos do DOM regular
    elementos = [...root.querySelectorAll(selector)];
    
    // Busca entre os elementos com shadow root
    const elementosComShadow = root.querySelectorAll('*');
    for (const el of elementosComShadow) {
      if (el.shadowRoot) {
        // Adiciona os elementos do shadow root atual
        elementos = [...elementos, ...el.shadowRoot.querySelectorAll(selector)];
        
        // Busca recursivamente se necessário
        if (recursivo) {
          elementos = [...elementos, ...this.encontrarTodosElementos(selector, el.shadowRoot, true)];
        }
      }
    }
    
    return elementos;
  },
  
  /**
   * Encontra elemento no Shadow DOM esperando que ele esteja disponível
   * @param {string} selector - Seletor CSS para encontrar o elemento
   * @param {Element} root - Elemento raiz para iniciar a busca (opcional)
   * @param {number} timeout - Tempo máximo de espera em ms (padrão: 10000ms)
   * @param {boolean} recursivo - Se deve buscar recursivamente em todos os shadow roots
   * @returns {Promise<Element>} - Promessa que resolve para o elemento encontrado
   */
  async aguardarElemento(selector, root = document.body, timeout = 10000, recursivo = true) {
    return new Promise((resolve, reject) => {
      // Verifica se o elemento já existe
      const elementoExistente = this.encontrarElemento(selector, root, recursivo);
      if (elementoExistente) {
        return resolve(elementoExistente);
      }
      
      // Configura temporizador para timeout
      const timeoutId = setTimeout(() => {
        observer.disconnect();
        reject(new Error(`Timeout ao aguardar pelo elemento: ${selector}`));
      }, timeout);
      
      // Configura MutationObserver para detectar mudanças no DOM
      const observer = new MutationObserver((mutations) => {
        const elemento = this.encontrarElemento(selector, root, recursivo);
        if (elemento) {
          clearTimeout(timeoutId);
          observer.disconnect();
          resolve(elemento);
        }
      });
      
      // Inicia observação no DOM e em todos os shadow roots
      observer.observe(root, {
        childList: true,
        subtree: true
      });
      
      // Observa também mudanças em shadow roots existentes
      const shadowRoots = [];
      const coletarShadowRoots = (element) => {
        if (element.shadowRoot) {
          shadowRoots.push(element.shadowRoot);
          observer.observe(element.shadowRoot, {
            childList: true,
            subtree: true
          });
        }
        
        Array.from(element.children).forEach(coletarShadowRoots);
      };
      
      coletarShadowRoots(root);
    });
  },
  
  /**
   * Encontra o shadow root mais profundo de um elemento
   * @param {Element} elemento - Elemento para encontrar o shadow root mais profundo
   * @returns {ShadowRoot|null} - O shadow root mais profundo ou null
   */
  encontrarShadowRootMaisProfundo(elemento) {
    if (!elemento) return null;
    
    // Se o elemento tem um shadow root, continua a busca nele
    if (elemento.shadowRoot) {
      // Pega todos os elementos com potencial shadow root
      const filhos = Array.from(elemento.shadowRoot.querySelectorAll('*'));
      
      // Procura o primeiro filho com shadow root
      for (const filho of filhos) {
        const shadowProfundo = this.encontrarShadowRootMaisProfundo(filho);
        if (shadowProfundo) return shadowProfundo;
      }
      
      // Se nenhum filho tem shadow root, retorna o shadow root atual
      return elemento.shadowRoot;
    }
    
    return null;
  },
  
  /**
   * Cria um seletor CSS único para um elemento
   * @param {Element} elemento - Elemento para criar o seletor
   * @returns {string} - Seletor CSS único
   */
  criarSeletorUnico(elemento) {
    if (!elemento || elemento === document || elemento === document.documentElement) {
      return '';
    }
    
    let seletor = elemento.tagName.toLowerCase();
    
    // Adiciona ID se disponível
    if (elemento.id) {
      return `${seletor}#${elemento.id}`;
    }
    
    // Adiciona classes se disponíveis
    if (elemento.className && typeof elemento.className === 'string') {
      const classes = elemento.className.trim().split(/\s+/);
      if (classes.length > 0) {
        seletor += '.' + classes.join('.');
      }
    }
    
    // Adiciona atributos que ajudam a identificar o elemento
    ['name', 'data-testid', 'aria-label'].forEach(attr => {
      if (elemento.hasAttribute(attr)) {
        seletor += `[${attr}="${elemento.getAttribute(attr)}"]`;
      }
    });
    
    // Adiciona posição entre irmãos se necessário
    const parent = elemento.parentNode;
    if (parent && parent.children.length > 1) {
      const siblings = Array.from(parent.children);
      const index = siblings.indexOf(elemento);
      if (index !== -1) {
        seletor += `:nth-child(${index + 1})`;
      }
    }
    
    return seletor;
  },
  
  /**
   * Mapeia o caminho de shadow roots para um elemento
   * @param {Element} elemento - Elemento para mapear o caminho
   * @returns {Array} - Array com o caminho de hosts e seletores
   */
  mapearCaminhoShadow(elemento) {
    const caminho = [];
    let elementoAtual = elemento;
    let root = document;
    
    while (elementoAtual && elementoAtual !== document.documentElement) {
      // Verifica se o elemento está em um shadow root
      const hostShadow = elementoAtual.getRootNode()?.host;
      
      if (hostShadow) {
        // Adiciona o host e o seletor do elemento dentro do shadow root
        caminho.unshift({
          host: this.criarSeletorUnico(hostShadow),
          seletorInterno: this.criarSeletorUnico(elementoAtual)
        });
        
        // Move para o host do shadow root
        elementoAtual = hostShadow;
      } else {
        // Se não está em shadow root, move para o pai
        elementoAtual = elementoAtual.parentElement;
      }
    }
    
    return caminho;
  },
  
  /**
   * Acessa um elemento usando um caminho de shadow roots
   * @param {Array} caminho - Caminho de shadow roots obtido com mapearCaminhoShadow
   * @returns {Element|null} - O elemento encontrado ou null
   */
  acessarPorCaminhoShadow(caminho) {
    let elementoAtual = document.documentElement;
    
    for (const passo of caminho) {
      // Encontra o host do shadow root
      const host = document.querySelector(passo.host);
      if (!host || !host.shadowRoot) return null;
      
      // Encontra o elemento dentro do shadow root
      elementoAtual = host.shadowRoot.querySelector(passo.seletorInterno);
      if (!elementoAtual) return null;
    }
    
    return elementoAtual;
  }
};

export default ShadowDOMUtils;
