/**
 * Utilitário para simulação de interações humanas
 * Fornece funções para simular cliques, movimentos do mouse e digitação
 * com comportamento natural para evitar detecção de automação
 */

const HumanSimulation = {
  // Configurações padrão
  config: {
    delayMinimo: 800,
    delayMaximo: 2000,
    movimentoMouseAtivado: true,
    digitacaoNatural: true
  },
  
  /**
   * Configura as opções de simulação
   * @param {Object} options - Opções de configuração
   */
  configurar(options) {
    this.config = { ...this.config, ...options };
  },
  
  /**
   * Gera um delay aleatório para simular comportamento humano
   * @param {number} min - Tempo mínimo em ms (opcional)
   * @param {number} max - Tempo máximo em ms (opcional)
   * @returns {Promise} - Promessa que resolve após o delay
   */
  async delay(min = null, max = null) {
    const minDelay = min || this.config.delayMinimo;
    const maxDelay = max || this.config.delayMaximo;
    
    // Adiciona uma variação não-linear para parecer mais humano
    // Ocasionalmente adiciona pausas mais longas (como um humano pensando)
    let delay;
    
    if (Math.random() < 0.15) {
      // Pausa longa ocasional (15% de chance)
      delay = Math.floor(Math.random() * (maxDelay * 1.5 - maxDelay + 1)) + maxDelay;
    } else {
      // Distribuição não uniforme para parecer mais natural
      const randomBase = Math.random();
      const skewedRandom = Math.pow(randomBase, 0.7); // Faz com que delays curtos sejam mais frequentes
      delay = Math.floor(skewedRandom * (maxDelay - minDelay + 1)) + minDelay;
    }
    
    return new Promise(resolve => setTimeout(resolve, delay));
  },
  
  /**
   * Simula movimento de mouse natural para um elemento
   * @param {Element} elemento - Elemento alvo para o movimento
   * @returns {Promise} - Promessa que resolve após a simulação
   */
  async moverMousePara(elemento) {
    if (!elemento || !this.config.movimentoMouseAtivado) return;
    
    // Obtém a posição do elemento
    const rect = elemento.getBoundingClientRect();
    
    // Não clica exatamente no centro, mas em uma posição aleatória dentro do elemento
    // Os sistemas anti-bot detectam cliques exatos no centro como suspeitos
    const offsetX = (Math.random() * 0.6 + 0.2) * rect.width; // Entre 20% e 80% da largura
    const offsetY = (Math.random() * 0.6 + 0.2) * rect.height; // Entre 20% e 80% da altura
    
    const targetX = rect.left + offsetX + window.scrollX;
    const targetY = rect.top + offsetY + window.scrollY;
    
    // Obtém a posição atual do mouse, ou uma posição aleatória na tela
    // para simular que o mouse vem de um lugar aleatório
    const randomStartPosition = Math.random() < 0.7; // 70% de chance de usar posição aleatória
    
    let startX, startY;
    if (randomStartPosition) {
      // Posição aleatória nas bordas da tela, mais realista que vir do centro
      if (Math.random() < 0.5) {
        // Começa de um dos lados
        startX = Math.random() < 0.5 ? 10 : window.innerWidth - 10;
        startY = Math.random() * window.innerHeight;
      } else {
        // Começa de cima ou de baixo
        startX = Math.random() * window.innerWidth;
        startY = Math.random() < 0.5 ? 10 : window.innerHeight - 10;
      }
    } else {
      // Centro da tela (menos frequente)
      startX = window.innerWidth / 2;
      startY = window.innerHeight / 2;
    }
    
    // Calcula a distância total para determinar o número de passos
    const distancia = Math.sqrt(Math.pow(targetX - startX, 2) + Math.pow(targetY - startY, 2));
    // Número de passos proporcional à distância (movimento mais natural)
    const passos = Math.floor(5 + distancia / 30);
    
    // Cria pontos de controle para uma curva de Bezier mais natural
    // Humanos raramente movem o mouse em linha reta
    const controlX1 = startX + (targetX - startX) * (Math.random() * 0.3 + 0.1);
    const controlY1 = startY + (targetY - startY) * (Math.random() * 0.3 + 0.6);
    const controlX2 = startX + (targetX - startX) * (Math.random() * 0.3 + 0.6);
    const controlY2 = startY + (targetY - startY) * (Math.random() * 0.3 + 0.1);
    
    // Simula o movimento do mouse em passos
    for (let i = 0; i <= passos; i++) {
      // Progresso atual (0 a 1)
      const t = i / passos;
      
      // Aplica a curva de Bezier cúbica para trajetória natural
      const bezierX = this.bezierCubico(t, startX, controlX1, controlX2, targetX);
      const bezierY = this.bezierCubico(t, startY, controlY1, controlY2, targetY);
      
      // Adiciona um pequeno desvio aleatório que diminui conforme se aproxima do alvo
      // (simulando a maior precisão quando se aproxima do objetivo)
      const desvioFator = 1 - Math.min(1, t * 2); // Diminui gradualmente até zero
      const desvioMax = 4 * desvioFator;
      const desvioX = (Math.random() * 2 - 1) * desvioMax;
      const desvioY = (Math.random() * 2 - 1) * desvioMax;
      
      const novoX = bezierX + desvioX;
      const novoY = bezierY + desvioY;
      
      // Cria e dispara o evento de movimento do mouse
      const mouseEvent = new MouseEvent('mousemove', {
        clientX: novoX,
        clientY: novoY,
        bubbles: true,
        cancelable: true,
        view: window,
        movementX: novoX - (i > 0 ? bezierX : startX), // Adiciona movementX/Y para maior realismo
        movementY: novoY - (i > 0 ? bezierY : startY)
      });
      
      // Dispara o evento no elemento correto
      const elementoAlvo = document.elementFromPoint(novoX, novoY) || document.body;
      elementoAlvo.dispatchEvent(mouseEvent);
      
      // Ocasionalmente adiciona uma pequena pausa (como se o usuário estivesse hesitando)
      if (Math.random() < 0.1) {
        await this.delay(30, 150);
      } else {
        // Velocidade variável do movimento (mais lento no início e no final)
        const velocidade = this.mouseCurveSpeed(t);
        await this.delay(velocidade * 8, velocidade * 15);
      }
    }
    
    // Pausa natural antes de ações após mover o mouse
    await this.delay(50, 200);
  },
  
  /**
   * Calcula a velocidade do mouse baseada na curva de aceleração/desaceleração
   * @param {number} t - Progresso (0-1)
   * @returns {number} - Fator de velocidade (menor = mais rápido)
   */
  mouseCurveSpeed(t) {
    // Mais lento no início e no final do movimento (aceleração e desaceleração)
    return 10 + 15 * (1 - Math.sin(t * Math.PI));
  },
  
  /**
   * Implementação de curva Bezier cúbica para movimento de mouse
   * @param {number} t - Valor do tempo (0-1)
   * @param {number} p0 - Ponto inicial
   * @param {number} p1 - Primeiro ponto de controle
   * @param {number} p2 - Segundo ponto de controle
   * @param {number} p3 - Ponto final
   * @returns {number} - Valor interpolado
   */
  bezierCubico(t, p0, p1, p2, p3) {
    const cX = 3 * (p1 - p0);
    const bX = 3 * (p2 - p1) - cX;
    const aX = p3 - p0 - cX - bX;
    
    return aX * Math.pow(t, 3) + bX * Math.pow(t, 2) + cX * t + p0;
  },
  
  /**
   * Função de suavização para movimento natural
   * @param {number} t - Valor de progresso (0-1)
   * @returns {number} - Valor suavizado
   */
  easeInOutQuad(t) {
    return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
  },
  
  /**
   * Simula um clique humano em um elemento
   * @param {Element} elemento - Elemento para clicar
   * @param {boolean} ignorarMovimento - Se deve ignorar o movimento do mouse
   * @returns {Promise} - Promessa que resolve após o clique
   */
  async clicar(elemento, ignorarMovimento = false) {
    if (!elemento) throw new Error('Elemento não encontrado para clicar');
    
    // Rola a página para o elemento, se necessário
    this.rolarParaElemento(elemento);
    await this.delay(300, 700);
    
    // Simula movimento do mouse para o elemento
    if (!ignorarMovimento && this.config.movimentoMouseAtivado) {
      await this.moverMousePara(elemento);
    }
    
    // Obtém a posição do elemento
    const rect = elemento.getBoundingClientRect();
    
    // Não clica exatamente no centro, mas em uma posição aleatória dentro do elemento
    // Os sistemas anti-bot detectam cliques exatos no centro como suspeitos
    const offsetX = (Math.random() * 0.6 + 0.2) * rect.width; // Entre 20% e 80% da largura
    const offsetY = (Math.random() * 0.6 + 0.2) * rect.height; // Entre 20% e 80% da altura
    
    const x = rect.left + offsetX;
    const y = rect.top + offsetY;
    
    // Sequência natural de eventos do mouse com tempos variáveis entre eles
    // Um humano real não gera eventos mousedown/mouseup/click instantaneamente
    
    // 1. Evento mouseenter (opcional, acontece quando o mouse entra no elemento)
    if (Math.random() < 0.8) { // 80% de chance de disparar
      const mouseEnterEvent = new MouseEvent('mouseenter', {
        view: window,
        bubbles: true,
        cancelable: true,
        clientX: x,
        clientY: y
      });
      elemento.dispatchEvent(mouseEnterEvent);
      
      // Pequena pausa antes do hover
      await this.delay(10, 30);
    }
    
    // 2. Evento mouseover (hover)
    const mouseOverEvent = new MouseEvent('mouseover', {
      view: window,
      bubbles: true,
      cancelable: true,
      clientX: x,
      clientY: y
    });
    elemento.dispatchEvent(mouseOverEvent);
    
    // Pequeno delay antes de pressionar o botão
    await this.delay(20, 100);
    
    // 3. Evento mousedown (pressionar o botão do mouse)
    const mouseDownEvent = new MouseEvent('mousedown', {
      view: window,
      bubbles: true,
      cancelable: true,
      clientX: x,
      clientY: y,
      button: 0, // Botão esquerdo
      buttons: 1
    });
    elemento.dispatchEvent(mouseDownEvent);
    
    // Tempo variável mantendo o botão pressionado (humanos não clicam instantaneamente)
    // Cliques muito rápidos são suspeitos para sistemas anti-bot
    const tempoClique = Math.random() < 0.8
      ? Math.floor(Math.random() * 120) + 30 // Clique normal (80% de chance)
      : Math.floor(Math.random() * 350) + 150; // Clique mais demorado (20% de chance)
    
    await this.delay(tempoClique, tempoClique + 20);
    
    // 4. Evento mouseup (soltar o botão do mouse)
    const mouseUpEvent = new MouseEvent('mouseup', {
      view: window,
      bubbles: true,
      cancelable: true,
      clientX: x,
      clientY: y,
      button: 0,
      buttons: 0
    });
    elemento.dispatchEvent(mouseUpEvent);
    
    // Pequeno delay entre soltar o botão e o evento de clique
    await this.delay(5, 15);
    
    // 5. Evento click (o clique em si)
    const clickEvent = new MouseEvent('click', {
      view: window,
      bubbles: true,
      cancelable: true,
      clientX: x,
      clientY: y,
      button: 0,
      buttons: 0
    });
    elemento.dispatchEvent(clickEvent);
    
    // Ocasionalmente adiciona um pequeno movimento do mouse após o clique
    // (comportamento comum em humanos)
    if (Math.random() < 0.3) {
      await this.delay(50, 150);
      
      // Pequeno movimento aleatório após o clique
      const postClickX = x + (Math.random() * 20 - 10);
      const postClickY = y + (Math.random() * 20 - 10);
      
      const postClickEvent = new MouseEvent('mousemove', {
        view: window,
        bubbles: true,
        cancelable: true,
        clientX: postClickX,
        clientY: postClickY
      });
      
      document.elementFromPoint(postClickX, postClickY)?.dispatchEvent(postClickEvent);
    }
    
    // Aguarda um tempo para simular reação humana após o clique
    // Tempo de reação variável dependendo do contexto
    // - Cliques em botões de navegação geralmente têm um tempo de espera maior
    const aparenciaBotao = elemento.tagName === 'BUTTON' || 
                          elemento.tagName === 'A' ||
                          elemento.className.includes('btn') ||
                          elemento.className.includes('button');
                          
    if (aparenciaBotao) {
      // Espera um pouco mais após clicar em botões, simulando a expectativa de mudança de página
      await this.delay(500, 1500);
    } else {
      // Tempo padrão para outros elementos
      await this.delay(200, 600);
    }
    
    return true;
  },
  
  /**
   * Rola a página para exibir um elemento
   * @param {Element} elemento - Elemento para exibir
   */
  rolarParaElemento(elemento) {
    if (!elemento) return;
    
    const rect = elemento.getBoundingClientRect();
    const viewHeight = window.innerHeight;
    
    // Verifica se o elemento está fora da área visível
    if (rect.top < 0 || rect.bottom > viewHeight) {
      // Calcula a posição de rolagem ideal (deixa algum espaço acima)
      const scrollY = rect.top + window.scrollY - 100;
      
      // Rola suavemente para a posição
      window.scrollTo({
        top: scrollY,
        behavior: 'smooth'
      });
    }
  },
  
  /**
   * Simula digitação humana em um campo de entrada
   * @param {Element} elemento - Campo de entrada para digitar
   * @param {string} texto - Texto a ser digitado
   * @returns {Promise} - Promessa que resolve após a digitação
   */
  async digitar(elemento, texto) {
    if (!elemento) throw new Error('Elemento não encontrado para digitação');
    
    // Rola a página para o elemento, se necessário
    this.rolarParaElemento(elemento);
    await this.delay(300, 700);
    
    // Simula movimento do mouse e clique para focar o elemento
    if (this.config.movimentoMouseAtivado) {
      await this.moverMousePara(elemento);
    }
    await this.clicar(elemento, true);
    
    // Limpa o campo se já tiver conteúdo (como um humano faria)
    if (elemento.value) {
      // Uma pessoa real poderia usar Ctrl+A e depois digitar (sobrescrever),
      // ou deletar o conteúdo caractere por caractere, ou usar backspace
      
      // Escolhemos uma abordagem aleatória
      const abordagemLimpeza = Math.random();
      
      if (abordagemLimpeza < 0.4) {
        // Abordagem 1: Seleciona tudo com Ctrl+A e substitui
        elemento.select();
        await this.delay(100, 300);
        
        // Eventos para simular Ctrl+A
        elemento.dispatchEvent(new KeyboardEvent('keydown', {
          key: 'a',
          code: 'KeyA',
          ctrlKey: true,
          bubbles: true,
          cancelable: true
        }));
        
        elemento.dispatchEvent(new KeyboardEvent('keyup', {
          key: 'a',
          code: 'KeyA',
          ctrlKey: true,
          bubbles: true,
          cancelable: true
        }));
        
        await this.delay(50, 150);
      } else if (abordagemLimpeza < 0.7) {
        // Abordagem 2: Usa a tecla Delete para limpar o campo
        const valorAtual = elemento.value;
        elemento.focus();
        
        // Simula pressionar End para ir ao final e depois deletar para trás
        elemento.dispatchEvent(new KeyboardEvent('keydown', {
          key: 'End',
          code: 'End',
          bubbles: true,
          cancelable: true
        }));
        
        elemento.dispatchEvent(new KeyboardEvent('keyup', {
          key: 'End',
          code: 'End',
          bubbles: true,
          cancelable: true
        }));
        
        await this.delay(50, 150);
        
        // Backspace para cada caractere
        for (let i = 0; i < valorAtual.length; i++) {
          elemento.dispatchEvent(new KeyboardEvent('keydown', {
            key: 'Backspace',
            code: 'Backspace',
            bubbles: true,
            cancelable: true
          }));
          
          elemento.value = valorAtual.substring(0, valorAtual.length - i - 1);
          elemento.dispatchEvent(new Event('input', { bubbles: true }));
          
          elemento.dispatchEvent(new KeyboardEvent('keyup', {
            key: 'Backspace',
            code: 'Backspace',
            bubbles: true,
            cancelable: true
          }));
          
          await this.delay(30, 80);
        }
      } else {
        // Abordagem 3: Simplesmente limpa o valor diretamente
        // (como se tivesse clicado no X do campo ou usado algum atalho)
        elemento.value = '';
        elemento.dispatchEvent(new Event('input', { bubbles: true }));
        await this.delay(50, 200);
      }
    }
    
    // Se a digitação natural não estiver ativada, define o valor diretamente
    if (!this.config.digitacaoNatural) {
      elemento.value = texto;
      elemento.dispatchEvent(new Event('input', { bubbles: true }));
      elemento.dispatchEvent(new Event('change', { bubbles: true }));
      await this.delay();
      return;
    }
    
    // Análise de padrões de digitação para grupos de teclas próximas no teclado
    // Isso imita melhor o comportamento humano real, com velocidades diferentes para diferentes combinações de teclas
    
    // Simula digitação caractere por caractere
    for (let i = 0; i < texto.length; i++) {
      const caracterAtual = texto[i];
      const proximoCaractere = i < texto.length - 1 ? texto[i + 1] : null;
      
      // Adiciona o caractere ao valor atual
      elemento.value += caracterAtual;
      
      // Dispara eventos para atualizar a interface
      elemento.dispatchEvent(new Event('input', { bubbles: true }));
      
      // Simula o evento de digitação da tecla específica
      this.simularEventoTecla(elemento, caracterAtual);
      
      // Calcula o atraso baseado em vários fatores humanos
      let velocidadeBase;
      
      // Fatores que afetam a velocidade de digitação:
      
      // 1. Pausa maior quando encontra pontuação (humanos naturalmente pausam após pontos, vírgulas)
      if ('.,:;!?'.includes(caracterAtual)) {
        velocidadeBase = Math.floor(Math.random() * 200) + 100;
      } 
      // 2. Pausa para pensar ocasionalmente (hesitação humana)
      else if (Math.random() < 0.05) {
        velocidadeBase = Math.floor(Math.random() * 400) + 300;
      }
      // 3. Teclas próximas no teclado são digitadas mais rapidamente em sequência
      else if (proximoCaractere && this.teclasProximas(caracterAtual, proximoCaractere)) {
        velocidadeBase = Math.floor(Math.random() * 70) + 30;
      }
      // 4. Velocidade padrão com ligeira variação
      else {
        velocidadeBase = Math.floor(Math.random() * 100) + 60;
      }
      
      // Adiciona variações aleatórias para parecer mais natural
      const variacao = Math.floor(Math.random() * 40) - 20; // ±20ms
      await this.delay(Math.max(20, velocidadeBase + variacao), velocidadeBase + variacao + 30);
      
      // Simula erro de digitação ocasional e correção (comportamento muito humano)
      if (Math.random() < 0.03) { // 3% de chance de erro
        // Adiciona um caractere errado aleatório
        const caracteresProximos = this.obterCaracteresProximosTeclado(caracterAtual);
        if (caracteresProximos.length > 0) {
          const erroCaractere = caracteresProximos[Math.floor(Math.random() * caracteresProximos.length)];
          
          // Simula digitação do erro
          elemento.value += erroCaractere;
          elemento.dispatchEvent(new Event('input', { bubbles: true }));
          this.simularEventoTecla(elemento, erroCaractere);
          
          await this.delay(100, 300);
          
          // Simula a correção (backspace)
          this.simularEventoTecla(elemento, 'Backspace');
          elemento.value = elemento.value.slice(0, -1);
          elemento.dispatchEvent(new Event('input', { bubbles: true }));
          
          await this.delay(100, 250);
          
          // Digita o caractere correto
          elemento.value += caracterAtual;
          elemento.dispatchEvent(new Event('input', { bubbles: true }));
          this.simularEventoTecla(elemento, caracterAtual);
          
          await this.delay(60, 150);
        }
      }
    }
    
    // Dispara o evento change após a digitação completa
    elemento.dispatchEvent(new Event('change', { bubbles: true }));
    
    // Aguarda um tempo após a digitação
    await this.delay(200, 500);
  },
  
  /**
   * Simula eventos de teclado para uma tecla específica
   * @param {Element} elemento - Elemento de destino
   * @param {string} tecla - Tecla a ser simulada
   */
  simularEventoTecla(elemento, tecla) {
    // KeyboardEvent para keydown
    elemento.dispatchEvent(new KeyboardEvent('keydown', {
      key: tecla,
      code: this.obterCodeDeTecla(tecla),
      bubbles: true,
      cancelable: true
    }));
    
    // KeyboardEvent para keypress (deprecado mas ainda usado)
    elemento.dispatchEvent(new KeyboardEvent('keypress', {
      key: tecla,
      code: this.obterCodeDeTecla(tecla),
      bubbles: true,
      cancelable: true
    }));
    
    // KeyboardEvent para keyup
    elemento.dispatchEvent(new KeyboardEvent('keyup', {
      key: tecla,
      code: this.obterCodeDeTecla(tecla),
      bubbles: true,
      cancelable: true
    }));
  },
  
  /**
   * Obtém o código da tecla para eventos de teclado
   * @param {string} tecla - Tecla para obter o código
   * @returns {string} - Código da tecla
   */
  obterCodeDeTecla(tecla) {
    const mapeamentoTeclas = {
      'a': 'KeyA', 'b': 'KeyB', 'c': 'KeyC', 'd': 'KeyD', 'e': 'KeyE', 'f': 'KeyF',
      'g': 'KeyG', 'h': 'KeyH', 'i': 'KeyI', 'j': 'KeyJ', 'k': 'KeyK', 'l': 'KeyL',
      'm': 'KeyM', 'n': 'KeyN', 'o': 'KeyO', 'p': 'KeyP', 'q': 'KeyQ', 'r': 'KeyR',
      's': 'KeyS', 't': 'KeyT', 'u': 'KeyU', 'v': 'KeyV', 'w': 'KeyW', 'x': 'KeyX',
      'y': 'KeyY', 'z': 'KeyZ',
      '0': 'Digit0', '1': 'Digit1', '2': 'Digit2', '3': 'Digit3', '4': 'Digit4',
      '5': 'Digit5', '6': 'Digit6', '7': 'Digit7', '8': 'Digit8', '9': 'Digit9',
      ' ': 'Space', '.': 'Period', ',': 'Comma', ';': 'Semicolon', "'": 'Quote',
      '[': 'BracketLeft', ']': 'BracketRight', '\\': 'Backslash', '-': 'Minus',
      '=': 'Equal', '/': 'Slash', '`': 'Backquote', 'Backspace': 'Backspace',
      'Enter': 'Enter', 'Tab': 'Tab'
    };
    
    return mapeamentoTeclas[tecla.toLowerCase()] || 'Unidentified';
  },
  
  /**
   * Verifica se duas teclas estão próximas no teclado
   * @param {string} tecla1 - Primeira tecla
   * @param {string} tecla2 - Segunda tecla
   * @returns {boolean} - True se as teclas estão próximas
   */
  teclasProximas(tecla1, tecla2) {
    const mapaProximidade = {
      'q': ['w', 'a', '1', '2'],
      'w': ['q', 'e', 'a', 's', '2', '3'],
      'e': ['w', 'r', 's', 'd', '3', '4'],
      'r': ['e', 't', 'd', 'f', '4', '5'],
      't': ['r', 'y', 'f', 'g', '5', '6'],
      'y': ['t', 'u', 'g', 'h', '6', '7'],
      'u': ['y', 'i', 'h', 'j', '7', '8'],
      'i': ['u', 'o', 'j', 'k', '8', '9'],
      'o': ['i', 'p', 'k', 'l', '9', '0'],
      'p': ['o', '[', 'l', ';', '0', '-'],
      'a': ['q', 'w', 's', 'z'],
      's': ['w', 'e', 'a', 'd', 'z', 'x'],
      'd': ['e', 'r', 's', 'f', 'x', 'c'],
      'f': ['r', 't', 'd', 'g', 'c', 'v'],
      'g': ['t', 'y', 'f', 'h', 'v', 'b'],
      'h': ['y', 'u', 'g', 'j', 'b', 'n'],
      'j': ['u', 'i', 'h', 'k', 'n', 'm'],
      'k': ['i', 'o', 'j', 'l', 'm', ','],
      'l': ['o', 'p', 'k', ';', ',', '.'],
      'z': ['a', 's', 'x'],
      'x': ['s', 'd', 'z', 'c'],
      'c': ['d', 'f', 'x', 'v'],
      'v': ['f', 'g', 'c', 'b'],
      'b': ['g', 'h', 'v', 'n'],
      'n': ['h', 'j', 'b', 'm'],
      'm': ['j', 'k', 'n', ','],
      ',': ['k', 'l', 'm', '.'],
      '.': ['l', ';', ',', '/'],
      '1': ['q', '2'],
      '2': ['1', 'q', 'w', '3'],
      '3': ['2', 'w', 'e', '4'],
      '4': ['3', 'e', 'r', '5'],
      '5': ['4', 'r', 't', '6'],
      '6': ['5', 't', 'y', '7'],
      '7': ['6', 'y', 'u', '8'],
      '8': ['7', 'u', 'i', '9'],
      '9': ['8', 'i', 'o', '0'],
      '0': ['9', 'o', 'p', '-'],
      '-': ['0', 'p', '[', '='],
      '=': ['-', '[', ']'],
      '[': ['p', ']', '='],
      ']': ['[', '\\'],
      '\\': [']'],
      ';': ['l', "'", '.', '/'],
      "'": [';', '\\'],
      '/': ['.', ';', "'"]
    };
    
    const t1 = tecla1.toLowerCase();
    const t2 = tecla2.toLowerCase();
    
    return mapaProximidade[t1] && mapaProximidade[t1].includes(t2);
  },
  
  /**
   * Obtém caracteres próximos a uma tecla específica no teclado
   * @param {string} tecla - Tecla para encontrar vizinhos
   * @returns {string[]} - Array de caracteres próximos
   */
  obterCaracteresProximosTeclado(tecla) {
    const mapaProximidade = {
      'q': ['w', 'a', '1', '2'],
      'w': ['q', 'e', 'a', 's', '2', '3'],
      'e': ['w', 'r', 's', 'd', '3', '4'],
      'r': ['e', 't', 'd', 'f', '4', '5'],
      't': ['r', 'y', 'f', 'g', '5', '6'],
      'y': ['t', 'u', 'g', 'h', '6', '7'],
      'u': ['y', 'i', 'h', 'j', '7', '8'],
      'i': ['u', 'o', 'j', 'k', '8', '9'],
      'o': ['i', 'p', 'k', 'l', '9', '0'],
      'p': ['o', '[', 'l', ';', '0', '-'],
      'a': ['q', 'w', 's', 'z'],
      's': ['w', 'e', 'a', 'd', 'z', 'x'],
      'd': ['e', 'r', 's', 'f', 'x', 'c'],
      'f': ['r', 't', 'd', 'g', 'c', 'v'],
      'g': ['t', 'y', 'f', 'h', 'v', 'b'],
      'h': ['y', 'u', 'g', 'j', 'b', 'n'],
      'j': ['u', 'i', 'h', 'k', 'n', 'm'],
      'k': ['i', 'o', 'j', 'l', 'm', ','],
      'l': ['o', 'p', 'k', ';', ',', '.'],
      'z': ['a', 's', 'x'],
      'x': ['s', 'd', 'z', 'c'],
      'c': ['d', 'f', 'x', 'v'],
      'v': ['f', 'g', 'c', 'b'],
      'b': ['g', 'h', 'v', 'n'],
      'n': ['h', 'j', 'b', 'm'],
      'm': ['j', 'k', 'n', ','],
      ',': ['k', 'l', 'm', '.'],
      '.': ['l', ';', ',', '/'],
      '1': ['q', '2'],
      '2': ['1', 'q', 'w', '3'],
      '3': ['2', 'w', 'e', '4'],
      '4': ['3', 'e', 'r', '5'],
      '5': ['4', 'r', 't', '6'],
      '6': ['5', 't', 'y', '7'],
      '7': ['6', 'y', 'u', '8'],
      '8': ['7', 'u', 'i', '9'],
      '9': ['8', 'i', 'o', '0'],
      '0': ['9', 'o', 'p', '-'],
      '-': ['0', 'p', '[', '='],
      '=': ['-', '[', ']'],
      '[': ['p', ']', '='],
      ']': ['[', '\\'],
      '\\': [']'],
      ';': ['l', "'", '.', '/'],
      "'": [';', '\\'],
      '/': ['.', ';', "'"],
      ' ': ['c', 'v', 'b', 'n', 'm']
    };
    
    const t = tecla.toLowerCase();
    return mapaProximidade[t] || [];
  },
  
  /**
   * Simula o upload de um arquivo
   * @param {Element} inputElement - Elemento de input file
   * @param {File|File[]} arquivos - Arquivo(s) para upload
   * @returns {Promise} - Promessa que resolve após o upload
   */
  async uploadArquivo(inputElement, arquivos) {
    if (!inputElement || inputElement.type !== 'file') {
      throw new Error('Elemento de input de arquivo inválido');
    }
    
    // Rola a página para o elemento, se necessário
    this.rolarParaElemento(inputElement);
    await this.delay(300, 700);
    
    // Cria um DataTransfer para simular o upload
    const dataTransfer = new DataTransfer();
    
    // Adiciona os arquivos ao DataTransfer
    if (Array.isArray(arquivos)) {
      arquivos.forEach(arquivo => dataTransfer.items.add(arquivo));
    } else {
      dataTransfer.items.add(arquivos);
    }
    
    // Define os arquivos no input
    inputElement.files = dataTransfer.files;
    
    // Dispara eventos necessários
    inputElement.dispatchEvent(new Event('change', { bubbles: true }));
    
    // Aguarda um tempo após o upload
    await this.delay(1000, 2000);
  },
  
  /**
   * Simula a seleção de um item em um elemento select
   * @param {Element} selectElement - Elemento select
   * @param {string|number} valor - Valor a ser selecionado
   * @returns {Promise} - Promessa que resolve após a seleção
   */
  async selecionarOpcao(selectElement, valor) {
    if (!selectElement || selectElement.tagName !== 'SELECT') {
      throw new Error('Elemento select inválido');
    }
    
    // Foca no elemento
    await this.clicar(selectElement);
    
    // Encontra a opção com o valor especificado
    let opcaoEncontrada = false;
    for (const option of selectElement.options) {
      if (option.value === valor || option.textContent === valor) {
        selectElement.value = option.value;
        opcaoEncontrada = true;
        break;
      }
    }
    
    if (!opcaoEncontrada) {
      throw new Error(`Opção com valor "${valor}" não encontrada no select`);
    }
    
    // Dispara eventos
    selectElement.dispatchEvent(new Event('change', { bubbles: true }));
    
    // Aguarda um tempo após a seleção
    await this.delay();
  }
};

export default HumanSimulation;
