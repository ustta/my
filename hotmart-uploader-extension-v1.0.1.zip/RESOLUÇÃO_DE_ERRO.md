# Resolução de Erro "Arquivo de manifesto faltando ou não pode ser lido"

Se você estiver encontrando o erro "O arquivo de manifesto está faltando ou não pode ser lido" ao tentar instalar a extensão, siga estas instruções:

## Método 1: Instalar usando a pasta descompactada

1. Certifique-se de extrair completamente o arquivo ZIP antes de instalar:
   - Faça o download do arquivo `hotmart-uploader-extension-v1.0.1.zip`
   - Clique com o botão direito e escolha "Extrair tudo" 
   - Selecione uma pasta de destino (exemplo: `C:\Extensões\Hotmart`)
   - Confirme a extração

2. No Chrome, acesse `chrome://extensions/`

3. Ative o "Modo do desenvolvedor" no canto superior direito

4. Clique em "Carregar sem compactação"

5. **Importante:** Selecione a PASTA onde você extraiu os arquivos, não o arquivo ZIP

6. A extensão deve ser carregada com sucesso

## Método 2: Solução para problemas de permissão

Se o erro persistir:

1. Verifique se você tem permissões de acesso à pasta onde extraiu os arquivos
2. Tente extrair para uma pasta mais simples (exemplo: `C:\temp\hotmart`)
3. Certifique-se de que nenhum antivírus está bloqueando o acesso aos arquivos
4. Tente reiniciar o navegador antes de tentar instalar novamente

## Verificação de arquivos

A estrutura correta da pasta deve conter:
```
manifest.json
background.js
content.js
popup.html
popup.css
popup.js
/assets (pasta)
/utils (pasta)
```

Se o arquivo `manifest.json` estiver ausente ou inacessível, a extensão não poderá ser instalada.

Para qualquer dúvida adicional, sinta-se à vontade para entrar em contato.