# Changelog - Extensão Hotmart Upload Automático

## Versão 1.0.1 (15/05/2025)
- Adicionado suporte para upload em lote de até 500 arquivos
- Implementado processamento em lotes configuráveis (padrão: 50 arquivos por lote)
- Melhorada a visualização da lista de arquivos com resumo para grandes quantidades
- Adicionada exibição do tamanho total dos arquivos adicionais selecionados
- Refatorado o código para melhor organização e legibilidade
- Adicionada detecção automática de inputs de arquivo compatíveis com múltiplos arquivos
- Melhorada a manipulação de eventos no Shadow DOM
- Corrigidos bugs relacionados à detecção de botões na interface da Hotmart

## Versão 1.0.0 (01/05/2025)
- Lançamento inicial da extensão
- Implementação do sistema de simulação de comportamento humano
- Suporte para manipulação de Shadow DOM na Hotmart
- Interface para seleção de arquivos (capa, conteúdo principal, arquivos adicionais)
- Detecção automática do tipo de upload baseado no contexto da página
- Simulação de movimentos de mouse realistas com curvas Bezier
- Padrões de digitação humanizados com timing variável
- Configurações ajustáveis para timing e comportamento