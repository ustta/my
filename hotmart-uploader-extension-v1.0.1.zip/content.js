// Script de conteúdo para execução na página da Hotmart
// Este script é injetado em todas as páginas da Hotmart e gerencia a automação

// Carrega os módulos de utilidades
let shadowDomUtils = null;
let humanSimulation = null;
let hotmartNavigator = null;

// Estado da automação
let automacaoAtiva = false;
let configAutomacao = {
  delayMinimo: 800,
  delayMaximo: 2000,
  verificarSucessoUpload: true
};

// Carrega os módulos da extensão
async function carregarModulos() {
  // Carrega os módulos dinâmicamente
  shadowDomUtils = await import(chrome.runtime.getURL('utils/shadow-dom.js'));
  humanSimulation = await import(chrome.runtime.getURL('utils/human-simulation.js'));
  hotmartNavigator = await import(chrome.runtime.getURL('utils/hotmart-navigator.js'));
  
  console.log('Módulos de automação carregados');
}

// Inicia o processo de automação
async function iniciarAutomacao(config) {
  if (automacaoAtiva) {
    console.log('Automação já está em execução');
    return;
  }
  
  try {
    // Atualiza configurações
    configAutomacao = { ...configAutomacao, ...config };
    
    // Inicializa os módulos se ainda não foram carregados
    if (!shadowDomUtils) {
      await carregarModulos();
    }
    
    // Inicia a automação
    automacaoAtiva = true;
    atualizarStatus('Iniciando automação...');
    
    // Configura as utilidades com as configurações atuais
    humanSimulation.default.configurar(configAutomacao);
    hotmartNavigator.default.configurar(configAutomacao, shadowDomUtils.default, humanSimulation.default);
    
    // Determina em que página da Hotmart estamos
    const paginaAtual = detectarPaginaHotmart();
    
    // Inicia o fluxo de automação de acordo com a página
    if (paginaAtual === 'login') {
      atualizarStatus('Por favor, faça login na Hotmart antes de iniciar a automação');
      automacaoAtiva = false;
      return;
    }
    
    // Executa o fluxo principal
    await executarFluxoAutomacao(paginaAtual);
    
  } catch (erro) {
    console.error('Erro ao iniciar automação:', erro);
    atualizarStatus(`Erro: ${erro.message}`);
    automacaoAtiva = false;
  }
}

// Detecta em qual página da Hotmart estamos
function detectarPaginaHotmart() {
  const url = window.location.href;
  
  if (url.includes('hotmart.com/login')) {
    return 'login';
  } else if (url.includes('hotmart.com/club/products')) {
    return 'listagemProdutos';
  } else if (url.includes('hotmart.com/club/products/') && url.includes('/edit')) {
    return 'edicaoProduto';
  } else if (url.includes('hotmart.com/club/products/') && url.includes('/pricing')) {
    return 'precificacao';
  } else if (url.includes('hotmart.com/club/products/create')) {
    return 'criacaoProduto';
  } else {
    return 'outra';
  }
}

// Executa o fluxo de automação com base na página atual
async function executarFluxoAutomacao(paginaAtual) {
  try {
    atualizarStatus(`Executando automação na página: ${paginaAtual}`);
    
    switch (paginaAtual) {
      case 'listagemProdutos':
        await hotmartNavigator.default.navegarParaCriacaoProduto();
        break;
        
      case 'criacaoProduto':
        await hotmartNavigator.default.preencherFormularioCriacaoProduto();
        break;
        
      case 'edicaoProduto':
        await hotmartNavigator.default.realizarUploadArquivos();
        break;
        
      case 'precificacao':
        await hotmartNavigator.default.manipularPrecificacao();
        break;
        
      default:
        atualizarStatus('Navegue até a página de produtos da Hotmart para iniciar');
        automacaoAtiva = false;
    }
    
    if (automacaoAtiva) {
      atualizarStatus('Automação concluída com sucesso!');
      automacaoAtiva = false;
    }
    
  } catch (erro) {
    console.error('Erro durante a execução da automação:', erro);
    atualizarStatus(`Erro: ${erro.message}`);
    automacaoAtiva = false;
  }
}

// Para o processo de automação
function pararAutomacao() {
  automacaoAtiva = false;
  atualizarStatus('Automação interrompida pelo usuário');
}

// Atualiza o status da automação e notifica o background script
function atualizarStatus(mensagem) {
  console.log(`Status: ${mensagem}`);
  
  // Envia o status para o background script
  chrome.runtime.sendMessage({
    action: 'atualizarStatus',
    status: mensagem
  });
}

// Listener para comandos do background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'executarAutomacao') {
    iniciarAutomacao(message.config);
    sendResponse({ status: 'iniciado' });
    return true;
  }
  
  if (message.action === 'pararAutomacao') {
    pararAutomacao();
    sendResponse({ status: 'parado' });
    return true;
  }
  
  if (message.action === 'verificarEstado') {
    sendResponse({
      automacaoAtiva,
      paginaAtual: detectarPaginaHotmart()
    });
    return true;
  }
});

// Carrega as configurações quando o script é iniciado
chrome.storage.local.get('configAutomacao', (result) => {
  if (result.configAutomacao) {
    configAutomacao = result.configAutomacao;
  }
});

// Pré-carrega os módulos para uso futuro
carregarModulos().catch(console.error);

console.log('Script de automação Hotmart inicializado');
