// Background script para manipular eventos globais da extensão
let currentTabId = null;

// Rastreamento de padrões para simulação humana
let ultimaAcao = {
  tempo: Date.now() - Math.floor(Math.random() * 3600000), // Tempo aleatório inicial
  tipo: 'inicialização'
};

// Adiciona variação no comportamento para ser mais realista
const simularDelayHumano = () => {
  // Maior variabilidade no delay após a instalação/atualização
  if (ultimaAcao.tipo === 'inicialização') {
    return Math.floor(Math.random() * 1000) + 200;
  }
  
  // Delay médio entre ações
  return Math.floor(Math.random() * 300) + 100;
};

// Registra ações realizadas para criar padrões mais naturalistas
const registrarAcao = (tipo) => {
  ultimaAcao = {
    tempo: Date.now(),
    tipo
  };
};

// Escuta mensagens dos scripts de conteúdo e do popup com padrões humanos
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Pequeno delay artificial para parecer mais natural
  const timeoutId = setTimeout(() => {
  if (message.action === 'iniciarAutomacao') {
    registrarAcao('iniciar_automacao');
    const { config } = message;
    
    // Adiciona variação no comportamento para parecer mais natural
    const variacaoConfig = {
      ...config,
      // Pequena variação nos valores dos delays para evitar padrões exatos
      delayMinimo: parseInt(config.delayMinimo, 10) + Math.floor(Math.random() * 20) - 10,
      delayMaximo: parseInt(config.delayMaximo, 10) + Math.floor(Math.random() * 30) - 15
    };
    
    // Armazena as configurações no storage da extensão com timing variável
    const inicioOperacao = Date.now();
    chrome.storage.local.set({ configAutomacao: variacaoConfig }, () => {
      // Simula o tempo que um humano levaria para processar esta ação
      const tempoOperacao = Date.now() - inicioOperacao;
      const delayEsperado = Math.max(0, Math.floor(Math.random() * 100) + 20 - tempoOperacao);
      
      setTimeout(() => {
        console.log('Configurações de automação salvas');
      }, delayEsperado);
    });
    
    // Injeta o script de automação na aba ativa da Hotmart com padrões realistas
    setTimeout(() => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs.length > 0) {
          currentTabId = tabs[0].id;
          
          // Verifica se estamos em um domínio da Hotmart
          if (tabs[0].url.includes('hotmart.com')) {
            // Pequeno delay variável antes de enviar o comando
            setTimeout(() => {
              chrome.tabs.sendMessage(currentTabId, { 
                action: 'executarAutomacao', 
                config: variacaoConfig 
              });
              
              // Delay variável antes de responder
              setTimeout(() => {
                sendResponse({ status: 'iniciado' });
              }, Math.floor(Math.random() * 100) + 30);
            }, Math.floor(Math.random() * 150) + 50);
          } else {
            sendResponse({ 
              status: 'erro', 
              mensagem: 'Você precisa estar na plataforma Hotmart para iniciar a automação' 
            });
          }
        }
      });
    }, simularDelayHumano());
    
    return true; // Indica que a resposta será assíncrona
  }
  
  if (message.action === 'pararAutomacao') {
    registrarAcao('parar_automacao');
    
    if (currentTabId) {
      // Adiciona um delay variável para simular comportamento humano
      setTimeout(() => {
        chrome.tabs.sendMessage(currentTabId, { action: 'pararAutomacao' });
        
        // Responde após um pequeno atraso
        setTimeout(() => {
          sendResponse({ status: 'parado' });
        }, Math.floor(Math.random() * 80) + 20);
      }, simularDelayHumano());
    }
    return true;
  }
  
  if (message.action === 'atualizarStatus') {
    registrarAcao('atualizar_status');
    
    // Repassa o status para o popup após um pequeno delay variável
    setTimeout(() => {
      chrome.runtime.sendMessage({ 
        action: 'statusAtualizado', 
        status: message.status 
      });
    }, Math.floor(Math.random() * 70) + 30);
    
    return true;
  }
  }, simularDelayHumano());
});

// Escuta quando uma aba é alterada para atualizar o currentTabId
chrome.tabs.onActivated.addListener((activeInfo) => {
  currentTabId = activeInfo.tabId;
});

// Quando a extensão é instalada ou atualizada
chrome.runtime.onInstalled.addListener(() => {
  console.log('Extensão de automação Hotmart instalada/atualizada');
  
  // Inicializa as configurações padrão
  chrome.storage.local.set({
    configAutomacao: {
      delayMinimo: 800,
      delayMaximo: 2000,
      verificarSucessoUpload: true
    }
  });
});
