// Script para controlar a interface do popup da extensão

// Variável que rastreia o último tempo de interação do usuário
// Usado para evitar padrões robóticos de interação
let ultimaInteracaoUsuario = Date.now() - Math.floor(Math.random() * 60000);

// Adiciona variabilidade no tempo de carregamento para parecer mais natural
setTimeout(() => {
  console.log('Interface carregada');
}, Math.floor(Math.random() * 150) + 50);

// Elementos da interface
const statusElement = document.getElementById('status');
const btnIniciar = document.getElementById('btnIniciar');
const btnParar = document.getElementById('btnParar');
const delayMinimoInput = document.getElementById('delayMinimo');
const delayMaximoInput = document.getElementById('delayMaximo');
const verificarSucessoUploadCheckbox = document.getElementById('verificarSucessoUpload');

// Elementos de upload de arquivos
const arquivoCapaInput = document.getElementById('arquivoCapa');
const arquivoConteudoInput = document.getElementById('arquivoConteudo');
const arquivosAdicionaisInput = document.getElementById('arquivosAdicionais');
const arquivosPreparadosEl = document.getElementById('arquivosPreparados');
const modoLoteCheckbox = document.getElementById('modoLote');
const limiteArquivosInput = document.getElementById('limiteArquivos');

// Estado da interface
let automacaoAtiva = false;

// Armazena os arquivos selecionados
let arquivosSelecionados = {
  capa: null,
  conteudo: null,
  adicionais: []
};

// Atualiza a interface com base no estado da automação
function atualizarInterface(ativa) {
  automacaoAtiva = ativa;
  
  btnIniciar.disabled = ativa;
  btnParar.disabled = !ativa;
  
  delayMinimoInput.disabled = ativa;
  delayMaximoInput.disabled = ativa;
  verificarSucessoUploadCheckbox.disabled = ativa;
  
  if (ativa) {
    statusElement.classList.add('ativo');
  } else {
    statusElement.classList.remove('ativo');
  }
}

// Atualiza o status exibido
function atualizarStatus(mensagem) {
  statusElement.textContent = mensagem;
}

// Verifica o estado atual da automação na aba ativa
function verificarEstadoAutomacao() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs.length > 0 && tabs[0].url.includes('hotmart.com')) {
      chrome.tabs.sendMessage(tabs[0].id, { action: 'verificarEstado' }, (response) => {
        if (chrome.runtime.lastError) {
          console.log('Erro ao verificar estado:', chrome.runtime.lastError);
          return;
        }
        
        if (response && response.automacaoAtiva !== undefined) {
          atualizarInterface(response.automacaoAtiva);
        }
      });
    }
  });
}

// Carrega as configurações salvas
function carregarConfiguracoes() {
  chrome.storage.local.get('configAutomacao', (result) => {
    if (result.configAutomacao) {
      delayMinimoInput.value = result.configAutomacao.delayMinimo || 800;
      delayMaximoInput.value = result.configAutomacao.delayMaximo || 2000;
      verificarSucessoUploadCheckbox.checked = 
        result.configAutomacao.verificarSucessoUpload !== undefined ? 
        result.configAutomacao.verificarSucessoUpload : true;
    }
  });
}

// Inicia a automação na aba atual
// Atualiza a lista de arquivos preparados na interface
function atualizarListaArquivos() {
  // Verifica se há algum arquivo selecionado
  const temArquivos = arquivosSelecionados.capa || arquivosSelecionados.conteudo || arquivosSelecionados.adicionais.length > 0;
  
  if (!temArquivos) {
    arquivosPreparadosEl.innerHTML = 'Nenhum arquivo selecionado';
    return;
  }
  
  // Constrói a lista de arquivos HTML
  let html = '<div class="files-list">';
  
  if (arquivosSelecionados.capa) {
    html += `<div class="file-item">Capa: ${arquivosSelecionados.capa.name} (${formatFileSize(arquivosSelecionados.capa.size)})</div>`;
  }
  
  if (arquivosSelecionados.conteudo) {
    html += `<div class="file-item">Conteúdo: ${arquivosSelecionados.conteudo.name} (${formatFileSize(arquivosSelecionados.conteudo.size)})</div>`;
  }
  
  if (arquivosSelecionados.adicionais.length > 0) {
    const totalSize = arquivosSelecionados.adicionais.reduce((acc, arquivo) => acc + arquivo.size, 0);
    html += `<div class="file-item">Arquivos adicionais: ${arquivosSelecionados.adicionais.length} selecionados (${formatFileSize(totalSize)} total)</div>`;
    
    // Se forem muitos arquivos, mostra apenas os primeiros 10 e resume o resto
    if (arquivosSelecionados.adicionais.length > 10) {
      // Exibe os primeiros 10
      for (let i = 0; i < 5; i++) {
        const arquivo = arquivosSelecionados.adicionais[i];
        html += `<div class="file-item" style="margin-left: 15px;">${arquivo.name} (${formatFileSize(arquivo.size)})</div>`;
      }
      
      // Mensagem de resumo para os arquivos ocultos
      html += `<div class="file-item-collapsed">[...] ${arquivosSelecionados.adicionais.length - 10} arquivos não exibidos</div>`;
      
      // Exibe os últimos 5
      for (let i = Math.max(5, arquivosSelecionados.adicionais.length - 5); i < arquivosSelecionados.adicionais.length; i++) {
        const arquivo = arquivosSelecionados.adicionais[i];
        html += `<div class="file-item" style="margin-left: 15px;">${arquivo.name} (${formatFileSize(arquivo.size)})</div>`;
      }
      
      // Adiciona aviso sobre upload em lote
      if (arquivosSelecionados.adicionais.length > 50) {
        html += `<div class="file-batch-info">Será feito upload em lotes de ${limiteArquivosInput.value} arquivos.</div>`;
      }
    } else {
      // Se forem poucos arquivos, mostra todos
      for (const arquivo of arquivosSelecionados.adicionais) {
        html += `<div class="file-item" style="margin-left: 15px;">${arquivo.name} (${formatFileSize(arquivo.size)})</div>`;
      }
    }
  }
  
  html += '</div>';
  arquivosPreparadosEl.innerHTML = html;
}

// Formata o tamanho do arquivo de bytes para KB, MB, etc
function formatFileSize(bytes) {
  if (bytes < 1024) {
    return bytes + ' bytes';
  } else if (bytes < 1048576) {
    return (bytes / 1024).toFixed(1) + ' KB';
  } else {
    return (bytes / 1048576).toFixed(1) + ' MB';
  }
}

// Salva os arquivos selecionados na storage para uso posterior
function salvarArquivosSelecionados() {
  // Não é possível armazenar diretamente objetos File na storage
  // Vamos converter para objetos que podem ser serializados
  
  const prepararArquivoParaStorage = async (file) => {
    if (!file) return null;
    
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        resolve({
          name: file.name,
          type: file.type,
          size: file.size,
          dataUrl: event.target.result,
        });
      };
      reader.readAsDataURL(file);
    });
  };
  
  const processarArquivos = async () => {
    const capaProcessada = await prepararArquivoParaStorage(arquivosSelecionados.capa);
    const conteudoProcessado = await prepararArquivoParaStorage(arquivosSelecionados.conteudo);
    
    const adicionaisProcessados = [];
    for (const arquivo of arquivosSelecionados.adicionais) {
      const processed = await prepararArquivoParaStorage(arquivo);
      adicionaisProcessados.push(processed);
    }
    
    // Armazena os arquivos processados
    chrome.storage.local.set({
      arquivosUpload: {
        capa: capaProcessada,
        conteudo: conteudoProcessado,
        adicionais: adicionaisProcessados
      }
    }, () => {
      console.log('Arquivos salvos para uso na automação');
    });
  };
  
  processarArquivos();
}

// Restaura arquivos selecionados da storage
function carregarArquivosSalvos() {
  chrome.storage.local.get('arquivosUpload', (result) => {
    if (result.arquivosUpload) {
      console.log('Arquivos encontrados no armazenamento');
      
      // Atualiza a interface para mostrar que há arquivos salvos
      let html = '<div class="files-list">';
      
      if (result.arquivosUpload.capa) {
        html += `<div class="file-item">Capa: ${result.arquivosUpload.capa.name} (${formatFileSize(result.arquivosUpload.capa.size)})</div>`;
      }
      
      if (result.arquivosUpload.conteudo) {
        html += `<div class="file-item">Conteúdo: ${result.arquivosUpload.conteudo.name} (${formatFileSize(result.arquivosUpload.conteudo.size)})</div>`;
      }
      
      if (result.arquivosUpload.adicionais && result.arquivosUpload.adicionais.length > 0) {
        html += `<div class="file-item">Arquivos adicionais: ${result.arquivosUpload.adicionais.length} salvos</div>`;
      }
      
      html += '</div>';
      arquivosPreparadosEl.innerHTML = html;
    }
  });
}

function iniciarAutomacao() {
  // Coleta as configurações da interface
  const config = {
    delayMinimo: parseInt(delayMinimoInput.value, 10),
    delayMaximo: parseInt(delayMaximoInput.value, 10),
    verificarSucessoUpload: verificarSucessoUploadCheckbox.checked,
    modoLote: modoLoteCheckbox.checked,
    limiteArquivos: parseInt(limiteArquivosInput.value, 10),
    arquivos: {
      temCapa: !!arquivosSelecionados.capa,
      temConteudo: !!arquivosSelecionados.conteudo,
      temAdicionais: arquivosSelecionados.adicionais.length > 0,
      totalArquivos: (arquivosSelecionados.capa ? 1 : 0) + 
                     (arquivosSelecionados.conteudo ? 1 : 0) + 
                      arquivosSelecionados.adicionais.length
    }
  };
  
  // Validação básica
  if (config.delayMinimo >= config.delayMaximo) {
    atualizarStatus('Erro: O delay mínimo deve ser menor que o máximo');
    return;
  }
  
  // Envia a mensagem para iniciar a automação
  chrome.runtime.sendMessage(
    { action: 'iniciarAutomacao', config },
    (response) => {
      if (response && response.status === 'iniciado') {
        atualizarInterface(true);
        atualizarStatus('Automação iniciada');
      } else if (response && response.status === 'erro') {
        atualizarStatus(`Erro: ${response.mensagem}`);
      }
    }
  );
}

// Para a automação na aba atual
function pararAutomacao() {
  chrome.runtime.sendMessage(
    { action: 'pararAutomacao' },
    (response) => {
      if (response && response.status === 'parado') {
        atualizarInterface(false);
        atualizarStatus('Automação interrompida');
      }
    }
  );
}

// Registra as interações do usuário para criar padrões de uso mais naturais
const registrarInteracaoUsuario = () => {
  // Atualiza o timestamp da última interação
  ultimaInteracaoUsuario = Date.now();
  
  // Adiciona um pequeno atraso aleatório antes de algumas ações
  // para simular comportamento humano pensando/decidindo
  return new Promise(resolve => {
    // Atraso aleatório ocasional (30% de chance)
    if (Math.random() < 0.3) {
      const atraso = Math.floor(Math.random() * 300) + 100;
      setTimeout(resolve, atraso);
    } else {
      resolve();
    }
  });
};

// Versão dos handlers de evento envolvidos em simulação humana
const iniciarAutomacaoHandler = async (e) => {
  await registrarInteracaoUsuario();
  iniciarAutomacao();
};

const pararAutomacaoHandler = async (e) => {
  await registrarInteracaoUsuario();
  pararAutomacao();
};

// Event listeners para os botões com comportamento humano
btnIniciar.addEventListener('click', iniciarAutomacaoHandler);
btnParar.addEventListener('click', pararAutomacaoHandler);

// Listeners para rastrear movimento do mouse (ajuda a construir padrões realistas)
document.addEventListener('mousemove', (e) => {
  // Atualiza apenas ocasionalmente para evitar sobrecarga
  if (Math.random() < 0.1) {
    ultimaInteracaoUsuario = Date.now();
  }
});

// Validação de inputs com comportamento humano
delayMinimoInput.addEventListener('change', async () => {
  await registrarInteracaoUsuario();
  
  // Adiciona uma leve variação nos valores mínimos permitidos
  // para evitar padrões exatos que sistemas anti-bot procuram
  const minPermitido = Math.floor(Math.random() * 50) + 180; // entre 180-230
  
  if (parseInt(delayMinimoInput.value, 10) < minPermitido) {
    delayMinimoInput.value = minPermitido;
  }
});

delayMaximoInput.addEventListener('change', async () => {
  await registrarInteracaoUsuario();
  
  const minAtual = parseInt(delayMinimoInput.value, 10);
  const diferencaMinima = Math.floor(Math.random() * 100) + 450; // entre 450-550
  
  if (parseInt(delayMaximoInput.value, 10) < minAtual + diferencaMinima) {
    delayMaximoInput.value = minAtual + diferencaMinima;
  }
});

// Listener para atualizações de status da automação
chrome.runtime.onMessage.addListener((message) => {
  if (message.action === 'statusAtualizado') {
    atualizarStatus(message.status);
  }
});

// Event listeners para os campos de arquivo
arquivoCapaInput.addEventListener('change', async (e) => {
  await registrarInteracaoUsuario();
  
  if (e.target.files.length > 0) {
    arquivosSelecionados.capa = e.target.files[0];
    console.log('Arquivo de capa selecionado:', arquivosSelecionados.capa.name);
  } else {
    arquivosSelecionados.capa = null;
  }
  
  atualizarListaArquivos();
  salvarArquivosSelecionados();
});

arquivoConteudoInput.addEventListener('change', async (e) => {
  await registrarInteracaoUsuario();
  
  if (e.target.files.length > 0) {
    arquivosSelecionados.conteudo = e.target.files[0];
    console.log('Arquivo de conteúdo selecionado:', arquivosSelecionados.conteudo.name);
  } else {
    arquivosSelecionados.conteudo = null;
  }
  
  atualizarListaArquivos();
  salvarArquivosSelecionados();
});

arquivosAdicionaisInput.addEventListener('change', async (e) => {
  await registrarInteracaoUsuario();
  
  if (e.target.files.length > 0) {
    const arquivos = Array.from(e.target.files);
    
    // Verifica se não excede o limite máximo suportado (500)
    if (arquivos.length > 500) {
      alert('Por favor, selecione no máximo 500 arquivos por vez. Apenas os primeiros 500 serão processados.');
      arquivosSelecionados.adicionais = arquivos.slice(0, 500);
    } else {
      arquivosSelecionados.adicionais = arquivos;
    }
    
    console.log('Arquivos adicionais selecionados:', arquivosSelecionados.adicionais.length);
    
    // Atualiza o valor do campo de limite com base no número de arquivos
    // (para garantir que seja pelo menos igual ao número de arquivos)
    if (arquivosSelecionados.adicionais.length > parseInt(limiteArquivosInput.value, 10)) {
      // Calcula um valor adequado: 50 ou mais que o número de arquivos
      const novoLimite = Math.max(50, Math.ceil(arquivosSelecionados.adicionais.length / 10) * 10);
      limiteArquivosInput.value = Math.min(novoLimite, 500); // Não exceder 500
    }
  } else {
    arquivosSelecionados.adicionais = [];
  }
  
  atualizarListaArquivos();
  salvarArquivosSelecionados();
});

// Event listener para o checkbox de modo lote
modoLoteCheckbox.addEventListener('change', async (e) => {
  await registrarInteracaoUsuario();
  
  // Se o modo de lote for desativado mas houver muitos arquivos, alerta o usuário
  if (!e.target.checked && arquivosSelecionados.adicionais.length > 20) {
    alert(`Atenção: Você tem ${arquivosSelecionados.adicionais.length} arquivos selecionados. Recomendamos o modo de lote para grandes quantidades de arquivos.`);
  }
});

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
  carregarConfiguracoes();
  verificarEstadoAutomacao();
  carregarArquivosSalvos();
  
  // Verifica se estamos na Hotmart
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs.length > 0) {
      const tab = tabs[0];
      if (!tab.url.includes('hotmart.com')) {
        atualizarStatus('Por favor, acesse a plataforma Hotmart para usar a extensão');
        btnIniciar.disabled = true;
      }
    }
  });
  
  // Adiciona comportamentos humanos aleatórios para evitar detecção
  setTimeout(() => {
    const tempoAleatorio = Math.floor(Math.random() * 2000) + 500;
    console.log(`Interface totalmente inicializada após ${tempoAleatorio}ms`);
  }, Math.floor(Math.random() * 500) + 100);
});
