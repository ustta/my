#!/usr/bin/env python3
"""
CLI (Command Line Interface) para o sistema Hotmart Auto-Uploader
Permite usar o sistema diretamente do terminal sem a interface web
"""

import os
import sys
import argparse
import json
import datetime
import getpass
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.security import check_password_hash, generate_password_hash

# Configurar logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Inicializar app e DB
class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
db.init_app(app)

# Importar modelos necessários
with app.app_context():
    from models import User, Product, UploadSession, SessionProduct, SystemConfig, TaskQueue

def print_banner():
    """Imprime o banner do sistema"""
    print("\n" + "=" * 80)
    print("Hotmart Auto-Uploader - Interface de Linha de Comando")
    print("Sistema automatizado para uploads na Hotmart")
    print("=" * 80 + "\n")

def authenticate():
    """Autentica o usuário para uso da CLI"""
    print_banner()
    
    username = input("Nome de usuário: ")
    password = getpass.getpass("Senha: ")
    
    with app.app_context():
        user = User.query.filter_by(username=username).first()
        
        if not user:
            print("Usuário não encontrado")
            return None
            
        if not user.check_password(password):
            print("Senha incorreta")
            return None
            
        print(f"Bem-vindo, {user.first_name or username}!")
        return user

def register_user():
    """Registra um novo usuário no sistema"""
    print_banner()
    print("Registrar novo usuário\n")
    
    username = input("Nome de usuário: ")
    email = input("Email: ")
    first_name = input("Nome: ")
    last_name = input("Sobrenome: ")
    password = getpass.getpass("Senha: ")
    confirm = getpass.getpass("Confirme a senha: ")
    
    if password != confirm:
        print("As senhas não coincidem.")
        return False
    
    with app.app_context():
        # Verificar se usuário já existe
        if User.query.filter_by(username=username).first():
            print("Nome de usuário já existe.")
            return False
            
        if User.query.filter_by(email=email).first():
            print("Email já está em uso.")
            return False
        
        # Criar novo usuário
        user = User()
        user.username = username
        user.email = email
        user.first_name = first_name
        user.last_name = last_name
        user.set_password(password)
        user.auth_type = 'local'
        
        # Se for o primeiro usuário, torná-lo admin
        if User.query.count() == 0:
            user.role = 'admin'
        
        db.session.add(user)
        db.session.commit()
        
        print(f"Usuário {username} criado com sucesso!")
        return True

def list_products():
    """Lista todos os produtos no sistema"""
    with app.app_context():
        products = Product.query.order_by(Product.created_at.desc()).all()
        
        if not products:
            print("Nenhum produto encontrado.")
            return
            
        print("\n{:<5} {:<30} {:<10} {:<15}".format("ID", "Título", "Preço", "Status"))
        print("-" * 70)
        
        for p in products:
            title = p.title[:27] + "..." if len(p.title) > 30 else p.title
            print("{:<5} {:<30} R${:<9.2f} {:<15}".format(
                p.id, title, p.price, p.status
            ))
        
        print(f"\nTotal: {len(products)} produtos")

def show_product(product_id):
    """Mostra detalhes de um produto específico"""
    with app.app_context():
        product = Product.query.get(product_id)
        
        if not product:
            print(f"Produto ID {product_id} não encontrado.")
            return
            
        print("\nDetalhes do Produto:")
        print("-" * 50)
        print(f"ID: {product.id}")
        print(f"Título: {product.title}")
        print(f"Descrição: {product.description}")
        print(f"Preço: R${product.price:.2f}")
        print(f"Categoria: {product.category}")
        print(f"Formato: {product.format_type}")
        print(f"Idioma: {product.language}")
        print(f"Arquivo: {product.file_name} ({product.file_size:.2f} MB)" if product.file_name else "Arquivo: Nenhum")
        print(f"Status: {product.status}")
        print(f"Tentativas: {product.upload_attempts}")
        
        if product.hotmart_id:
            print(f"ID Hotmart: {product.hotmart_id}")
            print(f"URL Hotmart: {product.hotmart_url}")
        
        if product.error_details:
            print(f"\nÚltimo erro: {product.error_details}")
        
        print(f"\nCriado em: {product.created_at.strftime('%d/%m/%Y %H:%M:%S')}")

def add_product():
    """Adiciona um novo produto ao sistema"""
    print("\nAdicionar Novo Produto:")
    print("-" * 50)
    
    title = input("Título: ")
    description = input("Descrição: ")
    
    try:
        price = float(input("Preço (R$): "))
    except ValueError:
        print("Preço inválido. Usando valor padrão de R$97.00")
        price = 97.0
    
    category = input("Categoria: ")
    format_type = input("Formato: ")
    language = input("Idioma [pt-BR]: ") or "pt-BR"
    file_path = input("Caminho completo do arquivo (opcional): ")
    
    with app.app_context():
        product = Product()
        product.title = title
        product.description = description
        product.price = price
        product.category = category
        product.format_type = format_type
        product.language = language
        product.status = 'pending'
        
        # Processar arquivo, se existir
        if file_path and os.path.exists(file_path):
            file_name = os.path.basename(file_path)
            file_size = os.path.getsize(file_path) / (1024 * 1024)  # MB
            
            # Criar diretório uploads se não existir
            upload_folder = os.path.join(app.root_path, 'uploads')
            if not os.path.exists(upload_folder):
                os.makedirs(upload_folder)
            
            # Copiar arquivo para diretório uploads
            dest_path = os.path.join(upload_folder, file_name)
            
            try:
                with open(file_path, 'rb') as src, open(dest_path, 'wb') as dst:
                    dst.write(src.read())
                
                product.file_path = dest_path
                product.file_name = file_name
                product.file_size = file_size
                
                print(f"Arquivo copiado para: {dest_path}")
            except Exception as e:
                print(f"Erro ao copiar arquivo: {str(e)}")
        elif file_path:
            print(f"Arquivo não encontrado: {file_path}")
        
        # Configurar estratégia de preço
        pricing_enabled = input("Habilitar desconto? (s/n): ").lower() == 's'
        
        pricing_strategy = {
            'base_price': price,
            'discount_enabled': pricing_enabled
        }
        
        if pricing_enabled:
            try:
                discount_value = float(input("Valor do desconto: "))
                discount_type = input("Tipo de desconto (percent/fixed) [percent]: ") or "percent"
                
                pricing_strategy['discount_value'] = discount_value
                pricing_strategy['discount_type'] = discount_type
            except ValueError:
                print("Valor de desconto inválido, desabilitando desconto.")
                pricing_strategy['discount_enabled'] = False
        
        installments_enabled = input("Habilitar parcelamento? (s/n): ").lower() == 's'
        pricing_strategy['installments_enabled'] = installments_enabled
        
        if installments_enabled:
            try:
                max_installments = int(input("Número máximo de parcelas [12]: ") or "12")
                pricing_strategy['max_installments'] = max_installments
            except ValueError:
                print("Número de parcelas inválido, usando 12 parcelas.")
                pricing_strategy['max_installments'] = 12
        
        product.pricing_strategy = pricing_strategy
        
        # Salvar no banco de dados
        db.session.add(product)
        db.session.commit()
        
        print(f"\nProduto '{title}' adicionado com sucesso! ID: {product.id}")

def create_upload_session():
    """Cria uma nova sessão de upload"""
    print("\nCriar Nova Sessão de Upload:")
    print("-" * 50)
    
    with app.app_context():
        # Listar produtos pendentes
        pending_products = Product.query.filter_by(status='pending').all()
        
        if not pending_products:
            print("Não há produtos pendentes para upload.")
            return
        
        print("\nProdutos Pendentes:")
        print("{:<5} {:<30}".format("ID", "Título"))
        print("-" * 40)
        
        for p in pending_products:
            title = p.title[:27] + "..." if len(p.title) > 30 else p.title
            print("{:<5} {:<30}".format(p.id, title))
        
        # Selecionar produtos
        product_ids = input("\nIDs dos produtos (separados por vírgula): ")
        product_ids = [int(pid.strip()) for pid in product_ids.split(",") if pid.strip().isdigit()]
        
        if not product_ids:
            print("Nenhum produto válido selecionado.")
            return
        
        # Configurações da sessão
        try:
            max_simultaneous = int(input("Máximo de uploads simultâneos [1]: ") or "1")
        except ValueError:
            print("Valor inválido, usando 1.")
            max_simultaneous = 1
        
        stealth_mode = input("Ativar modo stealth? (s/n) [s]: ").lower() != 'n'
        
        try:
            wait_between = int(input("Tempo de espera entre uploads (segundos) [30]: ") or "30")
        except ValueError:
            print("Valor inválido, usando 30 segundos.")
            wait_between = 30
        
        retry_failed = input("Tentar novamente em caso de falha? (s/n) [s]: ").lower() != 'n'
        
        try:
            max_retries = int(input("Máximo de tentativas [3]: ") or "3")
        except ValueError:
            print("Valor inválido, usando 3 tentativas.")
            max_retries = 3
        
        browser_profile = input("Perfil do navegador [default]: ") or "default"
        
        # Criar sessão
        session = UploadSession()
        session.status = 'active'
        session.start_time = datetime.datetime.utcnow()
        
        # Configurações da sessão
        config = {
            'max_simultaneous': max_simultaneous,
            'stealth_mode': stealth_mode,
            'wait_between': wait_between,
            'retry_failed': retry_failed,
            'max_retries': max_retries,
            'browser_profile': browser_profile
        }
        session.config = config
        
        db.session.add(session)
        db.session.commit()
        
        # Adicionar produtos selecionados
        for product_id in product_ids:
            product = Product.query.get(product_id)
            if product and product.status == 'pending':
                sp = SessionProduct()
                sp.session_id = session.id
                sp.product_id = product_id
                sp.status = 'pending'
                db.session.add(sp)
        
        # Atualizar contagem e salvar
        session.total_products = len(product_ids)
        db.session.commit()
        
        # Criar tarefa na fila
        task = TaskQueue()
        task.task_type = 'upload_session'
        task.priority = 10
        task.status = 'pending'
        task.payload = {'session_id': session.id}
        
        db.session.add(task)
        db.session.commit()
        
        print(f"\nSessão de upload criada com sucesso! ID: {session.id}")
        print(f"Produtos: {len(product_ids)}")
        print(f"Perfil do navegador: {browser_profile}")
        print(f"Modo stealth: {'Ativado' if stealth_mode else 'Desativado'}")
        print(f"Tarefa adicionada à fila com prioridade 10")

def list_sessions():
    """Lista todas as sessões de upload"""
    with app.app_context():
        sessions = UploadSession.query.order_by(UploadSession.created_at.desc()).all()
        
        if not sessions:
            print("Nenhuma sessão encontrada.")
            return
            
        print("\n{:<5} {:<20} {:<15} {:<10} {:<10}".format(
            "ID", "Data de Início", "Status", "Total", "Completos"))
        print("-" * 70)
        
        for s in sessions:
            start_time = s.start_time.strftime("%d/%m/%Y %H:%M") if s.start_time else "N/A"
            
            print("{:<5} {:<20} {:<15} {:<10} {:<10}".format(
                s.id, start_time, s.status, s.total_products, s.successful_uploads
            ))
        
        print(f"\nTotal: {len(sessions)} sessões")

def show_session(session_id):
    """Mostra detalhes de uma sessão específica"""
    with app.app_context():
        session = UploadSession.query.get(session_id)
        
        if not session:
            print(f"Sessão ID {session_id} não encontrada.")
            return
            
        print("\nDetalhes da Sessão:")
        print("-" * 50)
        print(f"ID: {session.id}")
        print(f"Status: {session.status}")
        print(f"Início: {session.start_time.strftime('%d/%m/%Y %H:%M:%S')}" if session.start_time else "Início: N/A")
        
        if session.end_time:
            print(f"Término: {session.end_time.strftime('%d/%m/%Y %H:%M:%S')}")
            duration = session.calculate_duration()
            if duration:
                minutes = duration // 60
                seconds = duration % 60
                print(f"Duração: {minutes}m {seconds}s")
        
        print(f"Total de produtos: {session.total_products}")
        print(f"Uploads com sucesso: {session.successful_uploads}")
        print(f"Uploads com falha: {session.failed_uploads}")
        
        if session.config:
            print("\nConfiguração:")
            print(f"Modo Stealth: {'Ativado' if session.config.get('stealth_mode') else 'Desativado'}")
            print(f"Uploads simultâneos: {session.config.get('max_simultaneous', 1)}")
            print(f"Tempo entre uploads: {session.config.get('wait_between', 30)}s")
            print(f"Tentar novamente em falhas: {'Sim' if session.config.get('retry_failed') else 'Não'}")
            print(f"Máximo de tentativas: {session.config.get('max_retries', 3)}")
            print(f"Perfil do navegador: {session.config.get('browser_profile', 'default')}")
        
        # Listar produtos da sessão
        products = db.session.query(Product, SessionProduct).join(
            SessionProduct, Product.id == SessionProduct.product_id
        ).filter(SessionProduct.session_id == session_id).all()
        
        if products:
            print("\nProdutos nesta sessão:")
            print("{:<5} {:<30} {:<15}".format("ID", "Título", "Status"))
            print("-" * 60)
            
            for p, sp in products:
                title = p.title[:27] + "..." if len(p.title) > 30 else p.title
                print("{:<5} {:<30} {:<15}".format(p.id, title, sp.status))

def configure_system():
    """Configura o sistema"""
    print("\nConfiguração do Sistema:")
    print("-" * 50)
    
    with app.app_context():
        # Carregar configurações existentes
        system_config = SystemConfig.query.filter_by(config_name='system_settings').first()
        if not system_config:
            system_config = SystemConfig()
            system_config.config_name = 'system_settings'
            system_config.config_value = {}
        
        openai_config = SystemConfig.query.filter_by(config_name='openai_settings').first()
        if not openai_config:
            openai_config = SystemConfig()
            openai_config.config_name = 'openai_settings'
            openai_config.config_value = {}
        
        # Configurações gerais
        print("\n1. Configurações Gerais:")
        
        operation_mode = input(f"Modo de operação [stealth/{system_config.config_value.get('operation_mode', 'stealth')}]: ") or system_config.config_value.get('operation_mode', 'stealth')
        
        proxy_enabled = input(f"Usar proxy? (s/n) [{'s' if system_config.config_value.get('proxy_enabled') else 'n'}]: ")
        if proxy_enabled.lower() in ('s', 'sim', 'y', 'yes'):
            proxy_enabled = True
            proxy_url = input(f"URL do proxy [{system_config.config_value.get('proxy_url', '')}]: ") or system_config.config_value.get('proxy_url', '')
        else:
            proxy_enabled = False
            proxy_url = system_config.config_value.get('proxy_url', '')
        
        try:
            default_wait_time = int(input(f"Tempo de espera padrão (segundos) [{system_config.config_value.get('default_wait_time', 30)}]: ") or system_config.config_value.get('default_wait_time', 30))
        except ValueError:
            print("Valor inválido, usando o valor anterior.")
            default_wait_time = system_config.config_value.get('default_wait_time', 30)
        
        auto_retry = input(f"Tentar novamente automaticamente? (s/n) [{'s' if system_config.config_value.get('auto_retry') else 'n'}]: ")
        auto_retry = auto_retry.lower() in ('s', 'sim', 'y', 'yes')
        
        try:
            max_retries = int(input(f"Máximo de tentativas [{system_config.config_value.get('max_retries', 3)}]: ") or system_config.config_value.get('max_retries', 3))
        except ValueError:
            print("Valor inválido, usando o valor anterior.")
            max_retries = system_config.config_value.get('max_retries', 3)
        
        # Configurações OpenAI
        print("\n2. Configurações da OpenAI:")
        
        openai_api_key = input(f"Chave API OpenAI [{'*****' if openai_config.config_value.get('api_key') else ''}]: ")
        if not openai_api_key and openai_config.config_value.get('api_key'):
            openai_api_key = openai_config.config_value.get('api_key')
        
        openai_model = input(f"Modelo OpenAI [{openai_config.config_value.get('model', 'gpt-4-vision-preview')}]: ") or openai_config.config_value.get('model', 'gpt-4-vision-preview')
        
        try:
            openai_max_tokens = int(input(f"Máximo de tokens [{openai_config.config_value.get('max_tokens', 4000)}]: ") or openai_config.config_value.get('max_tokens', 4000))
        except ValueError:
            print("Valor inválido, usando o valor anterior.")
            openai_max_tokens = openai_config.config_value.get('max_tokens', 4000)
        
        try:
            openai_temperature = float(input(f"Temperatura [{openai_config.config_value.get('temperature', 0.5)}]: ") or openai_config.config_value.get('temperature', 0.5))
        except ValueError:
            print("Valor inválido, usando o valor anterior.")
            openai_temperature = openai_config.config_value.get('temperature', 0.5)
        
        # Salvar configurações
        system_config.config_value = {
            'operation_mode': operation_mode,
            'proxy_enabled': proxy_enabled,
            'proxy_url': proxy_url,
            'default_wait_time': default_wait_time,
            'auto_retry': auto_retry,
            'max_retries': max_retries
        }
        
        openai_config.config_value = {
            'api_key': openai_api_key,
            'model': openai_model,
            'max_tokens': openai_max_tokens,
            'temperature': openai_temperature
        }
        
        db.session.add(system_config)
        db.session.add(openai_config)
        db.session.commit()
        
        print("\nConfigurações salvas com sucesso!")

def show_help():
    """Mostra a ajuda do sistema"""
    print("\nComandos disponíveis:")
    print("-" * 50)
    print("  login           - Autenticar no sistema")
    print("  register        - Registrar novo usuário")
    print("  products        - Listar todos os produtos")
    print("  product <id>    - Mostrar detalhes de um produto")
    print("  add-product     - Adicionar novo produto")
    print("  sessions        - Listar sessões de upload")
    print("  session <id>    - Mostrar detalhes de uma sessão")
    print("  new-session     - Criar nova sessão de upload")
    print("  configure       - Configurar o sistema")
    print("  help            - Mostrar esta ajuda")
    print("  exit            - Sair do sistema")

def main():
    """Função principal da CLI"""
    
    # Comando especial para inicializar o banco de dados
    if len(sys.argv) > 1 and sys.argv[1] == 'init-db':
        print("Iniciando banco de dados...")
        try:
            from app import db
            db.create_all()
            print("Banco de dados inicializado com sucesso!")
            return
        except Exception as e:
            print(f"Erro ao inicializar banco de dados: {str(e)}")
            return
    if len(sys.argv) > 1:
        # Modo de linha de comando
        parser = argparse.ArgumentParser(description='Hotmart Auto-Uploader CLI')
        subparsers = parser.add_subparsers(dest='command', help='Comando')
        
        # Login
        parser_login = subparsers.add_parser('login', help='Autenticar no sistema')
        
        # Register
        parser_register = subparsers.add_parser('register', help='Registrar novo usuário')
        
        # Products
        parser_products = subparsers.add_parser('products', help='Listar todos os produtos')
        
        # Product
        parser_product = subparsers.add_parser('product', help='Mostrar detalhes de um produto')
        parser_product.add_argument('id', type=int, help='ID do produto')
        
        # Add Product
        parser_add_product = subparsers.add_parser('add-product', help='Adicionar novo produto')
        
        # Sessions
        parser_sessions = subparsers.add_parser('sessions', help='Listar sessões de upload')
        
        # Session
        parser_session = subparsers.add_parser('session', help='Mostrar detalhes de uma sessão')
        parser_session.add_argument('id', type=int, help='ID da sessão')
        
        # New Session
        parser_new_session = subparsers.add_parser('new-session', help='Criar nova sessão de upload')
        
        # Configure
        parser_configure = subparsers.add_parser('configure', help='Configurar o sistema')
        
        # Parsear argumentos
        args = parser.parse_args()
        
        # Executar comando
        if args.command == 'login':
            authenticate()
        elif args.command == 'register':
            register_user()
        elif args.command == 'products':
            list_products()
        elif args.command == 'product':
            show_product(args.id)
        elif args.command == 'add-product':
            add_product()
        elif args.command == 'sessions':
            list_sessions()
        elif args.command == 'session':
            show_session(args.id)
        elif args.command == 'new-session':
            create_upload_session()
        elif args.command == 'configure':
            configure_system()
        else:
            parser.print_help()
    else:
        # Modo interativo
        user = None
        
        while True:
            if user is None:
                print("\n1. Login")
                print("2. Registrar")
                print("3. Sair")
                
                try:
                    choice = int(input("\nEscolha uma opção: "))
                    
                    if choice == 1:
                        user = authenticate()
                    elif choice == 2:
                        register_user()
                    elif choice == 3:
                        print("Saindo...")
                        break
                    else:
                        print("Opção inválida.")
                except ValueError:
                    print("Entrada inválida. Digite um número.")
                except KeyboardInterrupt:
                    print("\nOperação cancelada pelo usuário.")
                    break
            else:
                # Menu principal
                print("\nMenu Principal:")
                print("1. Produtos")
                print("2. Sessões de Upload")
                print("3. Configurações")
                print("4. Sair")
                
                try:
                    choice = int(input("\nEscolha uma opção: "))
                    
                    if choice == 1:
                        # Submenu Produtos
                        print("\nProdutos:")
                        print("1. Listar produtos")
                        print("2. Ver detalhes de um produto")
                        print("3. Adicionar novo produto")
                        print("4. Voltar")
                        
                        sub_choice = int(input("\nEscolha uma opção: "))
                        
                        if sub_choice == 1:
                            list_products()
                        elif sub_choice == 2:
                            try:
                                product_id = int(input("ID do produto: "))
                                show_product(product_id)
                            except ValueError:
                                print("ID inválido.")
                        elif sub_choice == 3:
                            add_product()
                        elif sub_choice == 4:
                            continue
                        else:
                            print("Opção inválida.")
                    
                    elif choice == 2:
                        # Submenu Sessões
                        print("\nSessões de Upload:")
                        print("1. Listar sessões")
                        print("2. Ver detalhes de uma sessão")
                        print("3. Criar nova sessão")
                        print("4. Voltar")
                        
                        sub_choice = int(input("\nEscolha uma opção: "))
                        
                        if sub_choice == 1:
                            list_sessions()
                        elif sub_choice == 2:
                            try:
                                session_id = int(input("ID da sessão: "))
                                show_session(session_id)
                            except ValueError:
                                print("ID inválido.")
                        elif sub_choice == 3:
                            create_upload_session()
                        elif sub_choice == 4:
                            continue
                        else:
                            print("Opção inválida.")
                    
                    elif choice == 3:
                        configure_system()
                    
                    elif choice == 4:
                        print("Saindo...")
                        break
                    
                    else:
                        print("Opção inválida.")
                
                except ValueError:
                    print("Entrada inválida. Digite um número.")
                except KeyboardInterrupt:
                    print("\nOperação cancelada pelo usuário.")
                    break

if __name__ == "__main__":
    main()