"""
Adaptive Intelligence Module
-------------------------
Fornece capacidades de adaptação e aprendizado para o navegador automatizado.
Este módulo é responsável por analisar a interface do site em tempo real,
detectar mudanças e adaptar o comportamento do navegador.
"""

import os
import base64
import logging
import json
import time
import re
from io import BytesIO
from PIL import Image
from typing import Dict, List, Any, Tuple, Optional, Union

from openai import OpenAI

# Configurar logger
logger = logging.getLogger(__name__)

class AdaptiveIntelligence:
    """
    Classe principal para lidar com inteligência adaptativa
    """
    
    def __init__(self, driver=None, config=None):
        """
        Inicializa a inteligência adaptativa
        
        Args:
            driver: Instância do WebDriver
            config: Configuração opcional
        """
        self.driver = driver
        self.config = config or {}
        self.api_key = os.environ.get("OPENAI_API_KEY")
        
        if not self.api_key:
            logger.warning("OPENAI_API_KEY não encontrada. A funcionalidade adaptativa será limitada.")
        
        self.client = OpenAI(api_key=self.api_key) if self.api_key else None
        self.hotmart_element_cache = {}
        self.previous_analyses = []
        self.adaptation_strategies = {}
        self.learn_count = 0
        
        # Carregar estratégias de adaptação já conhecidas
        self._load_adaptation_strategies()
        
    def _load_adaptation_strategies(self):
        """Carrega estratégias de adaptação existentes do arquivo de cache"""
        try:
            cache_file = 'data/adaptation_strategies.json'
            if os.path.exists(cache_file):
                with open(cache_file, 'r', encoding='utf-8') as f:
                    self.adaptation_strategies = json.load(f)
                logger.info(f"Carregadas {len(self.adaptation_strategies)} estratégias de adaptação")
        except Exception as e:
            logger.error(f"Erro ao carregar estratégias de adaptação: {e}")
            self.adaptation_strategies = {}
    
    def _save_adaptation_strategies(self):
        """Salva estratégias de adaptação aprendidas em arquivo de cache"""
        try:
            cache_file = 'data/adaptation_strategies.json'
            os.makedirs('data', exist_ok=True)
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(self.adaptation_strategies, f, ensure_ascii=False, indent=2)
            logger.info(f"Salvas {len(self.adaptation_strategies)} estratégias de adaptação")
        except Exception as e:
            logger.error(f"Erro ao salvar estratégias de adaptação: {e}")
    
    def set_driver(self, driver):
        """Define o WebDriver a ser usado"""
        self.driver = driver
    
    def analyze_page(self, context: str = "") -> Dict[str, Any]:
        """
        Analisa a página atual para identificar elementos e possíveis mudanças
        
        Args:
            context: Contexto adicional sobre o que está tentando fazer
            
        Returns:
            Dict com os resultados da análise
        """
        if not self.driver or not self.api_key:
            return {"success": False, "reason": "Driver ou API key não configurados"}
        
        try:
            # Capturar screenshot da página
            screenshot = self._capture_screenshot()
            
            # Obter HTML da página
            page_html = self.driver.page_source
            
            # Extrair apenas a estrutura importante (reduz tokens)
            simplified_html = self._simplify_html(page_html)
            
            # Analisar com OpenAI
            analysis = self._analyze_with_ai(screenshot, simplified_html, context)
            
            # Guardar análise para uso futuro
            self.previous_analyses.append({
                "timestamp": time.time(),
                "url": self.driver.current_url,
                "context": context,
                "analysis": analysis
            })
            
            return {
                "success": True,
                "analysis": analysis,
                "url": self.driver.current_url
            }
            
        except Exception as e:
            logger.error(f"Erro ao analisar página: {e}")
            return {"success": False, "reason": str(e)}
    
    def _capture_screenshot(self) -> str:
        """
        Captura screenshot da página atual
        
        Returns:
            String base64 da imagem
        """
        screenshot = self.driver.get_screenshot_as_png()
        img = Image.open(BytesIO(screenshot))
        
        # Redimensionar para economizar tamanho
        max_width = 1024
        if img.width > max_width:
            ratio = max_width / img.width
            new_size = (max_width, int(img.height * ratio))
            img = img.resize(new_size, Image.Resampling.LANCZOS)
        
        buffered = BytesIO()
        img.save(buffered, format="JPEG", quality=80)
        return base64.b64encode(buffered.getvalue()).decode("utf-8")
    
    def _simplify_html(self, html: str) -> str:
        """
        Simplifica o HTML para reduzir tokens
        
        Args:
            html: HTML completo da página
            
        Returns:
            HTML simplificado
        """
        # Remover scripts e styles inline
        html = re.sub(r'<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>', '', html)
        html = re.sub(r'<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>', '', html)
        
        # Remover comentários
        html = re.sub(r'<!--(.*?)-->', '', html)
        
        # Remover atributos data-
        html = re.sub(r' data-[^=]*="[^"]*"', '', html)
        
        # Remover classes longas
        html = re.sub(r'class="[^"]{50,}"', 'class="..."', html)
        
        # Extrair apenas o body
        body_match = re.search(r'<body[^>]*>(.*?)<\/body>', html, re.DOTALL)
        if body_match:
            html = body_match.group(1)
        
        return html
    
    def _analyze_with_ai(self, screenshot: str, html: str, context: str) -> Dict[str, Any]:
        """
        Analisa a página usando a API OpenAI
        
        Args:
            screenshot: Imagem da página em base64
            html: HTML simplificado
            context: Contexto da operação
            
        Returns:
            Resultados da análise
        """
        # Construir a mensagem para o modelo
        messages = [
            {
                "role": "system",
                "content": """Você é um assistente especializado em analisar interfaces web e identificar elementos.
                Estamos automatizando a navegação na plataforma Hotmart e precisamos identificar elementos
                mesmo que a interface mude. Analise a captura de tela e o HTML fornecidos,
                e identifique os elementos solicitados no contexto. Forneça seletores alternativos e estratégias
                para encontrar os elementos em caso de mudanças. Responda no formato JSON."""
            },
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": f"""Analise esta página da plataforma Hotmart.
                        Contexto da operação: {context}
                        
                        Preciso identificar:
                        1. Elementos principais visíveis na interface
                        2. Campos de formulário e seus rótulos
                        3. Botões e suas funções
                        4. Possíveis problemas ou obstáculos para automação
                        5. Sugestões de seletores robustos para os elementos principais
                        6. Se houver Shadow DOM, indique como acessá-lo

                        Responda em formato JSON com estas chaves:
                        - main_elements: lista de elementos principais com descrição e seletores
                        - form_fields: campos de formulário com rótulos e seletores
                        - buttons: botões com funções e seletores
                        - obstacles: possíveis obstáculos para automação
                        - shadow_dom: informações sobre Shadow DOM se presente
                        - alternative_strategies: abordagens alternativas se os seletores padrão falharem
                        
                        Trecho relevante do HTML:
                        {html[:5000]}... (truncado)
                        """
                    },
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{screenshot}"
                        }
                    }
                ]
            }
        ]
        
        try:
            # Chamar a API do OpenAI
            response = self.client.chat.completions.create(
                model="gpt-4o",  # o modelo mais recente que tem visão
                messages=messages,
                max_tokens=2000,
                response_format={"type": "json_object"}
            )
            
            # Extrair e analisar a resposta JSON
            result = json.loads(response.choices[0].message.content)
            return result
            
        except Exception as e:
            logger.error(f"Erro ao analisar com IA: {e}")
            return {
                "error": str(e),
                "main_elements": [],
                "form_fields": [],
                "buttons": [],
                "obstacles": ["Falha na análise de IA"],
                "shadow_dom": {},
                "alternative_strategies": []
            }
    
    def find_adaptive_element(self, element_description: str, context: str = "") -> Dict[str, Any]:
        """
        Encontra um elemento de forma adaptativa, mesmo se a interface mudou
        
        Args:
            element_description: Descrição do elemento a localizar
            context: Contexto da operação
            
        Returns:
            Dicionário com informações do elemento e estratégias de localização
        """
        # Verificar cache de estratégias para este elemento
        cache_key = f"{self.driver.current_url}:{element_description}"
        if cache_key in self.adaptation_strategies:
            logger.info(f"Usando estratégia em cache para: {element_description}")
            return self.adaptation_strategies[cache_key]
        
        # Analisar a página
        page_analysis = self.analyze_page(
            f"Buscando o elemento: {element_description}. Contexto: {context}"
        )
        
        if not page_analysis["success"]:
            logger.warning(f"Falha na análise adaptativa: {page_analysis['reason']}")
            return {"success": False, "reason": page_analysis["reason"]}
        
        # Buscar o elemento na análise
        element_info = self._extract_element_info(page_analysis["analysis"], element_description)
        
        # Se encontrou o elemento, adicionar ao cache
        if element_info["success"]:
            self.adaptation_strategies[cache_key] = element_info
            self._save_adaptation_strategies()
            
        return element_info
    
    def _extract_element_info(self, analysis: Dict[str, Any], element_description: str) -> Dict[str, Any]:
        """
        Extrai informações sobre um elemento específico da análise
        
        Args:
            analysis: Análise completa da página
            element_description: Descrição do elemento
            
        Returns:
            Informações do elemento
        """
        # Procurar nos elementos principais
        for element in analysis.get("main_elements", []):
            if self._description_matches(element.get("description", ""), element_description):
                return {
                    "success": True,
                    "element_type": "main",
                    "description": element.get("description", ""),
                    "selectors": element.get("selectors", []),
                    "alternatives": analysis.get("alternative_strategies", [])
                }
        
        # Procurar nos campos de formulário
        for field in analysis.get("form_fields", []):
            if self._description_matches(field.get("label", ""), element_description):
                return {
                    "success": True,
                    "element_type": "form_field",
                    "description": field.get("label", ""),
                    "selectors": field.get("selectors", []),
                    "field_type": field.get("type", "text"),
                    "alternatives": analysis.get("alternative_strategies", [])
                }
        
        # Procurar nos botões
        for button in analysis.get("buttons", []):
            if self._description_matches(button.get("function", ""), element_description):
                return {
                    "success": True,
                    "element_type": "button",
                    "description": button.get("function", ""),
                    "selectors": button.get("selectors", []),
                    "alternatives": analysis.get("alternative_strategies", [])
                }
        
        # Não encontrou o elemento
        return {
            "success": False,
            "reason": f"Elemento não encontrado: {element_description}",
            "alternatives": analysis.get("alternative_strategies", [])
        }
    
    def _description_matches(self, description: str, target: str) -> bool:
        """
        Verifica se a descrição corresponde ao elemento alvo
        
        Args:
            description: Descrição encontrada
            target: Elemento alvo
            
        Returns:
            Bool indicando se corresponde
        """
        description = description.lower()
        target = target.lower()
        
        # Correspondência exata ou parcial
        if target in description or description in target:
            return True
        
        # Calcular similaridade (simplificado)
        words_desc = set(description.split())
        words_target = set(target.split())
        common_words = words_desc.intersection(words_target)
        
        # Se mais de 50% das palavras coincidem, considerar uma correspondência
        if len(common_words) >= 0.5 * min(len(words_desc), len(words_target)):
            return True
            
        return False
    
    def adapt_to_changes(self, expected_element: str, context: str) -> Dict[str, Any]:
        """
        Adapta-se às mudanças na interface, tentando encontrar o elemento esperado
        
        Args:
            expected_element: Elemento que esperamos encontrar
            context: Contexto da operação
            
        Returns:
            Estratégia de adaptação
        """
        logger.info(f"Adaptando a mudanças para encontrar: {expected_element}")
        
        # Encontrar o elemento de forma adaptativa
        element_info = self.find_adaptive_element(expected_element, context)
        
        if not element_info["success"]:
            # Temos alternativas?
            if element_info.get("alternatives"):
                logger.info(f"Elemento não encontrado, mas temos {len(element_info['alternatives'])} alternativas")
                return {
                    "success": True,
                    "adaptation_required": True,
                    "strategies": element_info.get("alternatives", [])
                }
            else:
                return {"success": False, "reason": element_info["reason"]}
        
        # Elemento encontrado, retornar suas informações
        return {
            "success": True,
            "adaptation_required": False,
            "element_info": element_info
        }
    
    def learn_from_success(self, element_description: str, successful_selector: str, context: str) -> None:
        """
        Aprende com sucessos para futuras adaptações
        
        Args:
            element_description: Descrição do elemento
            successful_selector: Seletor que funcionou
            context: Contexto da operação
        """
        cache_key = f"{self.driver.current_url}:{element_description}"
        
        # Atualizar ou criar estratégia
        strategy = self.adaptation_strategies.get(cache_key, {
            "success": True,
            "element_type": "learned",
            "description": element_description,
            "selectors": [],
            "alternatives": []
        })
        
        # Adicionar o seletor bem-sucedido
        if successful_selector not in strategy["selectors"]:
            strategy["selectors"].insert(0, successful_selector)  # Priorizar este seletor
            
        # Atualizar o cache
        self.adaptation_strategies[cache_key] = strategy
        
        # Incrementar contador de aprendizado
        self.learn_count += 1
        
        # Salvar a cada 5 aprendizados
        if self.learn_count % 5 == 0:
            self._save_adaptation_strategies()
            
        logger.info(f"Aprendeu seletor para '{element_description}': {successful_selector}")
    
    def learn_from_failure(self, element_description: str, failed_selector: str, context: str) -> None:
        """
        Aprende com falhas para evitar repetir os mesmos erros
        
        Args:
            element_description: Descrição do elemento
            failed_selector: Seletor que falhou
            context: Contexto da operação
        """
        cache_key = f"{self.driver.current_url}:{element_description}"
        
        # Atualizar ou criar estratégia
        strategy = self.adaptation_strategies.get(cache_key, {
            "success": False,
            "element_type": "failed",
            "description": element_description,
            "selectors": [],
            "failed_selectors": [],
            "alternatives": []
        })
        
        # Adicionar à lista de seletores que falharam
        if "failed_selectors" not in strategy:
            strategy["failed_selectors"] = []
            
        if failed_selector not in strategy["failed_selectors"]:
            strategy["failed_selectors"].append(failed_selector)
            
        # Tentar fornecer alternativas
        if not strategy.get("alternatives"):
            try:
                # Analisar a página para obter alternativas
                page_analysis = self.analyze_page(
                    f"O seletor '{failed_selector}' falhou para o elemento '{element_description}'. "
                    f"Preciso de alternativas. Contexto: {context}"
                )
                
                if page_analysis["success"]:
                    strategy["alternatives"] = page_analysis["analysis"].get("alternative_strategies", [])
            except Exception as e:
                logger.error(f"Erro ao gerar alternativas para seletor falho: {e}")
        
        # Atualizar o cache
        self.adaptation_strategies[cache_key] = strategy
        
        # Salvar cache
        self._save_adaptation_strategies()
            
        logger.info(f"Registrou falha de seletor para '{element_description}': {failed_selector}")
    
    def suggest_fixes(self, error_message: str, context: str) -> Dict[str, Any]:
        """
        Sugere correções para erros durante a automação
        
        Args:
            error_message: Mensagem de erro encontrada
            context: Contexto da operação
            
        Returns:
            Sugestões de correção
        """
        if not self.api_key:
            return {"success": False, "reason": "API key não configurada"}
        
        try:
            # Capturar screenshot do estado atual
            screenshot = self._capture_screenshot()
            
            # Preparar mensagem para a API
            messages = [
                {
                    "role": "system",
                    "content": """Você é um especialista em automação web. 
                    Ajude a resolver problemas em um script de automação da plataforma Hotmart.
                    Analise o erro, a captura de tela e o contexto para sugerir correções."""
                },
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": f"""Encontrei este erro durante a automação:
                            
                            Erro: {error_message}
                            
                            Contexto da operação: {context}
                            
                            Por favor, sugira:
                            1. Possíveis causas do erro
                            2. Soluções alternativas
                            3. Abordagens para tornar a automação mais robusta neste cenário
                            
                            Responda em formato JSON com estas chaves:
                            - possible_causes: lista de possíveis causas
                            - solutions: lista de soluções detalhadas
                            - robust_approaches: abordagens para aumentar robustez
                            - selector_alternatives: seletores alternativos se for um problema de localização
                            """
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{screenshot}"
                            }
                        }
                    ]
                }
            ]
            
            # Chamar a API do OpenAI
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=messages,
                max_tokens=1500,
                response_format={"type": "json_object"}
            )
            
            # Extrair e analisar a resposta JSON
            result = json.loads(response.choices[0].message.content)
            return {
                "success": True,
                "fixes": result
            }
            
        except Exception as e:
            logger.error(f"Erro ao sugerir correções: {e}")
            return {"success": False, "reason": str(e)}
    
    def handle_shadow_dom(self, shadow_host_selector: str) -> Dict[str, Any]:
        """
        Lida com elementos dentro de Shadow DOM
        
        Args:
            shadow_host_selector: Seletor do host do Shadow DOM
            
        Returns:
            Informações sobre o Shadow DOM
        """
        if not self.driver:
            return {"success": False, "reason": "Driver não configurado"}
        
        try:
            # Tentar encontrar o host do Shadow DOM
            host_element = self.driver.find_element_by_css_selector(shadow_host_selector)
            
            # Obter o Shadow Root
            shadow_root = self.driver.execute_script("return arguments[0].shadowRoot", host_element)
            
            if not shadow_root:
                return {"success": False, "reason": "Shadow Root não acessível"}
            
            # Obter HTML dentro do Shadow DOM
            shadow_html = self.driver.execute_script("return arguments[0].innerHTML", shadow_root)
            
            # Analisar com IA
            if self.api_key:
                response = self.client.chat.completions.create(
                    model="gpt-4o",
                    messages=[
                        {"role": "system", "content": "Analise este conteúdo de Shadow DOM e identifique elementos importantes."},
                        {"role": "user", "content": f"HTML do Shadow DOM:\n{shadow_html[:5000]}... (truncado)"}
                    ],
                    max_tokens=1000,
                    response_format={"type": "json_object"}
                )
                shadow_analysis = json.loads(response.choices[0].message.content)
            else:
                shadow_analysis = {"elements": [], "note": "Análise detalhada indisponível sem API key"}
            
            return {
                "success": True,
                "shadow_host": shadow_host_selector,
                "shadow_html": shadow_html[:1000] + "... (truncado)",
                "analysis": shadow_analysis
            }
            
        except Exception as e:
            logger.error(f"Erro ao lidar com Shadow DOM: {e}")
            return {"success": False, "reason": str(e)}

# Função para criar uma instância pré-configurada
def create_adaptive_intelligence(driver=None):
    """
    Cria uma instância de AdaptiveIntelligence pré-configurada
    
    Args:
        driver: WebDriver opcional
        
    Returns:
        Instância configurada de AdaptiveIntelligence
    """
    return AdaptiveIntelligence(driver=driver)