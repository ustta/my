import random
import time
import logging
import string
import json
import math
from typing import List, Dict, Any, Optional, Tuple, Union, Callable
import datetime

# Configurando logger
logger = logging.getLogger(__name__)

class HumanSimulator:
    """
    Simulador de comportamento humano para navegação realista
    
    Esta classe é responsável por simular movimentos de mouse, digitação,
    seleção de elementos e outras interações típicas de usuários humanos
    para evitar detecção por sistemas anti-bot.
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Inicializa o simulador de comportamento humano
        
        Args:
            config: Configurações opcionais para o simulador
        """
        self.config = config or {}
        
        # Perfil de comportamento
        self.typing_speed = self.config.get('typing_speed', 'normal')  # slow, normal, fast
        self.movement_style = self.config.get('movement_style', 'natural')  # natural, direct, hesitant
        self.error_rate = self.config.get('error_rate', 0.05)  # Taxa de erros de digitação (0.0 a 1.0)
        self.hesitation_factor = self.config.get('hesitation_factor', 0.2)  # Fator de hesitação (0.0 a 1.0)
        
        # Intervalo entre ações (segundos)
        self.delay_min = self.config.get('delay_min', 0.8)
        self.delay_max = self.config.get('delay_max', 3.0)
        
        # Histórico de ações para análise de padrões
        self.action_history = []
        self.session_start_time = datetime.datetime.now()
        
        # Carregar perfis comportamentais se existirem
        self.behavior_profiles = self._load_behavior_profiles()
        
        # Se um perfil específico foi solicitado
        profile_name = self.config.get('profile')
        if profile_name and profile_name in self.behavior_profiles:
            self._apply_profile(profile_name)
        else:
            # Usar perfil aleatório ou personalizado
            if self.config.get('random_profile', False) and self.behavior_profiles:
                random_profile = random.choice(list(self.behavior_profiles.keys()))
                self._apply_profile(random_profile)
    
    def _load_behavior_profiles(self) -> Dict[str, Dict[str, Any]]:
        """
        Carrega perfis comportamentais predefinidos
        
        Returns:
            Dicionário de perfis
        """
        profiles = {
            "casual_user": {
                "typing_speed": "normal",
                "movement_style": "natural",
                "error_rate": 0.08,
                "hesitation_factor": 0.3,
                "delay_min": 1.0,
                "delay_max": 4.0
            },
            "professional": {
                "typing_speed": "fast",
                "movement_style": "direct",
                "error_rate": 0.02,
                "hesitation_factor": 0.1,
                "delay_min": 0.5,
                "delay_max": 2.0
            },
            "beginner": {
                "typing_speed": "slow",
                "movement_style": "hesitant",
                "error_rate": 0.15,
                "hesitation_factor": 0.5,
                "delay_min": 2.0,
                "delay_max": 7.0
            },
            "elderly": {
                "typing_speed": "slow",
                "movement_style": "hesitant",
                "error_rate": 0.2,
                "hesitation_factor": 0.6,
                "delay_min": 2.5,
                "delay_max": 8.0
            },
            "mobile_user": {
                "typing_speed": "slow",
                "movement_style": "direct",
                "error_rate": 0.12,
                "hesitation_factor": 0.25,
                "delay_min": 1.5,
                "delay_max": 5.0
            }
        }
        
        # Tentar carregar perfis personalizados de arquivo
        try:
            custom_profiles_path = self.config.get('custom_profiles_path', 'config/behavior_profiles.json')
            with open(custom_profiles_path, 'r') as f:
                custom_profiles = json.load(f)
                profiles.update(custom_profiles)
        except:
            logger.debug("Nenhum perfil personalizado encontrado")
        
        return profiles
    
    def _apply_profile(self, profile_name: str) -> None:
        """
        Aplica um perfil comportamental predefinido
        
        Args:
            profile_name: Nome do perfil a ser aplicado
        """
        if profile_name not in self.behavior_profiles:
            logger.warning(f"Perfil comportamental '{profile_name}' não encontrado")
            return
        
        profile = self.behavior_profiles[profile_name]
        
        self.typing_speed = profile.get('typing_speed', self.typing_speed)
        self.movement_style = profile.get('movement_style', self.movement_style)
        self.error_rate = profile.get('error_rate', self.error_rate)
        self.hesitation_factor = profile.get('hesitation_factor', self.hesitation_factor)
        self.delay_min = profile.get('delay_min', self.delay_min)
        self.delay_max = profile.get('delay_max', self.delay_max)
        
        logger.debug(f"Perfil comportamental '{profile_name}' aplicado")
    
    def wait_random(self, min_seconds: Optional[float] = None, max_seconds: Optional[float] = None) -> float:
        """
        Aguarda um tempo aleatório entre operações
        
        Args:
            min_seconds: Tempo mínimo em segundos (opcional)
            max_seconds: Tempo máximo em segundos (opcional)
            
        Returns:
            Tempo aguardado em segundos
        """
        min_secs = min_seconds if min_seconds is not None else self.delay_min
        max_secs = max_seconds if max_seconds is not None else self.delay_max
        
        # Adicionar variação com base no fator de hesitação
        if random.random() < self.hesitation_factor:
            max_secs = max_secs * (1 + self.hesitation_factor)
        
        wait_time = random.uniform(min_secs, max_secs)
        time.sleep(wait_time)
        
        # Registrar ação
        self.action_history.append({
            'action': 'wait',
            'duration': wait_time,
            'timestamp': datetime.datetime.now().isoformat()
        })
        
        return wait_time
    
    def type_text(self, text: str, element=None, min_delay: Optional[float] = None, max_delay: Optional[float] = None) -> str:
        """
        Simula digitação humana com velocidade variável e possíveis erros
        
        Args:
            text: Texto a ser digitado
            element: Elemento onde digitar (opcional, dependendo da implementação)
            min_delay: Tempo mínimo entre teclas em segundos (opcional)
            max_delay: Tempo máximo entre teclas em segundos (opcional)
            
        Returns:
            Texto efetivamente digitado (pode conter erros intencionais)
        """
        # Determinar velocidade de digitação
        if self.typing_speed == 'slow':
            min_d = min_delay if min_delay is not None else 0.1
            max_d = max_delay if max_delay is not None else 0.4
        elif self.typing_speed == 'fast':
            min_d = min_delay if min_delay is not None else 0.03
            max_d = max_delay if max_delay is not None else 0.1
        else:  # normal
            min_d = min_delay if min_delay is not None else 0.05
            max_d = max_delay if max_delay is not None else 0.2
        
        result_text = ""
        for char in text:
            # Simular erros ocasionais de digitação
            if random.random() < self.error_rate:
                # Tipos de erros: tecla errada, tecla extra, tecla faltante
                error_type = random.choice(['wrong', 'extra', 'missing'])
                
                if error_type == 'wrong':
                    # Digitar tecla errada e depois corrigir
                    adjacent_keys = self._get_adjacent_keys(char)
                    wrong_char = random.choice(adjacent_keys) if adjacent_keys else char
                    
                    if element is not None:
                        element.send_keys(wrong_char)
                        time.sleep(random.uniform(0.1, 0.5))  # Pequena pausa antes de corrigir
                        element.send_keys('\b')  # Backspace
                        element.send_keys(char)
                    
                    # Adicionar o caractere correto ao resultado
                    result_text += char
                    
                elif error_type == 'extra':
                    # Digitar tecla extra e corrigir
                    adjacent_keys = self._get_adjacent_keys(char)
                    extra_char = random.choice(adjacent_keys) if adjacent_keys else char
                    
                    if element is not None:
                        element.send_keys(extra_char)
                        time.sleep(random.uniform(0.1, 0.3))
                        element.send_keys('\b')  # Backspace
                        element.send_keys(char)
                    
                    # Adicionar o caractere correto ao resultado
                    result_text += char
                    
                elif error_type == 'missing':
                    # Continuar sem digitar uma tecla, depois perceber e corrigir
                    if element is not None:
                        # Continuar para a próxima tecla
                        time.sleep(random.uniform(min_d, max_d))
                        # Perceber o erro e voltar para digitar
                        time.sleep(random.uniform(0.5, 1.5))
                        element.send_keys(char)
                    
                    # Adicionar o caractere ao resultado
                    result_text += char
            else:
                # Digitação normal
                if element is not None:
                    element.send_keys(char)
                result_text += char
            
            # Pausa variável entre teclas
            time.sleep(random.uniform(min_d, max_d))
            
            # Pausa maior para alguns caracteres (ponto, vírgula, etc)
            if char in '.,;:?!':
                time.sleep(random.uniform(0.1, 0.5))
        
        # Registrar ação
        self.action_history.append({
            'action': 'type',
            'text_length': len(text),
            'timestamp': datetime.datetime.now().isoformat()
        })
        
        return result_text
    
    def _get_adjacent_keys(self, char: str) -> List[str]:
        """
        Retorna teclas adjacentes no teclado para simular erros realistas
        
        Args:
            char: Caractere de referência
            
        Returns:
            Lista de caracteres adjacentes
        """
        keyboard_layout = {
            'q': ['w', 'a', '1', '2'],
            'w': ['q', 'e', 'a', 's', '2', '3'],
            'e': ['w', 'r', 's', 'd', '3', '4'],
            'r': ['e', 't', 'd', 'f', '4', '5'],
            't': ['r', 'y', 'f', 'g', '5', '6'],
            'y': ['t', 'u', 'g', 'h', '6', '7'],
            'u': ['y', 'i', 'h', 'j', '7', '8'],
            'i': ['u', 'o', 'j', 'k', '8', '9'],
            'o': ['i', 'p', 'k', 'l', '9', '0'],
            'p': ['o', 'l', '0', '-', '['],
            'a': ['q', 'w', 's', 'z'],
            's': ['w', 'e', 'a', 'd', 'z', 'x'],
            'd': ['e', 'r', 's', 'f', 'x', 'c'],
            'f': ['r', 't', 'd', 'g', 'c', 'v'],
            'g': ['t', 'y', 'f', 'h', 'v', 'b'],
            'h': ['y', 'u', 'g', 'j', 'b', 'n'],
            'j': ['u', 'i', 'h', 'k', 'n', 'm'],
            'k': ['i', 'o', 'j', 'l', 'm', ','],
            'l': ['o', 'p', 'k', ';', ',', '.'],
            'z': ['a', 's', 'x'],
            'x': ['z', 's', 'd', 'c'],
            'c': ['x', 'd', 'f', 'v'],
            'v': ['c', 'f', 'g', 'b'],
            'b': ['v', 'g', 'h', 'n'],
            'n': ['b', 'h', 'j', 'm'],
            'm': ['n', 'j', 'k', ','],
            ',': ['m', 'k', 'l', '.'],
            '.': [',', 'l', '/'],
            '1': ['q', '2'],
            '2': ['1', 'q', 'w', '3'],
            '3': ['2', 'w', 'e', '4'],
            '4': ['3', 'e', 'r', '5'],
            '5': ['4', 'r', 't', '6'],
            '6': ['5', 't', 'y', '7'],
            '7': ['6', 'y', 'u', '8'],
            '8': ['7', 'u', 'i', '9'],
            '9': ['8', 'i', 'o', '0'],
            '0': ['9', 'o', 'p', '-'],
            '-': ['0', 'p', '='],
            '=': ['-', '[', ']'],
            '[': ['p', ']', '='],
            ']': ['[', '\\'],
            '\\': [']'],
            ';': ['l', "'"],
            "'": [';', '\\'],
            '/': ['.', "'"]
        }
        
        char = char.lower()
        if char in keyboard_layout:
            return keyboard_layout[char]
        return []
    
    def move_to_element(self, element=None, x: Optional[int] = None, y: Optional[int] = None) -> Tuple[int, int]:
        """
        Simula movimento de mouse natural para um elemento
        
        Args:
            element: Elemento alvo (opcional, dependendo da implementação)
            x: Coordenada X opcional
            y: Coordenada Y opcional
            
        Returns:
            Tupla (x, y) com as coordenadas finais
        """
        # Obter posição do elemento, se fornecido
        target_x = x if x is not None else 0
        target_y = y if y is not None else 0
        
        if element is not None:
            # Normalmente aqui usaríamos element.location para obter a posição
            # Como estamos simulando, usamos valores fictícios se x,y não foram fornecidos
            if x is None or y is None:
                target_x = random.randint(100, 1000)
                target_y = random.randint(100, 700)
        
        # Simular movimento conforme estilo configurado
        if self.movement_style == 'direct':
            # Movimento direto com velocidade variável
            move_duration = random.uniform(0.2, 0.8)
            # Aqui seria implementado o movimento real
            time.sleep(move_duration)
            
        elif self.movement_style == 'hesitant':
            # Movimento hesitante com pausas e mudanças de direção
            move_duration = random.uniform(0.5, 2.0)
            num_points = random.randint(3, 8)
            
            for i in range(num_points):
                # Simular pausa durante o movimento
                time.sleep(move_duration / num_points)
                
                # Simular mudança leve de direção
                if random.random() < 0.3:
                    time.sleep(random.uniform(0.1, 0.5))
                
        else:  # 'natural'
            # Movimento natural com curva e aceleração/desaceleração
            move_duration = random.uniform(0.3, 1.2)
            
            # Simular pontos da curva de bezier para movimento natural
            num_points = random.randint(5, 15)
            for i in range(num_points):
                t = i / (num_points - 1)
                
                # Simular aceleração/desaceleração - mais lento no início e fim
                if t < 0.2 or t > 0.8:
                    multiplier = 0.7
                else:
                    multiplier = 1.3
                    
                time.sleep((move_duration / num_points) * multiplier)
        
        # Pequeno ajuste final
        if random.random() < 0.3:
            time.sleep(random.uniform(0.05, 0.15))
        
        # Registrar ação
        self.action_history.append({
            'action': 'move',
            'target_x': target_x,
            'target_y': target_y,
            'style': self.movement_style,
            'timestamp': datetime.datetime.now().isoformat()
        })
        
        return (target_x, target_y)
    
    def click_element(self, element=None, right_click: bool = False, double_click: bool = False) -> None:
        """
        Simula um clique de mouse humano em um elemento
        
        Args:
            element: Elemento a ser clicado (opcional, dependendo da implementação)
            right_click: Se True, realiza clique direito em vez de esquerdo
            double_click: Se True, realiza duplo clique
        """
        # Pequena pausa antes do clique
        time.sleep(random.uniform(0.05, 0.2))
        
        if element is not None:
            # Aqui seria implementado o clique real no elemento
            pass
        
        # Simular clique
        if double_click:
            time.sleep(random.uniform(0.08, 0.15))  # Tempo entre cliques
            
        # Pequena pausa após o clique
        time.sleep(random.uniform(0.05, 0.2))
        
        # Registrar ação
        click_type = "right" if right_click else "left"
        click_count = 2 if double_click else 1
        self.action_history.append({
            'action': 'click',
            'type': click_type,
            'count': click_count,
            'timestamp': datetime.datetime.now().isoformat()
        })
    
    def scroll_page(self, direction: str = 'down', distance: Optional[int] = None, speed: Optional[str] = None) -> int:
        """
        Simula rolagem de página natural
        
        Args:
            direction: Direção da rolagem ('up', 'down', 'left', 'right')
            distance: Distância a rolar em pixels (opcional)
            speed: Velocidade da rolagem ('slow', 'normal', 'fast') (opcional)
            
        Returns:
            Distância efetivamente rolada em pixels
        """
        # Determinar velocidade e distância
        if speed is None:
            speed_options = ['slow', 'normal', 'fast']
            weights = [0.2, 0.6, 0.2]  # Probabilidade de cada velocidade
            speed = random.choices(speed_options, weights=weights, k=1)[0]
        
        if distance is None:
            if direction in ['up', 'down']:
                # Rolagem vertical típica
                if speed == 'slow':
                    distance = random.randint(100, 300)
                elif speed == 'fast':
                    distance = random.randint(400, 1200)
                else:  # normal
                    distance = random.randint(250, 700)
            else:
                # Rolagem horizontal (normalmente menor)
                if speed == 'slow':
                    distance = random.randint(50, 150)
                elif speed == 'fast':
                    distance = random.randint(200, 500)
                else:  # normal
                    distance = random.randint(100, 300)
        
        # Determinar duração com base na velocidade
        if speed == 'slow':
            duration = random.uniform(0.8, 2.0)
        elif speed == 'fast':
            duration = random.uniform(0.2, 0.6)
        else:  # normal
            duration = random.uniform(0.4, 1.2)
        
        # Aplicar direção (valor positivo/negativo)
        if direction in ['up', 'left']:
            distance = -distance
        
        # Simular rolagem gradual
        steps = random.randint(4, 12)
        for i in range(steps):
            step_distance = distance / steps
            # Aqui seria implementada a rolagem real
            
            step_time = duration / steps
            
            # Variação na velocidade para parecer mais natural
            if i < steps / 4 or i > 3 * steps / 4:
                # Mais lento no início e fim
                step_time *= random.uniform(1.2, 1.5)
            
            time.sleep(step_time)
        
        # Pequena pausa após rolagem
        time.sleep(random.uniform(0.2, 1.0))
        
        # Registrar ação
        self.action_history.append({
            'action': 'scroll',
            'direction': direction,
            'distance': distance,
            'speed': speed,
            'timestamp': datetime.datetime.now().isoformat()
        })
        
        return distance
    
    def select_option(self, element=None, options=None, index: Optional[int] = None) -> Any:
        """
        Simula seleção natural de uma opção em um dropdown ou lista
        
        Args:
            element: Elemento select/dropdown (opcional, dependendo da implementação)
            options: Lista de opções disponíveis (opcional)
            index: Índice da opção a selecionar (opcional)
            
        Returns:
            Opção selecionada
        """
        # Simular hesitação antes de selecionar
        time.sleep(random.uniform(0.5, 2.0))
        
        # Se não foi especificado um índice, escolher aleatoriamente
        if index is None and options:
            index = random.randint(0, len(options) - 1)
        
        # Simulação de movimento sobre as opções antes de selecionar
        if options and random.random() < 0.7:
            # Simular verificação de algumas opções antes da seleção final
            num_checks = random.randint(1, min(3, len(options)))
            check_indices = random.sample(range(len(options)), num_checks)
            
            for check_idx in check_indices:
                if check_idx != index:
                    # Simular movimento para opção que não é a final
                    self.move_to_element()
                    time.sleep(random.uniform(0.2, 0.8))
        
        # Simular seleção da opção final
        selected_option = options[index] if options and index is not None else None
        
        if element is not None:
            # Aqui seria implementada a seleção real da opção
            pass
        
        # Pequena pausa após seleção
        time.sleep(random.uniform(0.2, 0.8))
        
        # Registrar ação
        self.action_history.append({
            'action': 'select',
            'selected_index': index,
            'timestamp': datetime.datetime.now().isoformat()
        })
        
        return selected_option
    
    def interact_with_page(self, interactions: Optional[List[str]] = None, count: Optional[int] = None) -> None:
        """
        Simula interações aleatórias com a página para parecer natural
        
        Args:
            interactions: Lista de tipos de interação ('scroll', 'move', 'click', etc.)
            count: Número de interações a realizar
        """
        if not interactions:
            interactions = ['scroll', 'move', 'pause', 'move_and_pause']
        
        if count is None:
            count = random.randint(2, 6)
        
        for _ in range(count):
            interaction = random.choice(interactions)
            
            if interaction == 'scroll':
                self.scroll_page()
            elif interaction == 'move':
                self.move_to_element()
            elif interaction == 'pause':
                self.wait_random(1.0, 5.0)
            elif interaction == 'move_and_pause':
                self.move_to_element()
                self.wait_random(0.5, 3.0)
            
            # Pequena pausa entre interações
            self.wait_random(0.3, 1.2)
    
    def simulate_form_filling(self, form_data: Dict[str, Any], elements: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Simula preenchimento natural de um formulário
        
        Args:
            form_data: Dicionário com dados do formulário
            elements: Dicionário de elementos do formulário (opcional)
            
        Returns:
            Dicionário com dados efetivamente preenchidos
        """
        filled_data = {}
        
        # Simular navegação entre campos do formulário
        fields = list(form_data.keys())
        
        # Ocasionalmente preencher em ordem não sequencial
        if random.random() < 0.3:
            random.shuffle(fields)
        
        for field in fields:
            # Simular movimento para o campo
            field_element = elements.get(field) if elements else None
            self.move_to_element(field_element)
            
            # Simular clique no campo
            self.click_element(field_element)
            
            # Preencher campo conforme tipo de dado
            value = form_data[field]
            
            if isinstance(value, str):
                # Campo de texto
                filled_text = self.type_text(value, field_element)
                filled_data[field] = filled_text
                
            elif isinstance(value, bool):
                # Checkbox
                if value:
                    self.click_element(field_element)
                filled_data[field] = value
                
            elif isinstance(value, (list, tuple)):
                # Select/dropdown
                selected = self.select_option(field_element, value)
                filled_data[field] = selected
            
            # Pequena pausa entre campos
            self.wait_random()
        
        # Registrar ação
        self.action_history.append({
            'action': 'form_fill',
            'fields_count': len(fields),
            'timestamp': datetime.datetime.now().isoformat()
        })
        
        return filled_data
    
    def get_action_pattern_analysis(self) -> Dict[str, Any]:
        """
        Analisa padrões nas ações realizadas para garantir naturalidade
        
        Returns:
            Dicionário com análise dos padrões de ação
        """
        analysis = {
            'total_actions': len(self.action_history),
            'session_duration': (datetime.datetime.now() - self.session_start_time).total_seconds(),
            'action_counts': {},
            'timing_analysis': {
                'avg_wait_time': 0,
                'avg_between_actions': 0
            }
        }
        
        # Contar tipos de ações
        for action in self.action_history:
            action_type = action['action']
            analysis['action_counts'][action_type] = analysis['action_counts'].get(action_type, 0) + 1
        
        # Análise de tempos
        wait_times = [a['duration'] for a in self.action_history if a['action'] == 'wait']
        if wait_times:
            analysis['timing_analysis']['avg_wait_time'] = sum(wait_times) / len(wait_times)
        
        # Calcular tempos entre ações consecutivas
        if len(self.action_history) > 1:
            between_times = []
            for i in range(1, len(self.action_history)):
                prev_time = datetime.datetime.fromisoformat(self.action_history[i-1]['timestamp'])
                curr_time = datetime.datetime.fromisoformat(self.action_history[i]['timestamp'])
                between_times.append((curr_time - prev_time).total_seconds())
            
            if between_times:
                analysis['timing_analysis']['avg_between_actions'] = sum(between_times) / len(between_times)
        
        return analysis
    
    def adapt_behavior(self, detection_risk: float) -> None:
        """
        Adapta o comportamento com base no risco de detecção
        
        Args:
            detection_risk: Nível de risco de detecção (0.0 a 1.0)
        """
        if detection_risk > 0.8:
            # Alto risco - tornar comportamento muito mais humano
            self.delay_min *= 1.5
            self.delay_max *= 1.8
            self.error_rate = max(0.1, self.error_rate * 1.5)
            self.hesitation_factor = max(0.3, self.hesitation_factor * 1.5)
            self.movement_style = 'hesitant'
            
            logger.warning(f"Adaptando comportamento para alto risco ({detection_risk:.2f})")
            
        elif detection_risk > 0.5:
            # Risco moderado - aumentar naturalidade
            self.delay_min *= 1.2
            self.delay_max *= 1.3
            self.error_rate = max(0.05, self.error_rate * 1.2)
            self.hesitation_factor = max(0.2, self.hesitation_factor * 1.2)
            
            logger.info(f"Adaptando comportamento para risco moderado ({detection_risk:.2f})")
            
        elif detection_risk < 0.2 and self.delay_min > 0.5:
            # Baixo risco - pode otimizar performance
            self.delay_min = max(0.3, self.delay_min / 1.2)
            self.delay_max = max(1.0, self.delay_max / 1.1)
            self.error_rate = max(0.01, self.error_rate / 1.2)
            
            logger.debug(f"Otimizando comportamento para baixo risco ({detection_risk:.2f})")


# Funções de utilidade global

def create_human_simulator(config: Dict[str, Any] = None) -> HumanSimulator:
    """
    Cria uma instância configurada do simulador de comportamento humano
    
    Args:
        config: Configurações opcionais para o simulador
        
    Returns:
        Instância do HumanSimulator
    """
    return HumanSimulator(config)

def get_random_typing_variation() -> Dict[str, Any]:
    """
    Retorna variações aleatórias para digitação humana realista
    
    Returns:
        Dicionário com configurações de variação
    """
    return {
        'delay_range': (random.uniform(0.02, 0.1), random.uniform(0.1, 0.3)),
        'error_probability': random.uniform(0.01, 0.08),
        'rhythm_variation': random.uniform(0.1, 0.3)
    }