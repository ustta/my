import threading
import time
import datetime
import logging
from app import db
from models import TaskQueue, Product, UploadSession, SystemConfig

# Configurando logger
logger = logging.getLogger(__name__)

class TaskScheduler:
    """Agendador de tarefas para execução em segundo plano"""
    
    def __init__(self, app=None):
        """
        Inicializa o agendador de tarefas
        
        Args:
            app: Aplicação Flask opcional
        """
        self.app = app
        self.running = False
        self.scheduler_thread = None
        self.worker_threads = {}
        self.max_workers = 3  # Máximo de workers simultâneos
        self.check_interval = 5  # Intervalo em segundos para verificar novas tarefas
        
        # Se app for fornecido, inicializar agora
        if app is not None:
            self.init_app(app)
    
    def init_app(self, app):
        """
        Inicializa o agendador com a aplicação Flask
        
        Args:
            app: Aplicação Flask
        """
        self.app = app
        
        # Registrar para limpeza durante desligamento
        @app.teardown_appcontext
        def cleanup(exception=None):
            self.stop()
    
    def start(self):
        """Inicia o agendador de tarefas em uma thread separada"""
        if self.running:
            logger.warning("Agendador já está em execução")
            return
        
        self.running = True
        self.scheduler_thread = threading.Thread(target=self._scheduler_loop)
        self.scheduler_thread.daemon = True
        self.scheduler_thread.start()
        logger.info("Agendador de tarefas iniciado")
    
    def stop(self):
        """Para o agendador de tarefas"""
        if not self.running:
            return
        
        self.running = False
        if self.scheduler_thread:
            self.scheduler_thread.join(timeout=5.0)
        
        # Parar workers ativos
        for thread_id, thread in list(self.worker_threads.items()):
            if thread.is_alive():
                logger.debug(f"Aguardando worker {thread_id} terminar...")
                thread.join(timeout=5.0)
        
        logger.info("Agendador de tarefas parado")
    
    def _scheduler_loop(self):
        """Loop principal do agendador que verifica e inicia tarefas"""
        logger.debug("Iniciando loop do agendador")
        
        while self.running:
            try:
                # Limpar threads de workers concluídos
                self._cleanup_workers()
                
                # Verificar se há espaço para novos workers
                available_slots = self.max_workers - len(self.worker_threads)
                
                if available_slots > 0:
                    # Buscar próximas tarefas prontas para execução
                    with self.app.app_context():
                        tasks = self._get_next_tasks(available_slots)
                        
                        for task in tasks:
                            # Marcar como em processamento
                            task.status = 'processing'
                            db.session.commit()
                            
                            # Iniciar worker para a tarefa
                            worker = threading.Thread(
                                target=self._process_task,
                                args=(task.id,),
                                name=f"worker-{task.id}"
                            )
                            worker.daemon = True
                            worker.start()
                            
                            self.worker_threads[task.id] = worker
                            logger.debug(f"Iniciado worker para tarefa {task.id}")
            
            except Exception as e:
                logger.error(f"Erro no loop do agendador: {str(e)}")
            
            # Aguardar próximo ciclo
            time.sleep(self.check_interval)
    
    def _cleanup_workers(self):
        """Remove workers concluídos da lista de workers ativos"""
        for task_id in list(self.worker_threads.keys()):
            thread = self.worker_threads[task_id]
            if not thread.is_alive():
                logger.debug(f"Worker para tarefa {task_id} concluído")
                self.worker_threads.pop(task_id)
    
    def _get_next_tasks(self, limit):
        """
        Obtém as próximas tarefas para execução
        
        Args:
            limit: Número máximo de tarefas a retornar
            
        Returns:
            Lista de tarefas
        """
        now = datetime.datetime.utcnow()
        
        # Obter tarefas pendentes e ordenar por prioridade
        tasks = TaskQueue.query.filter(
            TaskQueue.status == 'pending',
            # Tarefas agendadas para o futuro ou sem agendamento (immediate)
            (TaskQueue.scheduled_for.is_(None) | (TaskQueue.scheduled_for <= now))
        ).order_by(
            TaskQueue.priority.desc(),
            TaskQueue.created_at.asc()
        ).limit(limit).all()
        
        return tasks
    
    def _process_task(self, task_id):
        """
        Processa uma tarefa específica
        
        Args:
            task_id: ID da tarefa a processar
        """
        with self.app.app_context():
            try:
                # Obter tarefa do banco de dados
                task = TaskQueue.query.get(task_id)
                
                if not task or task.status != 'processing':
                    logger.warning(f"Tarefa {task_id} não encontrada ou não está no estado 'processing'")
                    return
                
                logger.info(f"Processando tarefa {task_id} do tipo {task.task_type}")
                
                # Processar tarefa conforme tipo
                if task.task_type == 'product_upload':
                    self._process_product_upload(task)
                elif task.task_type == 'price_update':
                    self._process_price_update(task)
                elif task.task_type == 'competitor_analysis':
                    self._process_competitor_analysis(task)
                elif task.task_type == 'content_generation':
                    self._process_content_generation(task)
                else:
                    logger.warning(f"Tipo de tarefa desconhecido: {task.task_type}")
                    task.status = 'failed'
                    task.error = f"Tipo de tarefa desconhecido: {task.task_type}"
                
                db.session.commit()
                logger.info(f"Tarefa {task_id} processada com sucesso")
            
            except Exception as e:
                logger.error(f"Erro ao processar tarefa {task_id}: {str(e)}")
                try:
                    # Marcar tarefa como falha
                    task = TaskQueue.query.get(task_id)
                    if task:
                        task.status = 'failed'
                        task.error = str(e)
                        db.session.commit()
                except:
                    logger.error("Erro adicional ao marcar tarefa como falha")
    
    def _process_product_upload(self, task):
        """
        Processa uma tarefa de upload de produto
        
        Args:
            task: Instância da tarefa
        """
        payload = task.payload
        product_id = payload.get('product_id')
        session_id = payload.get('session_id')
        
        if not product_id or not session_id:
            task.status = 'failed'
            task.error = "Payload da tarefa incompleto"
            return
        
        # Obter produto e sessão
        product = Product.query.get(product_id)
        upload_session = UploadSession.query.filter_by(session_id=session_id).first()
        
        if not product or not upload_session:
            task.status = 'failed'
            task.error = "Produto ou sessão não encontrados"
            return
        
        # Verificar se a sessão está ativa
        if upload_session.status != 'active':
            task.status = 'paused' if upload_session.status == 'paused' else 'failed'
            task.error = f"Sessão no estado {upload_session.status}"
            return
        
        # Tentar realizar o upload
        try:
            logger.info(f"Simulando upload do produto {product.id}: {product.title}")
            
            # Aqui seria iniciado o processo de navegação e upload
            # Atualmente apenas simula um upload bem-sucedido
            # Na implementação real, o resultado do upload seria determinado pela simulação
            
            # Atualizar produto como tendo sido enviado com sucesso
            product.status = 'uploaded'
            product.hotmart_id = f"HM-{product.id}-{int(time.time())}"
            product.hotmart_url = f"https://hotmart.com/produto/{product.id}"
            product.upload_attempts += 1
            product.last_attempt = datetime.datetime.utcnow()
            
            # Atualizar estatísticas da sessão
            upload_session.successful_uploads += 1
            
            # Verificar se é o último produto da sessão
            if upload_session.successful_uploads + upload_session.failed_uploads >= upload_session.total_products:
                upload_session.status = 'completed'
                upload_session.end_time = datetime.datetime.utcnow()
            
            # Marcar tarefa como concluída
            task.status = 'completed'
            task.result = {
                'success': True,
                'product_id': product.id,
                'hotmart_id': product.hotmart_id,
                'hotmart_url': product.hotmart_url
            }
            
            db.session.commit()
            
        except Exception as e:
            logger.error(f"Erro no upload do produto {product.id}: {str(e)}")
            
            # Atualizar informações do produto
            product.status = 'failed'
            product.upload_attempts += 1
            product.last_attempt = datetime.datetime.utcnow()
            product.error_details = str(e)
            
            # Atualizar estatísticas da sessão
            upload_session.failed_uploads += 1
            
            # Verificar se é o último produto da sessão
            if upload_session.successful_uploads + upload_session.failed_uploads >= upload_session.total_products:
                upload_session.status = 'completed'
                upload_session.end_time = datetime.datetime.utcnow()
            
            # Verificar se deve retentar
            max_retries = upload_session.config.get('max_retries', 3)
            if upload_session.config.get('retry_on_fail', True) and product.upload_attempts < max_retries:
                # Criar nova tarefa para retentar mais tarde
                retry_task = TaskQueue(
                    task_type='product_upload',
                    priority=3,  # Prioridade menor que a original
                    payload=task.payload,
                    scheduled_for=datetime.datetime.utcnow() + datetime.timedelta(minutes=5)
                )
                db.session.add(retry_task)
                logger.info(f"Agendando nova tentativa para produto {product.id}")
            
            # Marcar tarefa como falha
            task.status = 'failed'
            task.error = str(e)
            task.result = {
                'success': False,
                'product_id': product.id,
                'error': str(e)
            }
            
            db.session.commit()
    
    def _process_price_update(self, task):
        """
        Processa uma tarefa de atualização de preço
        
        Args:
            task: Instância da tarefa
        """
        # Implementação pendente
        task.status = 'completed'
        task.result = {
            'success': True,
            'message': "Atualização de preço simulada com sucesso"
        }
    
    def _process_competitor_analysis(self, task):
        """
        Processa uma tarefa de análise de concorrentes
        
        Args:
            task: Instância da tarefa
        """
        # Implementação pendente
        task.status = 'completed'
        task.result = {
            'success': True,
            'message': "Análise de concorrentes simulada com sucesso"
        }
    
    def _process_content_generation(self, task):
        """
        Processa uma tarefa de geração de conteúdo
        
        Args:
            task: Instância da tarefa
        """
        # Implementação pendente
        task.status = 'completed'
        task.result = {
            'success': True,
            'message': "Geração de conteúdo simulada com sucesso"
        }

# Instância global do agendador
scheduler = TaskScheduler()

def init_scheduler(app):
    """
    Inicializa e inicia o agendador de tarefas
    
    Args:
        app: Aplicação Flask
    """
    scheduler.init_app(app)
    scheduler.start()
    return scheduler