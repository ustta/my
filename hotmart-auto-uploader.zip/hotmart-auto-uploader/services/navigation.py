"""
Navigation Service
----------------
Handles browser navigation and interaction with the Hotmart platform.
Provides stealth navigation capabilities and human-like behavior.
"""

import os
import time
import random
import logging
import traceback
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    TimeoutException, 
    NoSuchElementException, 
    StaleElementReferenceException,
    ElementNotInteractableException
)

from services.human_simulator import HumanSimulator

# Configure logger
logger = logging.getLogger(__name__)

class Navigator:
    """
    Browser navigation with stealth capabilities and human-like behavior.
    """
    
    def __init__(self, session_id=None, config=None):
        """
        Initialize the Navigator.
        
        Args:
            session_id: Session identifier for tracking
            config: Configuration dict with custom settings
        """
        self.session_id = session_id or f"session_{int(time.time())}"
        self.config = config or {}
        self.driver = None
        self.wait = None
        self.default_timeout = self.config.get("default_timeout", 30)
        self.human_simulator = HumanSimulator()
        self.current_url = None
        self.last_action_time = time.time()
        
        # Initialize state
        self.detection_risk = 0.0
        self.page_load_times = []
        self.action_count = 0
        
        logger.info(f"Navigator initialized with session ID: {self.session_id}")
    
    def initialize_browser(self):
        """
        Initialize and configure the browser.
        
        Returns:
            bool: True if initialization was successful
        """
        try:
            # Set up Chrome options
            chrome_options = Options()
            
            # Add stealth options
            if self.config.get("stealth_mode", True):
                chrome_options.add_argument("--disable-blink-features=AutomationControlled")
                chrome_options.add_argument("--disable-infobars")
                chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
                chrome_options.add_experimental_option("useAutomationExtension", False)
            
            # Add proxy if configured
            if "proxy" in self.config:
                chrome_options.add_argument(f"--proxy-server={self.config['proxy']}")
            
            # Add headless mode if configured 
            if self.config.get("headless", False):
                chrome_options.add_argument("--headless")
                chrome_options.add_argument("--disable-gpu")
            
            # Common options
            chrome_options.add_argument("--window-size=1920,1080")
            chrome_options.add_argument("--start-maximized")
            chrome_options.add_argument("--disable-dev-shm-usage")
            chrome_options.add_argument("--no-sandbox")
            
            # Create and configure the driver
            service = Service()
            self.driver = webdriver.Chrome(service=service, options=chrome_options)
            self.wait = WebDriverWait(self.driver, self.default_timeout)
            
            # Set various properties to appear more human-like
            self._apply_stealth_properties()
            
            logger.info("Browser initialized successfully")
            return True
            
        except Exception as e:
            logger.error(f"Error initializing browser: {str(e)}")
            return False
    
    def _apply_stealth_properties(self):
        """Apply various stealth properties to make the browser appear more human-like."""
        if not self.driver:
            return
            
        try:
            # Execute JavaScript to modify navigator properties
            self.driver.execute_script("""
                // Overwrite the 'webdriver' property
                Object.defineProperty(navigator, 'webdriver', {
                    get: () => false
                });
                
                // Add a fake language list
                Object.defineProperty(navigator, 'languages', {
                    get: () => ['en-US', 'en', 'pt-BR']
                });
                
                // Add fake plugins
                Object.defineProperty(navigator, 'plugins', {
                    get: () => [
                        {
                            name: 'Chrome PDF Plugin',
                            filename: 'internal-pdf-viewer',
                            description: 'Portable Document Format'
                        },
                        {
                            name: 'Chrome PDF Viewer',
                            filename: 'mhjfbmdgcfjbbpaeojofohoefgiehjai',
                            description: 'Portable Document Format'
                        },
                        {
                            name: 'Native Client',
                            filename: 'internal-nacl-plugin',
                            description: ''
                        }
                    ]
                });
                
                // Modify window.chrome to look legitimate
                window.chrome = { 
                    runtime: {}, 
                    loadTimes: function() {}, 
                    csi: function() {}, 
                    app: {} 
                };
            """)
            
            logger.debug("Applied stealth properties to browser")
            
        except Exception as e:
            logger.warning(f"Error applying stealth properties: {str(e)}")
    
    def navigate_to(self, url, wait_for_load=True, timeout=None):
        """
        Navigate to a URL with human-like timing.
        
        Args:
            url: URL to navigate to
            wait_for_load: Whether to wait for page load
            timeout: Custom timeout in seconds
            
        Returns:
            bool: True if navigation was successful
        """
        if not self.driver:
            logger.error("Browser not initialized")
            return False
            
        try:
            logger.info(f"Navigating to {url}")
            
            # Track start time for performance
            start_time = time.time()
            
            # Navigate to the URL
            self.driver.get(url)
            
            # Wait for page load if required
            if wait_for_load:
                self._wait_for_page_load(timeout or self.default_timeout)
            
            # Update current URL and track load time
            self.current_url = self.driver.current_url
            load_time = time.time() - start_time
            self.page_load_times.append(load_time)
            
            # Simulate natural wait after page load
            self.human_simulator.natural_pause()
            
            logger.info(f"Navigation successful (loaded in {load_time:.2f}s)")
            self.last_action_time = time.time()
            
            return True
            
        except Exception as e:
            logger.error(f"Error navigating to {url}: {str(e)}")
            return False
    
    def _wait_for_page_load(self, timeout=None):
        """
        Wait for the page to fully load.
        
        Args:
            timeout: Wait timeout in seconds
        
        Returns:
            bool: True if page loaded within timeout
        """
        try:
            if not timeout:
                timeout = self.default_timeout
                
            # Wait for the document to be in ready state
            WebDriverWait(self.driver, timeout).until(
                lambda d: d.execute_script('return document.readyState') == 'complete'
            )
            
            # Allow some time for any JavaScript to run
            time.sleep(random.uniform(0.5, 2.0))
            
            return True
            
        except TimeoutException:
            logger.warning(f"Page load timeout after {timeout}s")
            return False
    
    def find_element(self, selector, by=By.CSS_SELECTOR, description=None, context=None, timeout=None):
        """
        Find an element with human-like timing.
        
        Args:
            selector: Element selector
            by: Selector method (e.g. By.CSS_SELECTOR)
            description: Human-readable description for logging
            context: Context description for operation
            timeout: Custom timeout in seconds
            
        Returns:
            WebElement or None if not found
        """
        if not self.driver:
            logger.error("Browser not initialized")
            return None
            
        try:
            element_desc = description or selector
            context_info = f" ({context})" if context else ""
            logger.debug(f"Finding element: {element_desc}{context_info}")
            
            # Wait for the element to be present
            wait_timeout = timeout or self.default_timeout
            element = WebDriverWait(self.driver, wait_timeout).until(
                EC.presence_of_element_located((by, selector))
            )
            
            # Simulate human hesitation before interacting
            self.human_simulator.micro_pause()
            
            return element
            
        except TimeoutException:
            logger.warning(f"Element not found: {description or selector}")
            return None
        except Exception as e:
            logger.error(f"Error finding element {description or selector}: {str(e)}")
            return None
    
    def find_elements(self, selector, by=By.CSS_SELECTOR, description=None, context=None, timeout=None):
        """
        Find multiple elements.
        
        Args:
            selector: Element selector
            by: Selector method (e.g. By.CSS_SELECTOR)
            description: Human-readable description for logging
            context: Context description for operation
            timeout: Custom timeout in seconds
            
        Returns:
            List of WebElements or empty list if none found
        """
        if not self.driver:
            logger.error("Browser not initialized")
            return []
            
        try:
            element_desc = description or selector
            context_info = f" ({context})" if context else ""
            logger.debug(f"Finding elements: {element_desc}{context_info}")
            
            # Wait for at least one element to be present
            wait_timeout = timeout or self.default_timeout
            WebDriverWait(self.driver, wait_timeout).until(
                EC.presence_of_element_located((by, selector))
            )
            
            # Get all matching elements
            elements = self.driver.find_elements(by, selector)
            
            # Simulate human hesitation
            self.human_simulator.micro_pause()
            
            logger.debug(f"Found {len(elements)} elements matching: {element_desc}")
            return elements
            
        except TimeoutException:
            logger.warning(f"No elements found: {description or selector}")
            return []
        except Exception as e:
            logger.error(f"Error finding elements {description or selector}: {str(e)}")
            return []
    
    def click(self, element, description=None, force=False):
        """
        Click an element with human-like behavior.
        
        Args:
            element: WebElement to click
            description: Description for logging
            force: Whether to force click using JavaScript
            
        Returns:
            bool: True if click was successful
        """
        if not self.driver or not element:
            return False
            
        try:
            elem_desc = description or "element"
            logger.debug(f"Clicking {elem_desc}")
            
            # Scroll element into view
            self._scroll_to_element(element)
            
            # Move mouse to element with natural movement
            self.human_simulator.move_mouse_to_element(self.driver, element)
            
            # Add a short pause before clicking (human-like)
            time.sleep(random.uniform(0.1, 0.3))
            
            # Try normal click first
            if not force:
                element.click()
            else:
                # Force click with JavaScript
                self.driver.execute_script("arguments[0].click();", element)
            
            # Record action and update time
            self.action_count += 1
            self.last_action_time = time.time()
            
            # Natural pause after clicking
            self.human_simulator.micro_pause()
            
            logger.debug(f"Click on {elem_desc} successful")
            return True
            
        except ElementNotInteractableException:
            # Try JavaScript click if normal click fails
            try:
                logger.debug(f"Element not interactable, trying JavaScript click for {elem_desc}")
                self.driver.execute_script("arguments[0].click();", element)
                return True
            except Exception as e2:
                logger.error(f"JavaScript click also failed for {elem_desc}: {str(e2)}")
                return False
        except Exception as e:
            logger.error(f"Error clicking {elem_desc}: {str(e)}")
            return False
    
    def find_and_click(self, selector, by=By.CSS_SELECTOR, description=None, context=None, timeout=None, force=False):
        """
        Find an element and click it.
        
        Args:
            selector: Element selector
            by: Selector method
            description: Description for logging
            context: Context of operation
            timeout: Custom timeout
            force: Whether to force click with JavaScript
            
        Returns:
            bool: True if operation was successful
        """
        element = self.find_element(selector, by, description, context, timeout)
        
        if element:
            return self.click(element, description, force)
        
        return False
    
    def type_text(self, element, text, clear_first=True, description=None, human_like=True):
        """
        Type text into an element with human-like behavior.
        
        Args:
            element: WebElement to type into
            text: Text to type
            clear_first: Whether to clear the field first
            description: Description for logging
            human_like: Whether to simulate human typing
            
        Returns:
            bool: True if typing was successful
        """
        if not self.driver or not element:
            return False
            
        try:
            elem_desc = description or "input field"
            logger.debug(f"Typing text into {elem_desc}")
            
            # Scroll element into view
            self._scroll_to_element(element)
            
            # Focus the element
            self.click(element, f"focusing {elem_desc}")
            
            # Clear the field if requested
            if clear_first:
                element.clear()
                self.human_simulator.micro_pause()
            
            # Type the text
            if human_like and self.human_simulator:
                # Simulate human typing with variable speed
                for char in text:
                    element.send_keys(char)
                    # Add random delay between keystrokes
                    time.sleep(self.human_simulator.get_typing_delay())
            else:
                # Type all at once
                element.send_keys(text)
            
            # Record action and update time
            self.action_count += 1
            self.last_action_time = time.time()
            
            # Natural pause after typing
            self.human_simulator.micro_pause()
            
            logger.debug(f"Finished typing into {elem_desc}")
            return True
            
        except Exception as e:
            logger.error(f"Error typing into {elem_desc}: {str(e)}")
            return False
    
    def find_and_type(self, selector, text, by=By.CSS_SELECTOR, clear_first=True, 
                     description=None, context=None, timeout=None, human_like=True):
        """
        Find an element and type text into it.
        
        Args:
            selector: Element selector
            text: Text to type
            by: Selector method
            clear_first: Whether to clear the field first
            description: Description for logging
            context: Context of operation
            timeout: Custom timeout
            human_like: Whether to simulate human typing
            
        Returns:
            bool: True if operation was successful
        """
        element = self.find_element(selector, by, description, context, timeout)
        
        if element:
            return self.type_text(element, text, clear_first, description, human_like)
        
        return False
    
    def _scroll_to_element(self, element, margin=100):
        """
        Scroll to an element with human-like behavior.
        
        Args:
            element: Element to scroll to
            margin: Margin in pixels
            
        Returns:
            bool: True if scroll was successful
        """
        if not self.driver or not element:
            return False
            
        try:
            # Get element location
            location = element.location_once_scrolled_into_view
            
            # Add some human-like scrolling behavior
            self.human_simulator.human_like_scroll(self.driver, element)
            
            return True
            
        except Exception as e:
            logger.warning(f"Error scrolling to element: {str(e)}")
            
            # Fallback to JavaScript scroll
            try:
                self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", element)
                return True
            except:
                return False
    
    def select_option(self, element, value=None, text=None, index=None, description=None):
        """
        Select an option from a dropdown.
        
        Args:
            element: Select element
            value: Option value
            text: Option text
            index: Option index
            description: Description for logging
            
        Returns:
            bool: True if selection was successful
        """
        if not self.driver or not element:
            return False
            
        try:
            elem_desc = description or "dropdown"
            logger.debug(f"Selecting option from {elem_desc}")
            
            # Scroll to and click the dropdown
            self._scroll_to_element(element)
            element.click()
            
            # Natural pause
            self.human_simulator.micro_pause()
            
            # Find and click the option based on criteria
            option_selected = False
            options = element.find_elements(By.TAG_NAME, "option")
            
            if value is not None:
                for option in options:
                    if option.get_attribute("value") == value:
                        option.click()
                        option_selected = True
                        break
            elif text is not None:
                for option in options:
                    if option.text == text:
                        option.click()
                        option_selected = True
                        break
            elif index is not None:
                if 0 <= index < len(options):
                    options[index].click()
                    option_selected = True
            
            if not option_selected:
                logger.warning(f"No matching option found for {elem_desc}")
                return False
            
            # Record action and update time
            self.action_count += 1
            self.last_action_time = time.time()
            
            # Natural pause after selection
            self.human_simulator.micro_pause()
            
            logger.debug(f"Option selection from {elem_desc} successful")
            return True
            
        except Exception as e:
            logger.error(f"Error selecting option from {elem_desc}: {str(e)}")
            return False
    
    def wait_for_element(self, selector, by=By.CSS_SELECTOR, visible=True, timeout=None):
        """
        Wait for an element to be present or visible.
        
        Args:
            selector: Element selector
            by: Selector method
            visible: Whether to wait for visibility
            timeout: Custom timeout
            
        Returns:
            WebElement or None if timeout
        """
        if not self.driver:
            return None
            
        try:
            wait_timeout = timeout or self.default_timeout
            wait = WebDriverWait(self.driver, wait_timeout)
            
            if visible:
                element = wait.until(EC.visibility_of_element_located((by, selector)))
            else:
                element = wait.until(EC.presence_of_element_located((by, selector)))
                
            return element
            
        except TimeoutException:
            logger.warning(f"Timeout waiting for element: {selector}")
            return None
        except Exception as e:
            logger.error(f"Error waiting for element {selector}: {str(e)}")
            return None
    
    def execute_script(self, script, *args):
        """
        Execute JavaScript in the browser.
        
        Args:
            script: JavaScript code
            *args: Arguments to pass to the script
            
        Returns:
            Result of the script execution
        """
        if not self.driver:
            return None
            
        try:
            return self.driver.execute_script(script, *args)
        except Exception as e:
            logger.error(f"Error executing script: {str(e)}")
            return None
    
    def take_screenshot(self, filename=None):
        """
        Take a screenshot of the current page.
        
        Args:
            filename: Output filename (if None, generated automatically)
            
        Returns:
            Path to screenshot file or None if failed
        """
        if not self.driver:
            return None
            
        try:
            if not filename:
                # Generate filename based on time and session
                timestamp = int(time.time())
                filename = f"screenshots/screenshot_{self.session_id}_{timestamp}.png"
            
            # Ensure directory exists
            os.makedirs(os.path.dirname(filename), exist_ok=True)
            
            # Take screenshot
            self.driver.save_screenshot(filename)
            logger.debug(f"Screenshot saved to {filename}")
            
            return filename
            
        except Exception as e:
            logger.error(f"Error taking screenshot: {str(e)}")
            return None
    
    def check_for_captcha(self):
        """
        Check if a CAPTCHA is present on the page.
        
        Returns:
            bool: True if CAPTCHA detected
        """
        if not self.driver:
            return False
            
        try:
            # Check for common CAPTCHA elements
            captcha_selectors = [
                "iframe[src*='recaptcha']",
                "iframe[src*='captcha']",
                "div.g-recaptcha",
                "[id*='captcha']",
                "[class*='captcha']",
                "input[id*='captcha']",
                "img[alt*='captcha' i]"
            ]
            
            for selector in captcha_selectors:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                if elements:
                    logger.warning(f"CAPTCHA detected: {selector}")
                    return True
            
            return False
            
        except Exception as e:
            logger.error(f"Error checking for CAPTCHA: {str(e)}")
            return False
    
    def get_url(self):
        """Get the current URL."""
        if self.driver:
            return self.driver.current_url
        return None
    
    def get_page_source(self):
        """Get the current page source."""
        if self.driver:
            return self.driver.page_source
        return None
    
    def get_title(self):
        """Get the current page title."""
        if self.driver:
            return self.driver.title
        return None
    
    def get_cookies(self):
        """Get all cookies."""
        if self.driver:
            return self.driver.get_cookies()
        return []
    
    def add_cookie(self, cookie):
        """Add a cookie to the browser."""
        if self.driver:
            self.driver.add_cookie(cookie)
    
    def clear_cookies(self):
        """Clear all cookies."""
        if self.driver:
            self.driver.delete_all_cookies()
    
    def refresh_page(self):
        """Refresh the current page."""
        if self.driver:
            self.driver.refresh()
            self._wait_for_page_load()
    
    def go_back(self):
        """Navigate back in history."""
        if self.driver:
            self.driver.back()
            self._wait_for_page_load()
    
    def go_forward(self):
        """Navigate forward in history."""
        if self.driver:
            self.driver.forward()
            self._wait_for_page_load()
    
    def close(self):
        """Close the browser."""
        if self.driver:
            try:
                self.driver.quit()
                logger.info("Browser closed")
            except Exception as e:
                logger.error(f"Error closing browser: {str(e)}")
            finally:
                self.driver = None
    
    def is_element_present(self, selector, by=By.CSS_SELECTOR):
        """
        Check if an element is present on the page.
        
        Args:
            selector: Element selector
            by: Selector method
            
        Returns:
            bool: True if element is present
        """
        if not self.driver:
            return False
            
        try:
            self.driver.find_element(by, selector)
            return True
        except NoSuchElementException:
            return False
    
    def is_element_visible(self, selector, by=By.CSS_SELECTOR):
        """
        Check if an element is visible on the page.
        
        Args:
            selector: Element selector
            by: Selector method
            
        Returns:
            bool: True if element is visible
        """
        if not self.driver:
            return False
            
        try:
            element = self.driver.find_element(by, selector)
            return element.is_displayed()
        except NoSuchElementException:
            return False
    
    def get_element_attribute(self, element, attribute):
        """
        Get an attribute value from an element.
        
        Args:
            element: WebElement
            attribute: Attribute name
            
        Returns:
            Attribute value or None if not found
        """
        if not element:
            return None
            
        try:
            return element.get_attribute(attribute)
        except Exception:
            return None
    
    def get_element_text(self, element):
        """
        Get text content of an element.
        
        Args:
            element: WebElement
            
        Returns:
            Text content or empty string if not found
        """
        if not element:
            return ""
            
        try:
            return element.text.strip()
        except Exception:
            return ""
