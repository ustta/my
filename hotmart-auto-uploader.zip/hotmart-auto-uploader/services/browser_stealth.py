import logging
import random
import json
import time
from typing import Dict, Any, List, Optional
import os
import uuid

# Configurando logger
logger = logging.getLogger(__name__)

class BrowserStealth:
    """
    Técnicas avançadas de evasão para evitar detecção do navegador automatizado.
    
    Esta classe implementa diversas técnicas para mascarar os indicadores de automação
    em navegadores controlados pelo Selenium, tornando-os indistinguíveis de
    navegadores operados por humanos.
    """
    
    def __init__(self, driver=None, config: Dict[str, Any] = None):
        """
        Inicializa o sistema de evasão para navegador
        
        Args:
            driver: Instância do WebDriver (opcional)
            config: Configurações opcionais
        """
        self.driver = driver
        self.config = config or {}
        self.enabled_techniques = self.config.get('techniques', [
            'webdriver_properties',
            'navigator_properties',
            'hardware_concurrency',
            'plugins_length',
            'plugins_prototype',
            'language_properties',
            'webgl_vendor',
            'chrome_properties',
            'permissions_properties',
            'iframe_contentWindow',
            'audio_context',
            'touch_points',
            'codec_profiles',
            'outerHeight_width',
            'connection_rtt'
        ])
        
        # Dicionário de user agents realistas
        self.user_agents = {
            'windows': {
                'chrome': [
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36'
                ],
                'firefox': [
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/120.0',
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/119.0',
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/118.0'
                ],
                'edge': [
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0',
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0'
                ]
            },
            'macos': {
                'chrome': [
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
                ],
                'safari': [
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Safari/605.1.15',
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15'
                ],
                'firefox': [
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/120.0',
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/119.0'
                ]
            }
        }
        
        # Dicionário de nomes de plugins comuns
        self.common_plugins = [
            "Chrome PDF Plugin",
            "Chrome PDF Viewer",
            "Native Client",
            "Adobe Acrobat",
            "AdobeAAMDetect",
            "Google Drive",
            "Microsoft Office",
            "WebEx",
            "LastPass",
            "1Password"
        ]
        
        # Dicionário de idiomas comuns
        self.language_combinations = [
            ['pt-BR', 'pt', 'en-US', 'en'],
            ['en-US', 'en', 'pt-BR', 'pt'],
            ['pt-BR', 'pt', 'es-ES', 'es', 'en-US', 'en'],
            ['en-US', 'en', 'es-ES', 'es'],
            ['es-ES', 'es', 'pt-BR', 'pt', 'en-US', 'en']
        ]
        
        # Fabricantes de GPU comuns
        self.common_gpu_vendors = [
            "Google Inc. (Intel)",
            "Google Inc. (NVIDIA)",
            "Google Inc. (AMD)",
            "Google Inc.",
            "Intel Inc.",
            "NVIDIA Corporation",
            "AMD Corporation"
        ]
        
        # Carregar perfil de evasão, se fornecido
        self.profile = self._load_profile()
        
        # Aplicar evasão automaticamente se driver foi fornecido
        if self.driver is not None:
            self.apply_evasion_techniques()
    
    def _load_profile(self) -> Dict[str, Any]:
        """
        Carrega ou cria perfil de evasão
        
        Returns:
            Dicionário com o perfil
        """
        profile = {}
        
        # Tentar carregar perfil de arquivo
        profile_path = self.config.get('profile_path')
        if profile_path and os.path.exists(profile_path):
            try:
                with open(profile_path, 'r') as f:
                    profile = json.load(f)
                    logger.info(f"Perfil de evasão carregado: {profile_path}")
                    return profile
            except Exception as e:
                logger.warning(f"Erro ao carregar perfil de evasão: {str(e)}")
        
        # Criar perfil aleatório
        os_type = random.choice(['windows', 'macos'])
        if os_type == 'windows':
            browser_type = random.choice(['chrome', 'firefox', 'edge'])
        else:
            browser_type = random.choice(['chrome', 'safari', 'firefox'])
        
        ua = random.choice(self.user_agents[os_type][browser_type])
        
        hardwareConcurrency = random.choice([2, 4, 6, 8, 12, 16])
        deviceMemory = random.choice([2, 4, 8, 16])
        
        profile = {
            'userAgent': ua,
            'appVersion': ua.split('Mozilla/')[1],
            'hardwareConcurrency': hardwareConcurrency,
            'deviceMemory': deviceMemory,
            'languages': random.choice(self.language_combinations),
            'plugins': random.sample(self.common_plugins, random.randint(3, 6)),
            'vendor': random.choice(self.common_gpu_vendors),
            'hasTouch': random.choice([True, False]),
            'platform': 'Win32' if os_type == 'windows' else 'MacIntel',
            'doNotTrack': random.choice([None, '0', '1']),
            'timezone': random.choice([-3, -2, -1, 0]),
            'videoCodecs': ['avc1.42E01E', 'vp8', 'vp9'],
            'audioCodecs': ['mp4a.40.2', 'vorbis', 'opus'],
            'connection': {
                'rtt': random.randint(50, 150),
                'downlink': random.uniform(5.0, 20.0),
                'effectiveType': random.choice(['4g', '3g'])
            },
            'mediaDevices': {
                'audioinput': random.randint(1, 2),
                'audiooutput': random.randint(1, 3),
                'videoinput': random.randint(0, 2)
            },
            'screen': {
                'width': random.choice([1366, 1440, 1536, 1920, 2560]),
                'height': random.choice([768, 900, 1080, 1200, 1440]),
                'pixelDepth': 24,
                'colorDepth': 24
            }
        }
        
        # Salvar perfil para reutilização
        if profile_path:
            try:
                os.makedirs(os.path.dirname(profile_path), exist_ok=True)
                with open(profile_path, 'w') as f:
                    json.dump(profile, f, indent=2)
                    logger.info(f"Perfil de evasão salvo: {profile_path}")
            except Exception as e:
                logger.warning(f"Erro ao salvar perfil de evasão: {str(e)}")
        
        return profile
    
    def set_driver(self, driver) -> None:
        """
        Define o WebDriver para aplicar técnicas de evasão
        
        Args:
            driver: WebDriver a ser utilizado
        """
        self.driver = driver
        
        # Aplicar evasão automaticamente
        self.apply_evasion_techniques()
    
    def apply_evasion_techniques(self) -> None:
        """
        Aplica todas as técnicas de evasão habilitadas
        """
        if self.driver is None:
            logger.warning("Nenhum WebDriver disponível para aplicar técnicas de evasão")
            return
        
        # Criar função JavaScript para evitar detecção por depuração
        js_set_properties = """
        // Função utilitária para definir propriedades não detectáveis
        const _setProperty = (obj, prop, value, descriptor = {}) => {
            try {
                // Criar descritor de propriedade personalizado
                const propDescriptor = {
                    ...descriptor,
                    value
                };
                
                // Adicionar getter/setter se não fornecido
                if (!('get' in descriptor)) {
                    propDescriptor.get = function() { return value; };
                }
                
                if (!('set' in descriptor)) {
                    propDescriptor.set = function(newValue) { value = newValue; };
                }
                
                // Garantir que a propriedade não seja detectável
                Object.defineProperty(obj, prop, {
                    ...propDescriptor,
                    configurable: true,
                    enumerable: true
                });
                
                return true;
            } catch (e) {
                console.error(`Erro ao definir ${prop}:`, e);
                return false;
            }
        };
        
        // Métodos para gerar fingerprint consistente
        const _fingerprint = {
            deviceIdKey: '__$$deviceprint$$__',
            getDeviceId: function() {
                let deviceId = localStorage.getItem(this.deviceIdKey);
                if (!deviceId) {
                    // Gerar ID único persistente
                    deviceId = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
                        const r = Math.random() * 16 | 0;
                        const v = c === 'x' ? r : (r & 0x3 | 0x8);
                        return v.toString(16);
                    });
                    localStorage.setItem(this.deviceIdKey, deviceId);
                }
                return deviceId;
            },
            getCanvasFingerprint: function(text = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ`~1!2@3#4$5%6^7&8*9(0)-_=+[{]}\\|;:'\",<.>/?') {
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');
                
                // Definir tamanho consistente
                canvas.width = 220;
                canvas.height = 30;
                
                // Preencher fundo
                ctx.fillStyle = 'rgb(255, 255, 255)';
                ctx.fillRect(0, 0, 220, 30);
                
                // Desenhar texto
                ctx.fillStyle = 'rgb(0, 0, 0)';
                ctx.font = '15px Arial';
                ctx.textBaseline = 'alphabetic';
                ctx.fillText(text, 10, 15);
                
                return canvas.toDataURL();
            }
        };
        
        window._stealth = {
            isInitialized: true,
            fingerprint: _fingerprint,
            setProperty: _setProperty
        };
        """
        
        try:
            # Injetar funções utilitárias
            self.driver.execute_script(js_set_properties)
            
            # Aplicar técnicas habilitadas
            for technique in self.enabled_techniques:
                technique_method = getattr(self, f'_apply_{technique}', None)
                if technique_method:
                    try:
                        technique_method()
                    except Exception as e:
                        logger.warning(f"Erro ao aplicar técnica '{technique}': {str(e)}")
                else:
                    logger.warning(f"Técnica desconhecida: {technique}")
            
            # Aplicar técnicas adicionais
            self._apply_random_delays()
            self._apply_additional_fingerprint_protections()
            
            logger.info("Técnicas de evasão aplicadas com sucesso")
        
        except Exception as e:
            logger.error(f"Erro ao aplicar técnicas de evasão: {str(e)}")
    
    def _apply_webdriver_properties(self) -> None:
        """
        Remove ou modifica propriedades navigator.webdriver
        """
        script = """
        (function() {
            // Remover propriedade webdriver
            window._stealth.setProperty(navigator, 'webdriver', undefined, {
                get: function() { return undefined; }
            });
            
            // Script para lidar com o "driver" também
            if ('driver' in window.navigator) {
                window._stealth.setProperty(navigator, 'driver', undefined);
            }
            
            // Ocultar classes relacionadas ao Selenium/ChromeDriver
            let oldProto = HTMLElement.prototype.getAttribute;
            window._stealth.setProperty(HTMLElement.prototype, 'getAttribute', function() {
                const attr = arguments[0];
                if (attr === 'webdriver' || attr === 'driver' || attr === 'selenium') {
                    return null;
                }
                
                let result = oldProto.apply(this, arguments);
                return result;
            });
            
            // Ocultar propriedades "chrome driver"
            if (window.navigator.hasOwnProperty('webdriver')) {
                delete Object.getPrototypeOf(navigator).webdriver;
            }
        })();
        """
        
        self.driver.execute_script(script)
    
    def _apply_navigator_properties(self) -> None:
        """
        Modifica propriedades do objeto navigator para parecer mais realista
        """
        script = f"""
        (function() {{
            // User agent
            window._stealth.setProperty(navigator, 'userAgent', '{self.profile["userAgent"]}');
            window._stealth.setProperty(navigator, 'appVersion', '{self.profile["appVersion"]}');
            
            // Platform
            window._stealth.setProperty(navigator, 'platform', '{self.profile["platform"]}');
            
            // Do Not Track
            window._stealth.setProperty(navigator, 'doNotTrack', '{self.profile["doNotTrack"]}');
            
            // Corrigir propriedades de plugins
            if (navigator.plugins.length === 0) {{
                // Criar alguns plugins falsos
                const numPlugins = {len(self.profile["plugins"])};
                const FakePlugin = function(name, description, filename) {{
                    this.name = name;
                    this.description = description || "";
                    this.filename = filename || "";
                    this.version = "1.0.0";
                    this.length = 1;
                    this[0] = {{
                        type: "application/x-" + name.toLowerCase().replace(/\\s/g, '-'),
                        description: description || "",
                        suffixes: "pdf",
                        enabledPlugin: this
                    }};
                }};
                
                const plugins = [
                    {", ".join([f'new FakePlugin("{plugin}")' for plugin in self.profile["plugins"]])}
                ];
                
                // Emular propriedades do objeto plugins
                const PluginArray = function() {{
                    this.length = plugins.length;
                    for (let i = 0; i < plugins.length; i++) {{
                        this[i] = plugins[i];
                        this[plugins[i].name] = plugins[i];
                    }}
                }};
                
                PluginArray.prototype.item = function(index) {{
                    return this[index];
                }};
                
                PluginArray.prototype.namedItem = function(name) {{
                    return this[name];
                }};
                
                PluginArray.prototype.refresh = function() {{}};
                
                const pluginsInstance = new PluginArray();
                window._stealth.setProperty(navigator, 'plugins', pluginsInstance);
            }}
        }})();
        """
        
        self.driver.execute_script(script)
    
    def _apply_hardware_concurrency(self) -> None:
        """
        Modifica a propriedade navigator.hardwareConcurrency
        """
        script = f"""
        (function() {{
            window._stealth.setProperty(navigator, 'hardwareConcurrency', {self.profile["hardwareConcurrency"]});
        }})();
        """
        
        self.driver.execute_script(script)
    
    def _apply_plugins_length(self) -> None:
        """
        Garante que navigator.plugins tenha um comprimento adequado
        """
        script = f"""
        (function() {{
            const pluginsLength = {len(self.profile["plugins"])};
            if (navigator.plugins.length !== pluginsLength && !navigator.plugins.namedItem) {{
                const originalPlugins = navigator.plugins;
                const pluginsProxy = new Proxy(originalPlugins, {{
                    get: function(target, prop) {{
                        if (prop === 'length') {{
                            return pluginsLength;
                        }}
                        return target[prop];
                    }}
                }});
                window._stealth.setProperty(navigator, 'plugins', pluginsProxy);
            }}
        }})();
        """
        
        self.driver.execute_script(script)
    
    def _apply_plugins_prototype(self) -> None:
        """
        Corrige o protótipo de navigator.plugins para parecer normal
        """
        script = """
        (function() {
            // Verificar se plugins está funcionando corretamente
            if (navigator.plugins && typeof navigator.plugins === 'object') {
                // Adicionar métodos padrão se necessário
                if (!navigator.plugins.namedItem) {
                    Object.defineProperty(navigator.plugins, 'namedItem', {
                        value: function(name) {
                            for (let i = 0; i < this.length; i++) {
                                if (this[i].name === name) {
                                    return this[i];
                                }
                            }
                            return null;
                        },
                        configurable: true
                    });
                }
                
                // Adicionar outras funções padrão
                if (!navigator.plugins.refresh) {
                    Object.defineProperty(navigator.plugins, 'refresh', {
                        value: function() { /* Não faz nada, mas existe */ },
                        configurable: true
                    });
                }
                
                if (!navigator.plugins.item) {
                    Object.defineProperty(navigator.plugins, 'item', {
                        value: function(index) {
                            return this[index];
                        },
                        configurable: true
                    });
                }
            }
        })();
        """
        
        self.driver.execute_script(script)
    
    def _apply_language_properties(self) -> None:
        """
        Modifica as propriedades de idioma do navegador
        """
        langs = self.profile["languages"]
        langs_str = json.dumps(langs)
        
        script = f"""
        (function() {{
            // Definir navigator.languages
            window._stealth.setProperty(navigator, 'languages', {langs_str});
            
            // Definir navigator.language
            window._stealth.setProperty(navigator, 'language', '{langs[0]}');
        }})();
        """
        
        self.driver.execute_script(script)
    
    def _apply_webgl_vendor(self) -> None:
        """
        Modifica as informações de fabricante e renderizador do WebGL
        """
        vendor = self.profile["vendor"]
        
        script = f"""
        (function() {{
            const getParameterProxies = new Map();
            
            // Hook WebGLRenderingContext.getParameter para retornar valores falsos
            const addGetParameterProxy = function(ctx) {{
                if (getParameterProxies.has(ctx)) return;
                
                const origGetParameter = ctx.getParameter.bind(ctx);
                
                const getParameterProxy = function(param) {{
                    // UNMASKED_VENDOR_WEBGL ou UNMASKED_RENDERER_WEBGL
                    if (param === 37445) {{ // vendor
                        return '{vendor}';
                    }}
                    
                    if (param === 37446) {{ // renderer
                        return '{vendor} OpenGL Engine';
                    }}
                    
                    return origGetParameter(param);
                }};
                
                getParameterProxies.set(ctx, getParameterProxy);
                ctx.getParameter = getParameterProxy;
            }};
            
            // Interceptar criação de context WebGL
            const protoDesc = Object.getOwnPropertyDescriptor(HTMLCanvasElement.prototype, 'getContext');
            if (protoDesc) {{
                const origGetContext = protoDesc.value;
                
                const getContextProxy = function(type, ...rest) {{
                    const ctx = origGetContext.call(this, type, ...rest);
                    
                    if (ctx && (type === 'webgl' || type === 'webgl2' || type === 'experimental-webgl')) {{
                        addGetParameterProxy(ctx);
                    }}
                    
                    return ctx;
                }};
                
                window._stealth.setProperty(HTMLCanvasElement.prototype, 'getContext', getContextProxy);
            }}
        }})();
        """
        
        self.driver.execute_script(script)
    
    def _apply_chrome_properties(self) -> None:
        """
        Manipula o objeto window.chrome para parecer mais realista
        """
        script = """
        (function() {
            // Criar uma versão realista do objeto chrome
            if (!window.chrome) {
                const chrome = {
                    app: {
                        isInstalled: false,
                        InstallState: {
                            DISABLED: 'disabled',
                            INSTALLED: 'installed',
                            NOT_INSTALLED: 'not_installed'
                        },
                        RunningState: {
                            CANNOT_RUN: 'cannot_run',
                            READY_TO_RUN: 'ready_to_run',
                            RUNNING: 'running'
                        }
                    },
                    runtime: {
                        OnInstalledReason: {
                            INSTALL: 'install',
                            UPDATE: 'update',
                            CHROME_UPDATE: 'chrome_update',
                            SHARED_MODULE_UPDATE: 'shared_module_update'
                        },
                        OnRestartRequiredReason: {
                            APP_UPDATE: 'app_update',
                            OS_UPDATE: 'os_update',
                            PERIODIC: 'periodic'
                        },
                        PlatformArch: {
                            ARM: 'arm',
                            ARM64: 'arm64',
                            MIPS: 'mips',
                            MIPS64: 'mips64',
                            X86_32: 'x86-32',
                            X86_64: 'x86-64'
                        },
                        PlatformNaclArch: {
                            ARM: 'arm',
                            MIPS: 'mips',
                            MIPS64: 'mips64',
                            X86_32: 'x86-32',
                            X86_64: 'x86-64'
                        },
                        PlatformOs: {
                            ANDROID: 'android',
                            CROS: 'cros',
                            LINUX: 'linux',
                            MAC: 'mac',
                            OPENBSD: 'openbsd',
                            WIN: 'win'
                        },
                        RequestUpdateCheckStatus: {
                            THROTTLED: 'throttled',
                            NO_UPDATE: 'no_update',
                            UPDATE_AVAILABLE: 'update_available'
                        }
                    }
                };
                
                window._stealth.setProperty(window, 'chrome', chrome);
            }
        })();
        """
        
        self.driver.execute_script(script)
    
    def _apply_permissions_properties(self) -> None:
        """
        Manipula o objeto Permissions para comportamento realista
        """
        script = """
        (function() {
            // Criar um objeto de permissões realista
            if (navigator.permissions) {
                const originalQuery = navigator.permissions.query;
                
                window._stealth.setProperty(navigator.permissions, 'query', function(permissionDesc) {
                    if (permissionDesc.name === 'notifications') {
                        return Promise.resolve({
                            state: Notification.permission,
                            addEventListener: function() {},
                            removeEventListener: function() {},
                            dispatchEvent: function() { return true; }
                        });
                    }
                    
                    // Ações de automação e clipes específicos podem revelar ferramentas de automação
                    if (permissionDesc.name === 'clipboard-read' || 
                        permissionDesc.name === 'clipboard-write' || 
                        permissionDesc.name === 'clipboard' ||
                        permissionDesc.name === 'accessibility-events' ||
                        permissionDesc.name === 'automation') {
                        
                        return Promise.resolve({
                            state: 'prompt',
                            addEventListener: function() {},
                            removeEventListener: function() {},
                            dispatchEvent: function() { return true; }
                        });
                    }
                    
                    return originalQuery.call(this, permissionDesc);
                });
            }
        })();
        """
        
        self.driver.execute_script(script)
    
    def _apply_iframe_contentWindow(self) -> None:
        """
        Impede a detecção por meio de iframe.contentWindow.navigator
        """
        script = """
        (function() {
            // Verificar se já existe algum iframe criado
            try {
                const iframe = document.createElement('iframe');
                document.head.append(iframe);
                
                if (iframe.contentWindow) {
                    // Ocultar propriedade webdriver no iframe também
                    window._stealth.setProperty(iframe.contentWindow.navigator, 'webdriver', undefined);
                    
                    // Diversos métodos usados para detecção
                    const remover = [
                        '_getSelfPath',
                        '_sourceObject',
                        '_createRegExp',
                        'isChrome',
                        '_p',
                        '_phantom',
                        '__phantomas',
                        'callPhantom',
                        '_selenium',
                        'callSelenium',
                        '_Selenium_IDE_Recorder',
                        '_selenium',
                        'getAttribute',
                        '__webdriver_script_fn',
                        '$chrome_asyncScriptInfo',
                        '__$webdriverAsyncExecutor',
                        '__driver_evaluate',
                        '__webdriver_evaluate',
                        '__selenium_evaluate',
                        '__fxdriver_evaluate',
                        '__driver_unwrapped',
                        '__webdriver_unwrapped',
                        '__selenium_unwrapped',
                        '__fxdriver_unwrapped',
                        '__webdriver_script_func',
                        '$cdc_asdjflasutopfhvcZLmcfl_'
                    ];
                    
                    for (const prop of remover) {
                        if (iframe.contentWindow[prop]) {
                            delete iframe.contentWindow[prop];
                        }
                    }
                }
                
                // Remover iframe
                iframe.remove();
            } catch (e) {
                // Ignorar erros
            }
            
            // Criar hook para todos os futuros iframes
            const createElementOrig = document.createElement;
            window._stealth.setProperty(document, 'createElement', function(...args) {
                const element = createElementOrig.apply(this, args);
                if (args[0].toLowerCase() === 'iframe') {
                    const frameLoadHandler = () => {
                        try {
                            if (element.contentWindow && element.contentWindow.navigator) {
                                window._stealth.setProperty(element.contentWindow.navigator, 'webdriver', undefined);
                            }
                        } catch (e) {
                            // Ignorar erros de CORS
                        }
                        element.removeEventListener('load', frameLoadHandler);
                    };
                    
                    element.addEventListener('load', frameLoadHandler);
                }
                return element;
            });
        })();
        """
        
        self.driver.execute_script(script)
    
    def _apply_audio_context(self) -> None:
        """
        Aplica proteção contra fingerprinting por AudioContext
        """
        script = """
        (function() {
            const originalOfflineAudioContextConstructor = window.OfflineAudioContext;
            const originalAudioContextConstructor = window.AudioContext || window.webkitAudioContext;
            
            // Adicionar noise com leve variação a um buffer de áudio
            const addNoise = function(buffer) {
                const channelData = buffer.getChannelData(0);
                const noise = window._stealth.fingerprint.getDeviceId();
                
                // Usar o ID do dispositivo para gerar ruído consistente
                let noiseIndex = 0;
                for (let i = 0; i < channelData.length; i++) {
                    // Adicionar pequeníssima variação - grande demais quebra sites legítimos
                    const char = noise.charCodeAt(noiseIndex % noise.length);
                    const tinyNoise = char / 50000; // Extremamente sutil
                    
                    // Apenas alguns samples para não quebrar funcionalidade
                    if (i % 100 === 0) {
                        channelData[i] = channelData[i] + tinyNoise;
                    }
                    
                    noiseIndex++;
                }
            };
            
            // Criar proxy para getChannelData
            const createAudioBufferProxy = function(audioBuffer) {
                const originalGetChannelData = audioBuffer.getChannelData;
                
                Object.defineProperty(audioBuffer, 'getChannelData', {
                    value: function() {
                        const results = originalGetChannelData.apply(this, arguments);
                        
                        // Apenas adicionar noise ao buffer de tamanho específico usado em fingerprinting
                        if (this.length >= 100 && this.length <= 5000) {
                            // Verificar se o buffer já teve ruído adicionado
                            if (!this._noisedBuffer) {
                                addNoise(this);
                                this._noisedBuffer = true;
                            }
                        }
                        
                        return results;
                    }
                });
            };
            
            // Proxy para createOscillator comum em técnicas de fingerprinting
            if (originalAudioContextConstructor && originalAudioContextConstructor.prototype) {
                const originalCreateOscillator = originalAudioContextConstructor.prototype.createOscillator;
                Object.defineProperty(originalAudioContextConstructor.prototype, 'createOscillator', {
                    value: function() {
                        const oscillator = originalCreateOscillator.apply(this, arguments);
                        
                        // Adicionar pequena variação aos valores de frequência
                        const originalFrequency = oscillator.frequency.value;
                        Object.defineProperty(oscillator.frequency, 'value', {
                            get: function() {
                                return originalFrequency;
                            },
                            set: function(newValue) {
                                // Adicionar perturbação sutil à frequência
                                const deviceId = window._stealth.fingerprint.getDeviceId();
                                const char = deviceId.charCodeAt(0);
                                const tinyOffset = char / 10000; // Perturbação muito sutil
                                
                                return originalFrequency = newValue + tinyOffset;
                            }
                        });
                        
                        return oscillator;
                    }
                });
            }
            
            // Hook para OfflineAudioContext
            if (originalOfflineAudioContextConstructor) {
                window.OfflineAudioContext = function(a, b, c) {
                    const instance = new originalOfflineAudioContextConstructor(a, b, c);
                    
                    // Hook para createBuffer
                    const originalCreateBuffer = instance.createBuffer;
                    if (originalCreateBuffer) {
                        Object.defineProperty(instance, 'createBuffer', {
                            value: function() {
                                const buffer = originalCreateBuffer.apply(this, arguments);
                                createAudioBufferProxy(buffer);
                                return buffer;
                            }
                        });
                    }
                    
                    return instance;
                };
                
                window.OfflineAudioContext.prototype = originalOfflineAudioContextConstructor.prototype;
            }
        })();
        """
        
        self.driver.execute_script(script)
    
    def _apply_touch_points(self) -> None:
        """
        Configura e manipula propriedades de pontos de toque
        """
        script = f"""
        (function() {{
            const hasTouch = {str(self.profile["hasTouch"]).lower()};
            
            window._stealth.setProperty(navigator, 'maxTouchPoints', hasTouch ? 5 : 0);
            
            if ('ontouchstart' in window === !hasTouch) {{
                if (hasTouch) {{
                    window.ontouchstart = function() {{}};
                }} else {{
                    delete window.ontouchstart;
                }}
            }}
        }})();
        """
        
        self.driver.execute_script(script)
    
    def _apply_codec_profiles(self) -> None:
        """
        Configura propriedades de codecs de vídeo e áudio
        """
        video_codecs = json.dumps(self.profile["videoCodecs"])
        audio_codecs = json.dumps(self.profile["audioCodecs"])
        
        script = f"""
        (function() {{
            const videoCodecs = {video_codecs};
            const audioCodecs = {audio_codecs};
            
            // Sobrescrever HTMLMediaElement.canPlayType
            const originalCanPlayType = HTMLMediaElement.prototype.canPlayType;
            window._stealth.setProperty(HTMLMediaElement.prototype, 'canPlayType', function(contentType) {{
                // Verificar se é um codec de vídeo conhecido
                for (const codec of videoCodecs) {{
                    if (contentType.includes(codec)) {{
                        return "probably";
                    }}
                }}
                
                // Verificar se é um codec de áudio conhecido
                for (const codec of audioCodecs) {{
                    if (contentType.includes(codec)) {{
                        return "probably";
                    }}
                }}
                
                // Retornar o resultado original para outros tipos
                return originalCanPlayType.apply(this, arguments);
            }});
            
            // Opcional: Sobrescrever MediaSource.isTypeSupported
            if (window.MediaSource && MediaSource.isTypeSupported) {{
                const originalIsTypeSupported = MediaSource.isTypeSupported;
                window._stealth.setProperty(MediaSource, 'isTypeSupported', function(contentType) {{
                    // Similar à implementação acima
                    for (const codec of videoCodecs.concat(audioCodecs)) {{
                        if (contentType.includes(codec)) {{
                            return true;
                        }}
                    }}
                    
                    return originalIsTypeSupported.apply(this, arguments);
                }});
            }}
        }})();
        """
        
        self.driver.execute_script(script)
    
    def _apply_outerHeight_width(self) -> None:
        """
        Modifica as propriedades outerHeight e outerWidth da janela
        """
        width = self.profile["screen"]["width"]
        height = self.profile["screen"]["height"]
        
        script = f"""
        (function() {{
            window._stealth.setProperty(window, 'outerWidth', {width});
            window._stealth.setProperty(window, 'outerHeight', {height});
        }})();
        """
        
        self.driver.execute_script(script)
    
    def _apply_connection_rtt(self) -> None:
        """
        Configura propriedades de conexão realistas
        """
        rtt = self.profile["connection"]["rtt"]
        downlink = self.profile["connection"]["downlink"]
        effective_type = self.profile["connection"]["effectiveType"]
        
        script = f"""
        (function() {{
            if (navigator.connection) {{
                window._stealth.setProperty(navigator.connection, 'rtt', {rtt});
                window._stealth.setProperty(navigator.connection, 'downlink', {downlink});
                window._stealth.setProperty(navigator.connection, 'effectiveType', '{effective_type}');
                window._stealth.setProperty(navigator.connection, 'saveData', false);
            }}
        }})();
        """
        
        self.driver.execute_script(script)
    
    def _apply_random_delays(self) -> None:
        """
        Adiciona atrasos aleatórios a determinadas operações JavaScript
        """
        script = """
        (function() {
            // Criar versões mais lentas e aleatórias
            const originalSetTimeout = window.setTimeout;
            const originalSetInterval = window.setInterval;
            const originalRequestAnimationFrame = window.requestAnimationFrame;
            
            window._stealth.setProperty(window, 'setTimeout', function(handler, timeout, ...args) {
                // Adicionar atraso aleatório apenas para timeouts curtos
                if (timeout < 100) {
                    timeout += Math.random() * 10;
                }
                return originalSetTimeout.call(this, handler, timeout, ...args);
            });
            
            window._stealth.setProperty(window, 'setInterval', function(handler, timeout, ...args) {
                // Adicionar atraso aleatório apenas para intervalos curtos
                if (timeout < 100) {
                    timeout += Math.random() * 10;
                }
                return originalSetInterval.call(this, handler, timeout, ...args);
            });
            
            window._stealth.setProperty(window, 'requestAnimationFrame', function(callback) {
                return originalRequestAnimationFrame.call(this, function(timestamp) {
                    // Adicionar um pequeno atraso aleatório
                    const delay = Math.random() * 5;
                    setTimeout(function() {
                        callback(timestamp + delay);
                    }, delay);
                });
            });
        })();
        """
        
        self.driver.execute_script(script)
    
    def _apply_additional_fingerprint_protections(self) -> None:
        """
        Aplica proteções adicionais contra fingerprinting
        """
        script = """
        (function() {
            // Proteger canvas fingerprinting
            const originalToDataURL = HTMLCanvasElement.prototype.toDataURL;
            const originalGetImageData = CanvasRenderingContext2D.prototype.getImageData;
            
            window._stealth.setProperty(HTMLCanvasElement.prototype, 'toDataURL', function() {
                // Se for chamado com propósito de fingerprinting, retorne um valor consistente
                const fillColor = this.getContext('2d').fillStyle;
                if (fillColor === '#fff' || fillColor === '#ffffff' || fillColor === 'white') {
                    const dataSize = this.width + "x" + this.height;
                    if ((dataSize === "16x16" || dataSize === "1x1" || dataSize === "0x0") ||
                        (this.width <= 200 && this.height <= 200)) {
                        return window._stealth.fingerprint.getCanvasFingerprint();
                    }
                }
                
                return originalToDataURL.apply(this, arguments);
            });
            
            window._stealth.setProperty(CanvasRenderingContext2D.prototype, 'getImageData', function() {
                const width = arguments[2];
                const height = arguments[3];
                
                // Detectar fingerprinting através de tamanho da área lida
                if (width === 16 && height === 16) {
                    // Consistentemente aleatório
                    const deviceId = window._stealth.fingerprint.getDeviceId();
                    const hashCode = str => {
                        let hash = 0;
                        for (let i = 0; i < str.length; i++) {
                            hash = ((hash << 5) - hash) + str.charCodeAt(i);
                            hash |= 0;
                        }
                        return hash;
                    };
                    
                    // Obter dados originais
                    const originalData = originalGetImageData.apply(this, arguments);
                    
                    // Modificar sutilmente cada 10º pixel
                    const idHash = hashCode(deviceId);
                    for (let i = 0; i < originalData.data.length; i += 40) {
                        const pixelOffset = (idHash + i) % 3;
                        if (pixelOffset < 3) {
                            originalData.data[i + pixelOffset] = 
                                (originalData.data[i + pixelOffset] + (idHash % 10)) % 256;
                        }
                    }
                    
                    return originalData;
                }
                
                return originalGetImageData.apply(this, arguments);
            });
            
            // Proteger performance.now() contra timing attacks
            const originalNow = window.performance.now;
            window._stealth.setProperty(window.performance, 'now', function() {
                const originalResult = originalNow.call(this);
                // Adicionar ruído mínimo para dificultar fingerprinting
                const noise = Math.random() * 0.01;
                return originalResult + noise;
            });
            
            // Sobrescrever propriedades do objeto screen para evitar inconsistências
            const screenValues = {
                width: window.screen.width,
                height: window.screen.height,
                availWidth: window.screen.availWidth,
                availHeight: window.screen.availHeight,
                colorDepth: window.screen.colorDepth,
                pixelDepth: window.screen.pixelDepth
            };
            
            for (const [key, value] of Object.entries(screenValues)) {
                window._stealth.setProperty(window.screen, key, value);
            }
        })();
        """
        
        self.driver.execute_script(script)
    
    def rotate_identity(self) -> None:
        """
        Troca de fingerprint e identidade do navegador
        """
        if self.driver is None:
            logger.warning("Nenhum WebDriver disponível para rotacionar identidade")
            return
        
        # Criar novo perfil
        self.profile = self._load_profile()
        
        # Limpar cookies e armazenamento
        try:
            self.driver.delete_all_cookies()
            self.driver.execute_script("""
                localStorage.clear();
                sessionStorage.clear();
                
                // Limpar IndexedDB
                if (window.indexedDB) {
                    const databases = await window.indexedDB.databases();
                    databases.forEach(db => window.indexedDB.deleteDatabase(db.name));
                }
                
                // Limpar cache de ServiceWorker
                if (navigator.serviceWorker) {
                    navigator.serviceWorker.getRegistrations().then(registrations => {
                        registrations.forEach(registration => registration.unregister());
                    });
                }
            """)
        except Exception as e:
            logger.warning(f"Erro ao limpar dados ao rotacionar identidade: {str(e)}")
        
        # Reaplicar técnicas de evasão
        self.apply_evasion_techniques()
        
        logger.info("Identidade do navegador rotacionada com sucesso")
        
        return self.profile
    
    def inject_custom_scripts(self, scripts: List[str]) -> None:
        """
        Injeta scripts personalizados de evasão
        
        Args:
            scripts: Lista de strings com código JavaScript
        """
        if self.driver is None:
            logger.warning("Nenhum WebDriver disponível para injetar scripts")
            return
        
        for script in scripts:
            try:
                self.driver.execute_script(script)
            except Exception as e:
                logger.warning(f"Erro ao injetar script personalizado: {str(e)}")
    
    def inject_stealth_on_load(self) -> None:
        """
        Configura scripts de evasão para serem injetados em cada carregamento de página
        """
        if self.driver is None:
            logger.warning("Nenhum WebDriver disponível para configurar injeção em cada carregamento")
            return
        
        try:
            # Registrar executor de script via CDP (Chrome DevTools Protocol)
            self.driver.execute_cdp_cmd('Page.addScriptToEvaluateOnNewDocument', {
                'source': """
                // Código base de evasão que será executado antes de qualquer script da página
                (function() {
                    // Ocultar sinais de automação
                    Object.defineProperty(navigator, 'webdriver', {
                        get: () => undefined
                    });
                    
                    // Ocultar sinais de selenium, chrome driver, etc.
                    const properties = [
                        'webdriver', '__driver_evaluate', '__webdriver_evaluate',
                        '__selenium_evaluate', '__fxdriver_evaluate', '__driver_unwrapped',
                        '__webdriver_unwrapped', '__selenium_unwrapped', '__fxdriver_unwrapped',
                        '_Selenium_IDE_Recorder', '_selenium', 'calledSelenium',
                        '_WEBDRIVER_ELEM_CACHE', 'ChromeDriverw', 'driver-evaluate',
                        'webdriver-evaluate', 'selenium-evaluate', 'webdriverCommand',
                        'webdriver-evaluate-response', '__webdriverFunc', '__webdriver_script_fn',
                        '__$webdriverAsyncExecutor', '__lastWatirAlert', '__lastWatirConfirm',
                        '__lastWatirPrompt', '$chrome_asyncScriptInfo', '$cdc_asdjflasutopfhvcZLmcfl_'
                    ];
                    
                    // Limpar propriedades
                    for (const property of properties) {
                        if (property in window) {
                            delete window[property];
                        }
                        if (property in document) {
                            delete document[property];
                        }
                    }
                    
                    // Notificação para quando a página estiver pronta
                    document.addEventListener('DOMContentLoaded', function() {
                        // Sinal para o executor stealth que a página carregou
                        window.__stealthPageLoaded = true;
                    });
                })();
                """
            })
            
            logger.info("Injeção de stealth configurada para cada carregamento de página")
        except Exception as e:
            logger.warning(f"Erro ao configurar injeção em cada carregamento: {str(e)}")


def create_browser_stealth(driver=None, config: Dict[str, Any] = None) -> BrowserStealth:
    """
    Cria uma instância configurada do BrowserStealth
    
    Args:
        driver: WebDriver opcional
        config: Configurações opcionais
        
    Returns:
        Instância de BrowserStealth
    """
    return BrowserStealth(driver, config)