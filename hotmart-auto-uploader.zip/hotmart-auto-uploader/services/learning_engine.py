"""
Learning Engine Service
-------------------
Provides machine learning capabilities for continuous improvement of the system.
Learns from successful and failed upload attempts to improve future performance.
"""

import os
import json
import time
import logging
import random
import numpy as np
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Any, Tuple, Optional
from collections import defaultdict

from app import db
from models import UIElement, UploadSession, Product, SystemConfig

# Configure logger
logger = logging.getLogger(__name__)

class LearningEngine:
    """
    Machine learning system for continuous improvement of system behavior.
    """
    
    def __init__(self, config=None):
        """
        Initialize the learning engine.
        
        Args:
            config: Optional configuration dictionary
        """
        self.config = config or {}
        self.learning_rate = self.config.get("learning_rate", 0.1)
        self.exploration_rate = self.config.get("exploration_rate", 0.2)  # Exploration vs exploitation
        self.success_patterns = {}
        self.failure_patterns = {}
        self.element_scores = defaultdict(lambda: {"success": 0, "failure": 0})
        self.behavior_models = {}
        self.lock = threading.RLock()
        
        # Performance tracking
        self.performance_metrics = {
            "success_rate": [],
            "avg_upload_time": [],
            "error_rate": [],
            "adaptation_rate": []
        }
        
        # Load cached learning data if available
        self._load_cached_data()
        
        logger.info("Learning engine initialized")
    
    def _load_cached_data(self):
        """Load cached learning data from disk."""
        try:
            cache_file = "data/learning_data.json"
            if os.path.exists(cache_file):
                with open(cache_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                
                # Load patterns and scores
                self.success_patterns = data.get("success_patterns", {})
                self.failure_patterns = data.get("failure_patterns", {})
                
                # Convert defaultdict
                element_scores = data.get("element_scores", {})
                for key, value in element_scores.items():
                    self.element_scores[key] = value
                
                # Performance metrics
                self.performance_metrics = data.get("performance_metrics", self.performance_metrics)
                
                logger.info(f"Loaded cached learning data: {len(self.success_patterns)} success patterns, "
                           f"{len(self.failure_patterns)} failure patterns")
            else:
                logger.info("No cached learning data found")
        except Exception as e:
            logger.error(f"Error loading cached learning data: {str(e)}")
    
    def _save_cached_data(self):
        """Save learning data to disk for persistence."""
        try:
            # Ensure directory exists
            os.makedirs("data", exist_ok=True)
            
            cache_file = "data/learning_data.json"
            
            # Prepare data for serialization
            data = {
                "success_patterns": self.success_patterns,
                "failure_patterns": self.failure_patterns,
                "element_scores": dict(self.element_scores),
                "performance_metrics": self.performance_metrics,
                "last_updated": datetime.now().isoformat()
            }
            
            with open(cache_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            
            logger.info("Saved learning data to cache")
        except Exception as e:
            logger.error(f"Error saving learning data: {str(e)}")
    
    def learn_from_session(self, session_id: str) -> bool:
        """
        Learn from an upload session to improve future performance.
        
        Args:
            session_id: ID of the upload session to learn from
            
        Returns:
            bool: True if learning was successful
        """
        with self.lock:
            try:
                logger.info(f"Learning from session {session_id}")
                
                # Get session data from database
                session = UploadSession.query.filter_by(session_id=session_id).first()
                
                if not session:
                    logger.warning(f"Session {session_id} not found")
                    return False
                
                # Get products in this session
                products = Product.query.filter(
                    Product.id.in_(session.config.get("product_ids", [])) if session.config else False
                ).all()
                
                if not products:
                    logger.warning(f"No products found for session {session_id}")
                    return False
                
                # Calculate success rate
                success_count = 0
                failure_count = 0
                
                for product in products:
                    if product.status == "uploaded":
                        success_count += 1
                        self._learn_from_success(product, session)
                    elif product.status == "failed":
                        failure_count += 1
                        self._learn_from_failure(product, session)
                
                total_attempts = success_count + failure_count
                if total_attempts > 0:
                    success_rate = success_count / total_attempts
                    self.performance_metrics["success_rate"].append(success_rate)
                    
                    # Trim performance metrics to last 100 entries
                    if len(self.performance_metrics["success_rate"]) > 100:
                        self.performance_metrics["success_rate"] = self.performance_metrics["success_rate"][-100:]
                    
                    logger.info(f"Session {session_id} learning complete: "
                               f"{success_count} successes, {failure_count} failures, "
                               f"{success_rate:.2%} success rate")
                    
                    # Update UI elements with session data
                    self._update_ui_elements(session)
                    
                    # Save updated learning data
                    self._save_cached_data()
                    
                    return True
                else:
                    logger.warning(f"No completed attempts found in session {session_id}")
                    return False
                
            except Exception as e:
                logger.error(f"Error learning from session: {str(e)}")
                return False
    
    def _learn_from_success(self, product: Product, session: UploadSession) -> None:
        """
        Learn from a successful product upload.
        
        Args:
            product: Successfully uploaded product
            session: Upload session
        """
        try:
            # Extract features from successful upload
            product_type = product.format_type or "unknown"
            features = {
                "product_type": product_type,
                "file_size": product.file_size,
                "price": product.price,
                "description_length": len(product.description or "") if product.description else 0,
                "title_length": len(product.title) if product.title else 0,
                "browser": session.config.get("browser") if session.config else "unknown",
                "upload_duration": session.calculate_duration() / max(1, session.total_products)
            }
            
            # Store success pattern
            key = f"{product_type}_{int(time.time())}"
            self.success_patterns[key] = features
            
            # Trim patterns if too many
            if len(self.success_patterns) > 1000:
                # Remove oldest entries
                keys_to_remove = sorted(self.success_patterns.keys())[:len(self.success_patterns) - 1000]
                for k in keys_to_remove:
                    self.success_patterns.pop(k, None)
            
            logger.debug(f"Learned success pattern for product type: {product_type}")
            
        except Exception as e:
            logger.error(f"Error learning from success: {str(e)}")
    
    def _learn_from_failure(self, product: Product, session: UploadSession) -> None:
        """
        Learn from a failed product upload.
        
        Args:
            product: Failed product upload
            session: Upload session
        """
        try:
            # Extract features from failed upload
            product_type = product.format_type or "unknown"
            features = {
                "product_type": product_type,
                "file_size": product.file_size,
                "price": product.price,
                "description_length": len(product.description or "") if product.description else 0,
                "title_length": len(product.title) if product.title else 0,
                "browser": session.config.get("browser") if session.config else "unknown",
                "error_details": product.error_details,
                "upload_duration": session.calculate_duration() / max(1, session.total_products)
            }
            
            # Store failure pattern
            key = f"{product_type}_{int(time.time())}"
            self.failure_patterns[key] = features
            
            # Trim patterns if too many
            if len(self.failure_patterns) > 1000:
                # Remove oldest entries
                keys_to_remove = sorted(self.failure_patterns.keys())[:len(self.failure_patterns) - 1000]
                for k in keys_to_remove:
                    self.failure_patterns.pop(k, None)
            
            logger.debug(f"Learned failure pattern for product type: {product_type}")
            
        except Exception as e:
            logger.error(f"Error learning from failure: {str(e)}")
    
    def _update_ui_elements(self, session: UploadSession) -> None:
        """
        Update UI element scores based on session data.
        
        Args:
            session: Upload session
        """
        try:
            # Get UI elements used in this session
            elements = UIElement.query.all()
            
            # Update scores based on session outcome
            for element in elements:
                if element.last_used and element.last_used > session.start_time:
                    # This element was used in the session
                    
                    # Calculate success contribution
                    if session.successful_uploads > 0:
                        # Increase success score
                        element.success_count += 1
                        self.element_scores[element.element_name]["success"] += 1
                    
                    if session.failed_uploads > 0:
                        # Increase failure score
                        element.failure_count += 1
                        self.element_scores[element.element_name]["failure"] += 1
                    
                    # Update last used timestamp
                    element.last_used = datetime.utcnow()
                    
                    db.session.add(element)
            
            db.session.commit()
            
        except Exception as e:
            logger.error(f"Error updating UI elements: {str(e)}")
            db.session.rollback()
    
    def recommend_product_settings(self, product_type: str) -> Dict[str, Any]:
        """
        Recommend optimal settings for a product based on learned patterns.
        
        Args:
            product_type: Type of product
            
        Returns:
            Dict with recommended settings
        """
        with self.lock:
            try:
                # Get success patterns for this product type
                type_patterns = {k: v for k, v in self.success_patterns.items() 
                                if v.get("product_type") == product_type}
                
                if not type_patterns:
                    # No patterns for this type, use general recommendations
                    logger.info(f"No success patterns for {product_type}, using general recommendations")
                    return self._get_default_recommendations(product_type)
                
                # Calculate average values for successful uploads
                avg_price = sum(p.get("price", 0) for p in type_patterns.values()) / max(1, len(type_patterns))
                
                # Add some randomness to avoid detection
                price_variance = 0.1  # 10% variance
                recommended_price = avg_price * random.uniform(1 - price_variance, 1 + price_variance)
                
                # Get optimal description length
                desc_lengths = [p.get("description_length", 0) for p in type_patterns.values()]
                optimal_desc_length = sum(desc_lengths) / max(1, len(desc_lengths))
                
                # Get optimal title length
                title_lengths = [p.get("title_length", 0) for p in type_patterns.values()]
                optimal_title_length = sum(title_lengths) / max(1, len(title_lengths))
                
                logger.info(f"Generated recommendations for {product_type} from {len(type_patterns)} patterns")
                
                return {
                    "recommended_price": round(recommended_price, 2),
                    "optimal_description_length": int(optimal_desc_length),
                    "optimal_title_length": int(optimal_title_length),
                    "confidence": min(0.3 + (len(type_patterns) * 0.05), 0.95)  # Higher with more data
                }
                
            except Exception as e:
                logger.error(f"Error generating recommendations: {str(e)}")
                return self._get_default_recommendations(product_type)
    
    def _get_default_recommendations(self, product_type: str) -> Dict[str, Any]:
        """
        Get default recommendations when no learned data is available.
        
        Args:
            product_type: Type of product
            
        Returns:
            Dict with default recommendations
        """
        # Default values based on product type
        defaults = {
            "ebook": {
                "recommended_price": 47.0,
                "optimal_description_length": 300,
                "optimal_title_length": 60
            },
            "course": {
                "recommended_price": 197.0,
                "optimal_description_length": 500,
                "optimal_title_length": 70
            },
            "mentoria": {
                "recommended_price": 297.0,
                "optimal_description_length": 400,
                "optimal_title_length": 65
            },
            "software": {
                "recommended_price": 97.0,
                "optimal_description_length": 350,
                "optimal_title_length": 55
            },
            "assinatura": {
                "recommended_price": 27.0,
                "optimal_description_length": 450,
                "optimal_title_length": 60
            }
        }
        
        # Return defaults with low confidence
        result = defaults.get(product_type, defaults["ebook"]).copy()
        result["confidence"] = 0.3  # Low confidence for default values
        
        return result
    
    def get_optimal_selector(self, element_name: str, url_pattern: str) -> Dict[str, Any]:
        """
        Get the optimal selector strategy for a UI element based on learning.
        
        Args:
            element_name: Name of the UI element
            url_pattern: URL pattern where the element appears
            
        Returns:
            Dict with selector strategy
        """
        with self.lock:
            try:
                # Get all selectors for this element from database
                elements = UIElement.query.filter_by(
                    element_name=element_name,
                    page_url_pattern=url_pattern
                ).all()
                
                if not elements:
                    logger.warning(f"No selectors found for {element_name} on {url_pattern}")
                    return {"selectors": [], "confidence": 0}
                
                # Sort by success rate
                elements.sort(key=lambda e: e.calculate_success_rate(), reverse=True)
                
                # Get top selector
                top_element = elements[0]
                
                # Calculate confidence based on sample size
                total_attempts = top_element.success_count + top_element.failure_count
                confidence = min(0.3 + (total_attempts * 0.05), 0.95) if total_attempts > 0 else 0.3
                
                # If we have good confidence, return the best selector
                if confidence > 0.7 and random.random() > self.exploration_rate:
                    logger.info(f"Using best selector for {element_name} (confidence: {confidence:.2f})")
                    return {
                        "selectors": top_element.selector_strategy.get("selectors", []),
                        "confidence": confidence
                    }
                
                # Otherwise, explore alternative selectors
                alternative_selectors = []
                weights = []
                
                for element in elements:
                    success_rate = element.calculate_success_rate()
                    attempts = element.success_count + element.failure_count
                    
                    # Weight by success rate and number of attempts
                    weight = success_rate * min(1.0, attempts / 10)
                    
                    alternative_selectors.append(element.selector_strategy.get("selectors", []))
                    weights.append(max(0.1, weight))  # Ensure minimum weight
                
                # Normalize weights
                total_weight = sum(weights)
                if total_weight > 0:
                    weights = [w / total_weight for w in weights]
                else:
                    weights = [1.0 / len(weights)] * len(weights)
                
                # Select a strategy based on weights
                selected_idx = np.random.choice(len(alternative_selectors), p=weights)
                selected_selectors = alternative_selectors[selected_idx]
                
                logger.info(f"Exploring alternative selector for {element_name} (confidence: {confidence:.2f})")
                
                return {
                    "selectors": selected_selectors,
                    "confidence": confidence * 0.8  # Reduce confidence for exploration
                }
                
            except Exception as e:
                logger.error(f"Error getting optimal selector: {str(e)}")
                return {"selectors": [], "confidence": 0}
    
    def learn_new_selector(self, element_name: str, url_pattern: str, 
                          selectors: List[str], success: bool) -> bool:
        """
        Learn a new selector for a UI element.
        
        Args:
            element_name: Name of the UI element
            url_pattern: URL pattern where the element appears
            selectors: List of CSS selectors
            success: Whether the selector was successful
            
        Returns:
            bool: True if learning was successful
        """
        with self.lock:
            try:
                # Check if this selector already exists
                element = UIElement.query.filter_by(
                    element_name=element_name,
                    page_url_pattern=url_pattern
                ).filter(
                    UIElement.selector_strategy['selectors'].astext.contains(json.dumps(selectors))
                ).first()
                
                if element:
                    # Update existing element
                    if success:
                        element.success_count += 1
                    else:
                        element.failure_count += 1
                    
                    element.last_used = datetime.utcnow()
                    
                    db.session.add(element)
                    db.session.commit()
                    
                    logger.debug(f"Updated existing selector for {element_name}")
                else:
                    # Create new element
                    new_element = UIElement(
                        element_name=element_name,
                        description=f"Learned selector for {element_name}",
                        page_url_pattern=url_pattern,
                        selector_strategy={
                            "selectors": selectors,
                            "confidence": 0.5,
                            "created_at": datetime.utcnow().isoformat()
                        },
                        success_count=1 if success else 0,
                        failure_count=0 if success else 1,
                        last_used=datetime.utcnow()
                    )
                    
                    db.session.add(new_element)
                    db.session.commit()
                    
                    logger.info(f"Learned new selector for {element_name}")
                
                # Update in-memory scores
                self.element_scores[element_name]["success"] += 1 if success else 0
                self.element_scores[element_name]["failure"] += 0 if success else 1
                
                return True
                
            except Exception as e:
                logger.error(f"Error learning new selector: {str(e)}")
                db.session.rollback()
                return False
    
    def run_learning_cycle(self) -> Dict[str, Any]:
        """
        Run a complete learning cycle to optimize the system.
        
        Returns:
            Dict with results of the learning cycle
        """
        with self.lock:
            try:
                logger.info("Starting learning cycle")
                start_time = time.time()
                
                # Step 1: Analyze recent sessions
                recent_sessions = UploadSession.query.filter(
                    UploadSession.end_time > (datetime.utcnow() - timedelta(days=7))
                ).order_by(UploadSession.end_time.desc()).limit(20).all()
                
                session_count = 0
                for session in recent_sessions:
                    if self.learn_from_session(session.session_id):
                        session_count += 1
                
                # Step 2: Optimize UI selectors
                optimized_count = self._optimize_selectors()
                
                # Step 3: Update system configuration
                updated_config = self._update_system_config()
                
                # Step 4: Save data and calculate metrics
                self._save_cached_data()
                
                duration = time.time() - start_time
                
                logger.info(f"Learning cycle completed in {duration:.2f}s: "
                           f"{session_count} sessions analyzed, {optimized_count} selectors optimized")
                
                return {
                    "success": True,
                    "sessions_analyzed": session_count,
                    "selectors_optimized": optimized_count,
                    "config_updated": updated_config,
                    "duration_seconds": duration,
                    "timestamp": datetime.utcnow().isoformat()
                }
                
            except Exception as e:
                logger.error(f"Error in learning cycle: {str(e)}")
                return {
                    "success": False,
                    "error": str(e),
                    "timestamp": datetime.utcnow().isoformat()
                }
    
    def _optimize_selectors(self) -> int:
        """
        Optimize UI selectors based on success rates.
        
        Returns:
            int: Number of optimized selectors
        """
        try:
            # Group elements by name and URL pattern
            elements = UIElement.query.all()
            grouped = defaultdict(list)
            
            for element in elements:
                key = f"{element.element_name}|{element.page_url_pattern}"
                grouped[key].append(element)
            
            optimized_count = 0
            
            # For each group, find the best performer
            for key, group in grouped.items():
                if len(group) <= 1:
                    continue
                
                # Sort by success rate
                group.sort(key=lambda e: e.calculate_success_rate(), reverse=True)
                
                best = group[0]
                worst = group[-1]
                
                # If the best is significantly better than the worst, remove the worst
                if (best.calculate_success_rate() > 0.8 and 
                    worst.calculate_success_rate() < 0.3 and
                    best.success_count + best.failure_count > 5):
                    
                    db.session.delete(worst)
                    optimized_count += 1
                    
                    logger.debug(f"Removed low-performing selector for {best.element_name}")
            
            if optimized_count > 0:
                db.session.commit()
                logger.info(f"Optimized {optimized_count} selectors")
            
            return optimized_count
            
        except Exception as e:
            logger.error(f"Error optimizing selectors: {str(e)}")
            db.session.rollback()
            return 0
    
    def _update_system_config(self) -> bool:
        """
        Update system configuration based on learning.
        
        Returns:
            bool: True if configuration was updated
        """
        try:
            # Get current config
            system_config = SystemConfig.query.filter_by(config_name='upload_settings').first()
            
            if not system_config:
                logger.warning("System configuration not found, creating new one")
                system_config = SystemConfig(
                    config_name='upload_settings',
                    config_value={
                        'auto_upload': True,
                        'max_concurrent_sessions': 1,
                        'products_per_session': 5,
                        'time_between_sessions': 30,
                        'default_browser': 'chrome',
                        'stealth_mode': True
                    }
                )
                db.session.add(system_config)
                db.session.commit()
                return True
            
            # Calculate optimal values based on performance
            success_rates = self.performance_metrics.get("success_rate", [])
            
            if not success_rates:
                logger.info("No performance metrics available for config optimization")
                return False
            
            current_config = system_config.config_value or {}
            updated = False
            
            # Calculate overall success rate
            avg_success_rate = sum(success_rates) / len(success_rates) if success_rates else 0
            
            # Adjust batch size based on success rate
            current_batch_size = current_config.get('products_per_session', 5)
            
            if avg_success_rate > 0.9 and current_batch_size < 10:
                # High success rate, increase batch size
                current_config['products_per_session'] = min(10, current_batch_size + 1)
                updated = True
                logger.info(f"Increased batch size to {current_config['products_per_session']}")
            elif avg_success_rate < 0.5 and current_batch_size > 1:
                # Low success rate, decrease batch size
                current_config['products_per_session'] = max(1, current_batch_size - 1)
                updated = True
                logger.info(f"Decreased batch size to {current_config['products_per_session']}")
            
            # Adjust time between sessions
            current_interval = current_config.get('time_between_sessions', 30)
            
            if avg_success_rate < 0.3:
                # Very low success rate, increase interval
                current_config['time_between_sessions'] = min(120, current_interval + 15)
                updated = True
                logger.info(f"Increased time between sessions to {current_config['time_between_sessions']} minutes")
            elif avg_success_rate > 0.8 and current_interval > 20:
                # High success rate, decrease interval
                current_config['time_between_sessions'] = max(20, current_interval - 5)
                updated = True
                logger.info(f"Decreased time between sessions to {current_config['time_between_sessions']} minutes")
            
            if updated:
                system_config.config_value = current_config
                system_config.updated_at = datetime.utcnow()
                db.session.add(system_config)
                db.session.commit()
                
                logger.info("Updated system configuration based on learning")
                return True
            else:
                logger.info("No system configuration updates needed")
                return False
            
        except Exception as e:
            logger.error(f"Error updating system configuration: {str(e)}")
            db.session.rollback()
            return False
    
    def optimize(self) -> bool:
        """
        Optimize the learning system by cleaning up and consolidating data.
        
        Returns:
            bool: True if optimization was successful
        """
        with self.lock:
            try:
                logger.info("Optimizing learning engine")
                
                # Clean up old patterns
                success_count = len(self.success_patterns)
                failure_count = len(self.failure_patterns)
                
                # Keep only the latest 1000 patterns
                if success_count > 1000:
                    keys = sorted(self.success_patterns.keys())
                    for key in keys[:success_count - 1000]:
                        self.success_patterns.pop(key, None)
                
                if failure_count > 1000:
                    keys = sorted(self.failure_patterns.keys())
                    for key in keys[:failure_count - 1000]:
                        self.failure_patterns.pop(key, None)
                
                # Optimize selectors in database
                optimized_count = self._optimize_selectors()
                
                # Save optimized data
                self._save_cached_data()
                
                logger.info(f"Optimization complete: {success_count - len(self.success_patterns)} success patterns and "
                           f"{failure_count - len(self.failure_patterns)} failure patterns removed, "
                           f"{optimized_count} selectors optimized")
                
                return True
                
            except Exception as e:
                logger.error(f"Error optimizing learning engine: {str(e)}")
                return False
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """
        Get current performance metrics of the system.
        
        Returns:
            Dict with performance metrics
        """
        with self.lock:
            try:
                # Calculate overall metrics
                success_rates = self.performance_metrics.get("success_rate", [])
                avg_success_rate = sum(success_rates) / len(success_rates) if success_rates else 0
                
                # Get element statistics
                element_stats = {}
                for name, scores in self.element_scores.items():
                    total = scores["success"] + scores["failure"]
                    if total > 0:
                        success_rate = scores["success"] / total
                        element_stats[name] = {
                            "success_rate": success_rate,
                            "total_attempts": total
                        }
                
                # Get database statistics
                try:
                    element_count = UIElement.query.count()
                    recent_sessions = UploadSession.query.filter(
                        UploadSession.end_time > (datetime.utcnow() - timedelta(days=7))
                    ).count()
                    
                    recent_success = UploadSession.query.filter(
                        UploadSession.end_time > (datetime.utcnow() - timedelta(days=7)),
                        UploadSession.successful_uploads > 0
                    ).count()
                    
                    db_success_rate = recent_success / max(1, recent_sessions) if recent_sessions > 0 else 0
                    
                except Exception as e:
                    logger.error(f"Error getting database statistics: {str(e)}")
                    element_count = 0
                    recent_sessions = 0
                    db_success_rate = 0
                
                return {
                    "success_rate": avg_success_rate,
                    "element_count": element_count,
                    "recent_sessions": recent_sessions,
                    "db_success_rate": db_success_rate,
                    "learning_rate": self.learning_rate,
                    "exploration_rate": self.exploration_rate,
                    "pattern_count": {
                        "success": len(self.success_patterns),
                        "failure": len(self.failure_patterns)
                    },
                    "top_elements": sorted(
                        [
                            {
                                "name": name,
                                "success_rate": stats["success_rate"],
                                "attempts": stats["total_attempts"]
                            }
                            for name, stats in element_stats.items()
                            if stats["total_attempts"] > 5
                        ],
                        key=lambda x: x["success_rate"],
                        reverse=True
                    )[:10]
                }
                
            except Exception as e:
                logger.error(f"Error getting performance metrics: {str(e)}")
                return {
                    "error": str(e),
                    "success_rate": 0,
                    "element_count": 0,
                    "pattern_count": {"success": 0, "failure": 0}
                }
