"""
Hotmart API Service
---------------
Handles interactions with the Hotmart platform for product uploads.
"""

import os
import re
import time
import logging
import random
import json
import traceback
from typing import Dict, Any, Tuple, Optional, List
from datetime import datetime

from services.navigation import Navigator
from services.human_simulator import HumanSimulator
from attached_assets.batch_processor import BatchProcessor
from attached_assets.pricing_manager import PricingManager
from attached_assets.product_manager import ProductManager
from attached_assets.adaptive_intelligence import AdaptiveIntelligence
from attached_assets.logger import WebLogger

# Configure logger
logger = logging.getLogger(__name__)

class HotmartUploader:
    """
    Handles uploading products to the Hotmart platform.
    """
    
    def __init__(self, session_id=None, config=None):
        """
        Initialize the Hotmart uploader.
        
        Args:
            session_id: Session identifier for tracking
            config: Configuration dict with custom settings
        """
        self.session_id = session_id or f"session_{int(time.time())}"
        self.config = config or {}
        self.navigator = None
        self.web_logger = WebLogger(self.session_id)
        
        # Initialize components
        self.human_simulator = HumanSimulator(self.config.get("human_simulator", {}))
        self.batch_processor = BatchProcessor()
        self.product_manager = ProductManager()
        self.pricing_manager = None  # Will be initialized after navigator
        self.adaptive_intelligence = AdaptiveIntelligence()
        
        # Hotmart credentials
        self.hotmart_email = self.config.get("hotmart_email", os.environ.get("HOTMART_EMAIL"))
        self.hotmart_password = self.config.get("hotmart_password", os.environ.get("HOTMART_PASSWORD"))
        
        # URLs
        self.login_url = "https://app.hotmart.com/login"
        self.dashboard_url = "https://app.hotmart.com/dashboard"
        self.create_product_url = "https://app.hotmart.com/products/create"
        
        # State tracking
        self.is_logged_in = False
        self.login_attempts = 0
        self.max_login_attempts = 3
        self.upload_count = 0
        self.error_count = 0
        
        # Performance tracking
        self.start_time = None
        self.end_time = None
        
        self.web_logger.info(f"Hotmart uploader initialized with session ID: {self.session_id}")
    
    def initialize(self):
        """
        Initialize the uploader by setting up browser and logging in.
        
        Returns:
            bool: True if initialization was successful
        """
        try:
            self.start_time = time.time()
            
            # Initialize browser
            self.web_logger.info("Initializing browser...")
            self.navigator = Navigator(self.session_id, self.config.get("navigator", {}))
            
            if not self.navigator.initialize_browser():
                self.web_logger.error("Failed to initialize browser")
                return False
            
            # Initialize components that need navigator
            self.pricing_manager = PricingManager(self.navigator, self.human_simulator)
            self.adaptive_intelligence.set_driver(self.navigator.driver)
            
            # Login to Hotmart
            self.web_logger.info("Logging in to Hotmart...")
            login_result = self.login()
            
            if not login_result:
                self.web_logger.error("Failed to log in to Hotmart")
                return False
            
            self.web_logger.info("Initialization completed successfully")
            return True
            
        except Exception as e:
            self.web_logger.error(f"Error during initialization: {str(e)}")
            return False
    
    def login(self):
        """
        Log in to the Hotmart platform.
        
        Returns:
            bool: True if login was successful
        """
        if not self.navigator:
            self.web_logger.error("Navigator not initialized")
            return False
            
        if not self.hotmart_email or not self.hotmart_password:
            self.web_logger.error("Hotmart credentials not provided")
            return False
            
        try:
            # Navigate to login page
            if not self.navigator.navigate_to(self.login_url):
                self.web_logger.error("Failed to navigate to login page")
                return False
            
            # Wait for page to fully load
            time.sleep(2)
            
            # Check if already logged in
            dashboard_links = self.navigator.find_elements(
                "a[href*='dashboard'], .dashboard-link, [data-testid='dashboard-link']"
            )
            
            if dashboard_links:
                self.web_logger.info("Already logged in to Hotmart")
                self.is_logged_in = True
                return True
            
            # Look for login form with adaptive intelligence
            self.web_logger.info("Analyzing login page...")
            login_analysis = self.adaptive_intelligence.analyze_page("Hotmart login form")
            
            if not login_analysis.get("success", False):
                self.web_logger.warning("Failed to analyze login page, trying default selectors")
            
            # Find email input
            email_input = self.navigator.find_element(
                "input[type='email'], input[name='email'], input[id*='email'], input[placeholder*='email' i]",
                description="Email input field"
            )
            
            if not email_input:
                self.web_logger.error("Email input field not found")
                return False
            
            # Find password input
            password_input = self.navigator.find_element(
                "input[type='password'], input[name='password'], input[id*='password'], input[placeholder*='senha' i]",
                description="Password input field"
            )
            
            if not password_input:
                self.web_logger.error("Password input field not found")
                return False
            
            # Type email with human-like behavior
            self.web_logger.info("Entering email...")
            if not self.navigator.type_text(email_input, self.hotmart_email, description="email field"):
                self.web_logger.error("Failed to enter email")
                return False
            
            # Natural pause between fields
            self.human_simulator.natural_pause()
            
            # Type password with human-like behavior
            self.web_logger.info("Entering password...")
            if not self.navigator.type_text(password_input, self.hotmart_password, description="password field"):
                self.web_logger.error("Failed to enter password")
                return False
            
            # Find login button
            login_button = self.navigator.find_element(
                "button[type='submit'], button.login-button, button:contains('Entrar'), [data-testid='login-button']",
                description="Login button"
            )
            
            if not login_button:
                self.web_logger.error("Login button not found")
                return False
            
            # Click login button
            self.web_logger.info("Clicking login button...")
            if not self.navigator.click(login_button, description="login button"):
                self.web_logger.error("Failed to click login button")
                return False
            
            # Wait for dashboard to load
            self.web_logger.info("Waiting for dashboard...")
            
            # Create a function to check if login was successful
            def check_login_success():
                # Check URL
                current_url = self.navigator.get_url()
                if current_url and ("dashboard" in current_url or "home" in current_url):
                    return True
                
                # Check for dashboard elements
                dashboard_elements = self.navigator.find_elements(
                    ".dashboard-container, [data-testid='dashboard'], .home-container"
                )
                
                if dashboard_elements:
                    return True
                
                # Check for user menu or profile
                user_menu = self.navigator.find_elements(
                    ".user-menu, .profile-menu, [data-testid='user-menu']"
                )
                
                if user_menu:
                    return True
                
                return False
            
            # Wait for login to complete with timeout
            max_wait = 30  # seconds
            start_time = time.time()
            login_successful = False
            
            while time.time() - start_time < max_wait:
                if check_login_success():
                    login_successful = True
                    break
                
                # Check for errors
                error_messages = self.navigator.find_elements(
                    ".error-message, .alert-danger, [data-testid='error-message']"
                )
                
                if error_messages:
                    error_text = self.navigator.get_element_text(error_messages[0])
                    self.web_logger.error(f"Login error: {error_text}")
                    return False
                
                # Continue waiting
                time.sleep(1)
            
            if login_successful:
                self.web_logger.info("Login successful")
                self.is_logged_in = True
                return True
            else:
                self.web_logger.error("Login timed out or failed")
                
                # Increment login attempts
                self.login_attempts += 1
                
                # If we've reached max attempts, give up
                if self.login_attempts >= self.max_login_attempts:
                    self.web_logger.error(f"Reached maximum login attempts ({self.max_login_attempts})")
                    return False
                
                # Otherwise, try again
                self.web_logger.info(f"Retrying login (attempt {self.login_attempts + 1}/{self.max_login_attempts})")
                return self.login()
                
        except Exception as e:
            self.web_logger.error(f"Error during login: {str(e)}")
            traceback.print_exc()
            return False
    
    def check_login_status(self):
        """
        Check if user is still logged in, and login again if needed.
        
        Returns:
            bool: True if logged in
        """
        if not self.navigator:
            return False
            
        try:
            # Get current URL
            current_url = self.navigator.get_url()
            
            # If already on a secure page, check for session elements
            if current_url and "app.hotmart.com" in current_url:
                # Check for login form
                login_form = self.navigator.find_elements(
                    "form[action*='login'], .login-form, [data-testid='login-form']"
                )
                
                if login_form:
                    self.web_logger.warning("Session expired, logging in again")
                    self.is_logged_in = False
                    return self.login()
                
                # Check for user menu or profile (indicators of being logged in)
                user_elements = self.navigator.find_elements(
                    ".user-menu, .profile-menu, [data-testid='user-menu'], .user-profile"
                )
                
                if user_elements:
                    return True
            
            # Navigate to dashboard as a test
            self.web_logger.info("Checking login status by navigating to dashboard")
            if not self.navigator.navigate_to(self.dashboard_url):
                self.web_logger.error("Failed to navigate to dashboard")
                return False
            
            # Check for login form
            login_form = self.navigator.find_elements(
                "form[action*='login'], .login-form, [data-testid='login-form']"
            )
            
            if login_form:
                self.web_logger.warning("Not logged in, attempting to login")
                self.is_logged_in = False
                return self.login()
            
            # If we got here, we're logged in
            self.is_logged_in = True
            return True
            
        except Exception as e:
            self.web_logger.error(f"Error checking login status: {str(e)}")
            return False
    
    def navigate_to_product_creation(self):
        """
        Navigate to the product creation page.
        
        Returns:
            bool: True if navigation was successful
        """
        if not self.navigator:
            self.web_logger.error("Navigator not initialized")
            return False
            
        if not self.is_logged_in and not self.check_login_status():
            self.web_logger.error("Not logged in to Hotmart")
            return False
            
        try:
            # Navigate to product creation page
            self.web_logger.info("Navigating to product creation page...")
            if not self.navigator.navigate_to(self.create_product_url):
                self.web_logger.error("Failed to navigate to product creation page")
                return False
            
            # Check if we're on the correct page
            current_url = self.navigator.get_url()
            
            if not current_url or "create" not in current_url:
                self.web_logger.error("Not on product creation page")
                return False
            
            # Wait for the page to be ready
            create_form = self.navigator.wait_for_element(
                "form, .product-form, [data-testid='product-form']",
                visible=True,
                timeout=20
            )
            
            if not create_form:
                self.web_logger.error("Product creation form not found")
                return False
            
            self.web_logger.info("Successfully navigated to product creation page")
            return True
            
        except Exception as e:
            self.web_logger.error(f"Error navigating to product creation: {str(e)}")
            return False
    
    def upload_product(self, product) -> Tuple[bool, Dict[str, Any]]:
        """
        Upload a product to Hotmart.
        
        Args:
            product: Product object with metadata
            
        Returns:
            Tuple of (success, result_dict)
        """
        if not self.navigator:
            error_msg = "Navigator not initialized"
            self.web_logger.error(error_msg)
            return False, {"error": error_msg}
            
        if not self.is_logged_in and not self.check_login_status():
            error_msg = "Not logged in to Hotmart"
            self.web_logger.error(error_msg)
            return False, {"error": error_msg}
            
        try:
            product_id = product.id
            product_title = product.title
            self.web_logger.info(f"Starting upload for product: {product_title} (ID: {product_id})")
            
            # Navigate to product creation
            if not self.navigate_to_product_creation():
                error_msg = "Failed to navigate to product creation page"
                self.web_logger.error(error_msg)
                return False, {"error": error_msg}
            
            # Fill basic product info
            self.web_logger.info("Filling basic product information...")
            if not self._fill_basic_info(product):
                error_msg = "Failed to fill basic product information"
                self.web_logger.error(error_msg)
                return False, {"error": error_msg}
            
            # Progress to next step (pricing)
            if not self._navigate_to_next_step():
                error_msg = "Failed to navigate to pricing step"
                self.web_logger.error(error_msg)
                return False, {"error": error_msg}
            
            # Fill pricing information
            self.web_logger.info("Filling pricing information...")
            if not self._fill_pricing_info(product):
                error_msg = "Failed to fill pricing information"
                self.web_logger.error(error_msg)
                return False, {"error": error_msg}
            
            # Progress to next step (content)
            if not self._navigate_to_next_step():
                error_msg = "Failed to navigate to content step"
                self.web_logger.error(error_msg)
                return False, {"error": error_msg}
            
            # Upload product file if available
            if product.file_path:
                self.web_logger.info(f"Uploading product file: {product.file_name}")
                if not self._upload_product_file(product):
                    error_msg = "Failed to upload product file"
                    self.web_logger.error(error_msg)
                    return False, {"error": error_msg}
            
            # Complete the product creation
            if not self._complete_product_creation():
                error_msg = "Failed to complete product creation"
                self.web_logger.error(error_msg)
                return False, {"error": error_msg}
            
            # Get product details from confirmation page
            hotmart_id, hotmart_url = self._extract_product_details()
            
            # Update upload count
            self.upload_count += 1
            
            result = {
                "success": True,
                "product_id": product_id,
                "hotmart_id": hotmart_id,
                "hotmart_url": hotmart_url,
                "upload_time": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            
            self.web_logger.info(f"Product upload successful: {product_title} (Hotmart ID: {hotmart_id})")
            return True, result
            
        except Exception as e:
            error_msg = f"Error uploading product: {str(e)}"
            self.web_logger.error(error_msg)
            traceback.print_exc()
            
            # Update error count
            self.error_count += 1
            
            # Take screenshot for debugging
            screenshot_path = self.navigator.take_screenshot(
                f"logs/error_{self.session_id}_{int(time.time())}.png"
            )
            
            return False, {
                "error": error_msg,
                "screenshot": screenshot_path,
                "traceback": traceback.format_exc()
            }
    
    def _fill_basic_info(self, product):
        """
        Fill basic product information.
        
        Args:
            product: Product object
            
        Returns:
            bool: True if successful
        """
        try:
            # Use adaptive intelligence to analyze the form
            self.web_logger.info("Analyzing product form...")
            form_analysis = self.adaptive_intelligence.analyze_page("Product creation form - Basic information")
            
            # Wait for page to be ready
            self.human_simulator.natural_pause()
            
            # Fill product name
            name_input = self.navigator.find_element(
                "input[name*='name' i], input[placeholder*='nome do produto' i], [data-testid='product-name']",
                description="Product name field"
            )
            
            if not name_input:
                self.web_logger.error("Product name field not found")
                return False
            
            if not self.navigator.type_text(name_input, product.title, description="product name"):
                self.web_logger.error("Failed to enter product name")
                return False
            
            # Natural pause between fields
            self.human_simulator.natural_pause()
            
            # Fill product description
            desc_input = self.navigator.find_element(
                "textarea[name*='description' i], textarea[placeholder*='descrição' i], [data-testid='product-description']",
                description="Product description field"
            )
            
            if not desc_input:
                self.web_logger.error("Product description field not found")
                return False
            
            if not self.navigator.type_text(desc_input, product.description or "Premium digital product", description="product description"):
                self.web_logger.error("Failed to enter product description")
                return False
            
            # Select product category
            category_select = self.navigator.find_element(
                "select[name*='category' i], [data-testid='product-category']",
                description="Category dropdown"
            )
            
            if category_select:
                category = product.category or self.product_manager.get_random_category()
                if not self.navigator.select_option(category_select, text=category, description="product category"):
                    self.web_logger.warning("Failed to select category, trying alternative method")
                    
                    # Try clicking the dropdown
                    self.navigator.click(category_select)
                    
                    # Look for the option in the dropdown
                    category_option = self.navigator.find_element(
                        f"option:contains('{category}'), li:contains('{category}')"
                    )
                    
                    if category_option:
                        self.navigator.click(category_option)
            
            # If there are other required fields, try to identify and fill them
            required_fields = self.navigator.find_elements(
                "input[required], select[required], textarea[required]"
            )
            
            for field in required_fields:
                field_type = field.get_attribute("type")
                field_name = field.get_attribute("name") or field.get_attribute("id") or ""
                
                # Skip fields we already filled
                if "name" in field_name.lower() or "description" in field_name.lower():
                    continue
                
                # Handle different field types
                if field_type == "text" and not field.get_attribute("value"):
                    placeholder = field.get_attribute("placeholder") or ""
                    
                    if "keyword" in placeholder.lower() or "palavra" in placeholder.lower():
                        # Keywords field
                        keywords = "digital product, ebook, online course"
                        self.navigator.type_text(field, keywords, description=f"field: {field_name}")
                    else:
                        # Generic text field
                        self.navigator.type_text(field, "Premium content", description=f"field: {field_name}")
                
                elif field_type == "select-one" or field.tag_name.lower() == "select":
                    # Try to select a non-empty option
                    options = field.find_elements("tag name", "option")
                    
                    for i, option in enumerate(options):
                        if i > 0:  # Skip the first option (usually placeholder)
                            self.navigator.select_option(field, index=i, description=f"field: {field_name}")
                            break
            
            return True
            
        except Exception as e:
            self.web_logger.error(f"Error filling basic info: {str(e)}")
            return False
    
    def _fill_pricing_info(self, product):
        """
        Fill pricing information.
        
        Args:
            product: Product object
            
        Returns:
            bool: True if successful
        """
        try:
            # Use adaptive intelligence to analyze the pricing form
            self.web_logger.info("Analyzing pricing form...")
            pricing_analysis = self.adaptive_intelligence.analyze_page("Product creation form - Pricing information")
            
            # Natural pause
            self.human_simulator.natural_pause()
            
            # Determine pricing strategy
            product_data = {
                'product_type': product.format_type or 'ebook',
                'price': product.price
            }
            
            # Initialize pricing strategy
            if self.pricing_manager:
                # Set the navigator
                self.pricing_manager.set_navigator(self.navigator)
                self.pricing_manager.set_human_simulator(self.human_simulator)
                
                # Generate and apply pricing strategy
                pricing_strategy = self.pricing_manager.generate_pricing_strategy(
                    product_data.get('product_type', 'ebook'),
                    product.price
                )
                
                self.web_logger.info(f"Using pricing strategy: {pricing_strategy['payment_model']} at {pricing_strategy['formatted_price']}")
                
                # Apply the pricing strategy
                if not self.pricing_manager.fill_pricing_form(product_data, pricing_strategy):
                    self.web_logger.warning("Failed to apply pricing strategy, trying manual method")
                    
                    # Try to fill price field directly
                    price_input = self.navigator.find_element(
                        "input[name*='price' i], input[placeholder*='preço' i], [data-testid='product-price']",
                        description="Price field"
                    )
                    
                    if price_input:
                        price_value = product.price or 97.0
                        formatted_price = f"{price_value:.2f}".replace('.', ',')
                        
                        if not self.navigator.type_text(price_input, formatted_price, description="product price"):
                            self.web_logger.error("Failed to enter product price")
                            return False
            else:
                # Manual method if pricing manager not available
                price_input = self.navigator.find_element(
                    "input[name*='price' i], input[placeholder*='preço' i], [data-testid='product-price']",
                    description="Price field"
                )
                
                if price_input:
                    price_value = product.price or 97.0
                    formatted_price = f"{price_value:.2f}".replace('.', ',')
                    
                    if not self.navigator.type_text(price_input, formatted_price, description="product price"):
                        self.web_logger.error("Failed to enter product price")
                        return False
            
            return True
            
        except Exception as e:
            self.web_logger.error(f"Error filling pricing info: {str(e)}")
            return False
    
    def _upload_product_file(self, product):
        """
        Upload the product file.
        
        Args:
            product: Product object
            
        Returns:
            bool: True if successful
        """
        try:
            # Use adaptive intelligence to analyze the content form
            self.web_logger.info("Analyzing content form...")
            content_analysis = self.adaptive_intelligence.analyze_page("Product creation form - Content upload")
            
            # Natural pause
            self.human_simulator.natural_pause()
            
            # Find upload input using product manager
            if not self.product_manager.find_upload_input(self.navigator, None, "Upload de Arquivo do Produto"):
                self.web_logger.error("Upload input not found")
                return False
            
            # Get file path
            file_path = product.file_path
            
            if not file_path or not os.path.exists(file_path):
                self.web_logger.error(f"File not found: {file_path}")
                return False
            
            # Upload the file
            file_input = self.navigator.find_element(
                "input[type='file']",
                description="File input field"
            )
            
            if not file_input:
                self.web_logger.error("File input not found")
                return False
            
            # Make input visible if needed
            self.navigator.execute_script(
                "arguments[0].style.opacity = '1'; arguments[0].style.display = 'block';",
                file_input
            )
            
            # Set the file path
            absolute_path = os.path.abspath(file_path)
            file_input.send_keys(absolute_path)
            
            self.web_logger.info(f"File upload started: {absolute_path}")
            
            # Wait for upload to complete
            max_wait = 300  # 5 minutes for large files
            start_time = time.time()
            upload_complete = False
            
            while time.time() - start_time < max_wait:
                # Check for success indicators
                success_elements = self.navigator.find_elements(
                    ".upload-success, .file-uploaded, [data-testid='upload-success']"
                )
                
                file_name_elements = self.navigator.find_elements(
                    f"*:contains('{os.path.basename(file_path)}')"
                )
                
                if success_elements or file_name_elements:
                    upload_complete = True
                    break
                
                # Check for error indicators
                error_elements = self.navigator.find_elements(
                    ".upload-error, .file-error, [data-testid='upload-error']"
                )
                
                if error_elements:
                    error_text = self.navigator.get_element_text(error_elements[0])
                    self.web_logger.error(f"Upload error: {error_text}")
                    return False
                
                # Continue waiting
                time.sleep(2)
                
                # Log progress periodically
                if int(time.time() - start_time) % 10 == 0:
                    self.web_logger.info(f"Waiting for upload to complete... ({int(time.time() - start_time)}s)")
            
            if upload_complete:
                self.web_logger.info("File upload completed successfully")
                return True
            else:
                self.web_logger.error("File upload timed out")
                return False
            
        except Exception as e:
            self.web_logger.error(f"Error uploading file: {str(e)}")
            return False
    
    def _navigate_to_next_step(self):
        """
        Navigate to the next step in the product creation process.
        
        Returns:
            bool: True if successful
        """
        try:
            # Find and click the next button
            next_button = self.navigator.find_element(
                "button[type='submit'], button.next-button, button:contains('Próximo'), button:contains('Continuar'), button:contains('Avançar'), [data-testid='next-button']",
                description="Next button"
            )
            
            if not next_button:
                self.web_logger.error("Next button not found")
                return False
            
            if not self.navigator.click(next_button, description="next button"):
                self.web_logger.error("Failed to click next button")
                return False
            
            # Wait for the next page to load
            max_wait = 30  # seconds
            start_time = time.time()
            
            while time.time() - start_time < max_wait:
                # Check if loading indicator is present
                loading_elements = self.navigator.find_elements(
                    ".loading-indicator, .spinner, [data-testid='loading']"
                )
                
                if not loading_elements:
                    # Wait a bit more to ensure page is loaded
                    time.sleep(2)
                    return True
                
                # Continue waiting
                time.sleep(1)
            
            self.web_logger.warning("Navigation to next step timed out, but continuing")
            return True
            
        except Exception as e:
            self.web_logger.error(f"Error navigating to next step: {str(e)}")
            return False
    
    def _complete_product_creation(self):
        """
        Complete the product creation process.
        
        Returns:
            bool: True if successful
        """
        try:
            # Find and click the finish button
            finish_button = self.navigator.find_element(
                "button[type='submit'], button.finish-button, button:contains('Finalizar'), button:contains('Concluir'), button:contains('Publicar'), [data-testid='finish-button']",
                description="Finish button"
            )
            
            if not finish_button:
                self.web_logger.error("Finish button not found")
                return False
            
            if not self.navigator.click(finish_button, description="finish button"):
                self.web_logger.error("Failed to click finish button")
                return False
            
            # Wait for completion
            max_wait = 60  # seconds
            start_time = time.time()
            
            while time.time() - start_time < max_wait:
                # Check for success indicators
                success_elements = self.navigator.find_elements(
                    ".success-message, .product-created, [data-testid='success-message']"
                )
                
                if success_elements:
                    self.web_logger.info("Product creation completed successfully")
                    return True
                
                # Check for product details page indicators
                product_elements = self.navigator.find_elements(
                    ".product-details, .product-overview, [data-testid='product-details']"
                )
                
                if product_elements:
                    self.web_logger.info("Product details page detected, creation successful")
                    return True
                
                # Check for error indicators
                error_elements = self.navigator.find_elements(
                    ".error-message, .creation-error, [data-testid='error-message']"
                )
                
                if error_elements:
                    error_text = self.navigator.get_element_text(error_elements[0])
                    self.web_logger.error(f"Creation error: {error_text}")
                    return False
                
                # Continue waiting
                time.sleep(1)
            
            # If we get here, we timed out but might still be successful
            self.web_logger.warning("Product creation completion timed out, checking current state")
            
            # Check URL for indicators of success
            current_url = self.navigator.get_url()
            
            if current_url and ("success" in current_url or "details" in current_url or "overview" in current_url):
                self.web_logger.info("Product appears to be created based on URL")
                return True
            
            self.web_logger.error("Product creation timed out without confirmation")
            return False
            
        except Exception as e:
            self.web_logger.error(f"Error completing product creation: {str(e)}")
            return False
    
    def _extract_product_details(self):
        """
        Extract product details from the confirmation page.
        
        Returns:
            Tuple of (hotmart_id, hotmart_url)
        """
        try:
            # Get current URL (may contain product ID)
            current_url = self.navigator.get_url() or ""
            
            # Extract product ID from URL
            product_id_match = re.search(r'product(?:s|/|=)([A-Z0-9]+)', current_url)
            hotmart_id = product_id_match.group(1) if product_id_match else None
            
            if not hotmart_id:
                # Try to find product ID on the page
                product_id_elements = self.navigator.find_elements(
                    "[data-testid='product-id'], .product-id, *:contains('ID do produto')"
                )
                
                if product_id_elements:
                    text = self.navigator.get_element_text(product_id_elements[0])
                    id_match = re.search(r'([A-Z0-9]{6,})', text)
                    
                    if id_match:
                        hotmart_id = id_match.group(1)
            
            # Default to current URL if we couldn't extract product ID
            hotmart_url = current_url
            
            return hotmart_id, hotmart_url
            
        except Exception as e:
            self.web_logger.warning(f"Error extracting product details: {str(e)}")
            return None, None
    
    def cleanup(self):
        """
        Clean up resources.
        
        Returns:
            bool: True if cleanup was successful
        """
        try:
            self.end_time = time.time()
            
            # Log performance metrics
            if self.start_time:
                duration = self.end_time - self.start_time
                self.web_logger.info(f"Session duration: {duration:.2f} seconds")
                self.web_logger.info(f"Uploads completed: {self.upload_count}")
                self.web_logger.info(f"Errors encountered: {self.error_count}")
            
            # Close browser
            if self.navigator:
                self.navigator.close()
                self.navigator = None
            
            self.web_logger.info("Cleanup completed")
            return True
            
        except Exception as e:
            self.web_logger.error(f"Error during cleanup: {str(e)}")
            return False
