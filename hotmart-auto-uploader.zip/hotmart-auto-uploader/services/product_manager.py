"""
Product Manager Module
------------------
Responsável por gerenciar os produtos, incluindo:
- Upload de arquivos (PDFs, eBooks)
- Seleção de categorias
- Gerenciamento de atributos do produto
"""

import os
import json
import random
import logging
import time
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path

logger = logging.getLogger(__name__)

class ProductManager:
    """Classe para gerenciar produtos e seus arquivos associados"""
    
    def __init__(self, config_dir: str = "config", data_dir: str = "data"):
        """
        Inicializa o gerenciador de produtos.
        
        Args:
            config_dir: Diretório com arquivos de configuração
            data_dir: Diretório com dados e temporários
        """
        self.config_dir = config_dir
        self.data_dir = data_dir
        self.categories = []
        self.formats = []
        self.languages = []
        
        # Carregar categorias e formatos
        self._load_configurations()
        
        # Criar diretório de temporários se não existir
        os.makedirs(os.path.join(self.data_dir, "temp"), exist_ok=True)
        
    def _load_configurations(self):
        """Carrega configurações de categorias e formatos"""
        try:
            categories_file = os.path.join(self.config_dir, "product_categories.json")
            
            if os.path.exists(categories_file):
                with open(categories_file, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    self.categories = config.get('categories', [])
                    self.formats = config.get('formats', [])
                    self.languages = config.get('languages', [])
                    
                logger.info(f"Carregadas {len(self.categories)} categorias de produtos")
            else:
                logger.warning(f"Arquivo de categorias não encontrado: {categories_file}")
                
        except Exception as e:
            logger.error(f"Erro ao carregar configurações: {e}")
            # Usar valores padrão em caso de erro
            self.categories = ["Educacional", "Finanças", "Saúde"]
            self.formats = ["eBooks, Documentos", "Vídeos", "Cursos Online"]
            self.languages = ["Português (Brasil)", "Inglês", "Espanhol"]
    
    def get_compatible_file_types(self) -> List[str]:
        """
        Retorna os tipos de arquivos compatíveis com a Hotmart
        
        Returns:
            Lista de extensões de arquivo aceitas
        """
        return [".pdf", ".epub", ".xlsx", ".xlsm", ".xls", ".csv"]
    
    def get_random_category(self) -> str:
        """
        Seleciona uma categoria aleatória para o produto
        
        Returns:
            Nome da categoria selecionada
        """
        if not self.categories:
            return "Outros"
        return random.choice(self.categories)
    
    def get_random_format(self) -> str:
        """
        Seleciona um formato aleatório para o produto
        
        Returns:
            Nome do formato selecionado
        """
        if not self.formats:
            return "eBooks, Documentos"
        return random.choice(self.formats)
    
    def get_random_language(self) -> str:
        """
        Seleciona um idioma aleatório para o produto
        
        Returns:
            Nome do idioma selecionado
        """
        if not self.languages:
            return "Português (Brasil)"
        return random.choice(self.languages)
    
    def validate_product_file(self, file_path: str) -> Tuple[bool, str]:
        """
        Valida se um arquivo é adequado para upload na Hotmart.
        
        Args:
            file_path: Caminho do arquivo
            
        Returns:
            Tupla (é_válido, mensagem)
        """
        # Verificar se o arquivo existe
        if not os.path.exists(file_path):
            return False, f"Arquivo não encontrado: {file_path}"
            
        # Verificar tamanho (máximo permitido pela Hotmart = 250MB)
        max_size_mb = 250
        file_size_mb = os.path.getsize(file_path) / (1024 * 1024)
        
        if file_size_mb > max_size_mb:
            return False, f"Arquivo muito grande: {file_size_mb:.2f}MB (máximo: {max_size_mb}MB)"
            
        # Verificar extensão
        file_ext = os.path.splitext(file_path)[1].lower()
        valid_extensions = self.get_compatible_file_types()
        
        if file_ext not in valid_extensions:
            return False, f"Tipo de arquivo não suportado: {file_ext}. Use: {', '.join(valid_extensions)}"
            
        return True, "Arquivo válido para upload"
    
    def prepare_product_data(self, title: str, description: str, 
                            file_path: Optional[str] = None,
                            category: Optional[str] = None,
                            format_type: Optional[str] = None,
                            language: Optional[str] = None,
                            price: Optional[float] = None) -> Dict[str, Any]:
        """
        Prepara dados do produto para upload no Hotmart.
        
        Args:
            title: Título do produto
            description: Descrição do produto
            file_path: Caminho do arquivo (opcional)
            category: Categoria do produto (opcional)
            format_type: Formato do produto (opcional)
            language: Idioma do produto (opcional)
            price: Preço do produto (opcional)
            
        Returns:
            Dicionário com dados do produto
        """
        # Definir valores default para campos opcionais
        if not category:
            category = self.get_random_category()
            
        if not format_type:
            format_type = self.get_random_format()
            
        if not language:
            language = self.get_random_language()
            
        if not price:
            # Preço padrão entre R$27 e R$97
            price = round(random.uniform(27, 97), 2)
        
        # Construir dados do produto
        product_data = {
            "title": title,
            "description": description,
            "category": category,
            "format": format_type,
            "language": language,
            "price": price,
            "file_path": file_path,
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S")
        }
        
        # Validar arquivo se fornecido
        if file_path:
            is_valid, message = self.validate_product_file(file_path)
            product_data["file_valid"] = is_valid
            product_data["file_message"] = message
            
            if is_valid:
                # Adicionar informações do arquivo
                file_size_mb = os.path.getsize(file_path) / (1024 * 1024)
                product_data["file_size_mb"] = round(file_size_mb, 2)
                product_data["file_name"] = os.path.basename(file_path)
                product_data["file_extension"] = os.path.splitext(file_path)[1].lower()
        
        return product_data
    
    def find_upload_input(self, navigator, hotmart_filler, context: str = "Upload de Arquivo") -> bool:
        """
        Encontra o campo de upload de arquivo na interface do Hotmart.
        
        Args:
            navigator: Instância do navegador
            hotmart_filler: Instância do preenchedor Hotmart
            context: Contexto da operação
            
        Returns:
            True se o campo foi encontrado, False caso contrário
        """
        try:
            # Primeira tentativa: campo de upload padrão
            upload_input = navigator.find_element(
                "input[type='file']", 
                description="Campo de upload de arquivo",
                context=context
            )
            
            if upload_input:
                logger.info("Campo de upload encontrado (padrão)")
                return True
            
            # Segunda tentativa: botão "Selecione um arquivo"
            upload_button = navigator.find_element(
                "button:contains('Selecione um arquivo'), button:contains('Escolher arquivo')",
                description="Botão de seleção de arquivo",
                context=context
            )
            
            if upload_button:
                logger.info("Botão de upload encontrado")
                navigator.find_and_click(
                    upload_button,
                    description="Clicar no botão de seleção de arquivo",
                    context=context
                )
                # Esperar pelo input de arquivo que pode surgir
                time.sleep(1)
                return True
            
            # Terceira tentativa: área de soltar arquivo
            drop_area = navigator.find_element(
                ".dropzone, [data-testid='dropzone'], [role='button'][aria-label*='upload']",
                description="Área de arrastar e soltar arquivo",
                context=context
            )
            
            if drop_area:
                logger.info("Área de upload encontrada")
                navigator.find_and_click(
                    drop_area,
                    description="Clicar na área de arrastar e soltar",
                    context=context
                )
                # Esperar pelo input de arquivo que pode surgir
                time.sleep(1)
                return True
            
            logger.warning("Não foi possível encontrar campo de upload")
            return False
            
        except Exception as e:
            logger.error(f"Erro ao buscar campo de upload: {e}")
            return False
            
    def upload_product_file(self, navigator, hotmart_filler, file_path: str, 
                          context: str = "Upload de Arquivo do Produto") -> bool:
        """
        Realiza o upload de um arquivo de produto no Hotmart.
        
        Args:
            navigator: Instância do navegador
            hotmart_filler: Instância do preenchedor Hotmart
            file_path: Caminho do arquivo para upload
            context: Contexto da operação
            
        Returns:
            True se o upload foi bem-sucedido, False caso contrário
        """
        try:
            # Validar arquivo
            is_valid, message = self.validate_product_file(file_path)
            if not is_valid:
                logger.error(f"Arquivo inválido para upload: {message}")
                return False
                
            # Garantir que estamos na página de conteúdo
            if not hotmart_filler.navigate_to_content_tab():
                logger.error("Não foi possível navegar para a aba de conteúdo")
                return False
                
            # Localizar o campo de upload
            if not self.find_upload_input(navigator, hotmart_filler, context):
                logger.error("Campo de upload não encontrado")
                return False
                
            # Buscar o input de arquivo (pode estar oculto)
            file_input = navigator.find_element(
                "input[type='file']", 
                description="Input de arquivo (possivelmente oculto)",
                context=context
            )
            
            if not file_input:
                logger.error("Input de arquivo não encontrado mesmo após encontrar área de upload")
                return False
                
            # Upload do arquivo
            try:
                # Tornar o input visível se estiver oculto
                navigator._execute_script(
                    "arguments[0].style.opacity = '1'; arguments[0].style.display = 'block';", 
                    file_input
                )
                
                # Definir o caminho do arquivo
                absolute_path = os.path.abspath(file_path)
                file_input.send_keys(absolute_path)
                logger.info(f"Arquivo enviado: {absolute_path}")
                
                # Esperar o upload concluir
                logger.info("Aguardando conclusão do upload...")
                
                # Aguardar indicador de progresso desaparecer
                max_wait = 300  # 5 minutos para uploads grandes
                start_time = time.time()
                upload_complete = False
                
                while time.time() - start_time < max_wait:
                    # Verificar se há mensagem de sucesso
                    success_message = navigator.find_element(
                        ".success-message, .upload-success, [data-testid='success-message']",
                        description="Mensagem de sucesso de upload",
                        context=context,
                        adaptive_retry=False  # Não usar retry para não logar erros
                    )
                    
                    if success_message:
                        logger.info("Upload concluído com sucesso!")
                        upload_complete = True
                        break
                        
                    # Verificar se há mensagem de erro
                    error_message = navigator.find_element(
                        ".error-message, .upload-error, [data-testid='error-message']",
                        description="Mensagem de erro de upload",
                        context=context,
                        adaptive_retry=False
                    )
                    
                    if error_message:
                        logger.error(f"Erro durante upload: {error_message.text}")
                        return False
                        
                    # Verificar se ainda há indicador de progresso
                    progress = navigator.find_element(
                        ".progress-bar, .upload-progress, [role='progressbar']",
                        description="Barra de progresso de upload",
                        context=context,
                        adaptive_retry=False
                    )
                    
                    if not progress:
                        # Verifique se o arquivo aparece na lista
                        file_listed = navigator.find_element(
                            f"[title*='{os.path.basename(file_path)}'], .file-name:contains('{os.path.basename(file_path)}')",
                            description="Arquivo na lista de arquivos",
                            context=context,
                            adaptive_retry=False
                        )
                        
                        if file_listed:
                            logger.info("Arquivo listado após upload!")
                            upload_complete = True
                            break
                    
                    # Aguardar um pouco antes de verificar novamente
                    time.sleep(5)
                    logger.info(f"Aguardando upload... ({int(time.time() - start_time)}s)")
                
                if not upload_complete:
                    logger.warning("Tempo de espera excedido. O upload pode não ter sido concluído.")
                    return False
                
                return True
                
            except Exception as e:
                logger.error(f"Erro durante o upload do arquivo: {e}")
                return False
                
        except Exception as e:
            logger.error(f"Erro geral no upload de arquivo: {e}")
            return False
    
    def select_product_category(self, navigator, category: str, 
                              context: str = "Seleção de Categoria") -> bool:
        """
        Seleciona a categoria do produto no Hotmart.
        
        Args:
            navigator: Instância do navegador
            category: Nome da categoria a selecionar
            context: Contexto da operação
            
        Returns:
            True se a categoria foi selecionada, False caso contrário
        """
        try:
            # Buscar o seletor de categoria
            category_dropdown = navigator.find_element(
                "select.category-select, [data-testid='category-select'], "
                + "[aria-label*='categoria'], [placeholder*='categoria']",
                description="Seletor de categoria de produto",
                context=context
            )
            
            if not category_dropdown:
                # Tentar encontrar como botão dropdown personalizado
                category_dropdown = navigator.find_element(
                    ".dropdown-toggle[aria-label*='categoria'], "
                    + "button:contains('categoria'), button:contains('Categoria')",
                    description="Botão de categoria de produto",
                    context=context
                )
                
                if category_dropdown:
                    # Clicar para abrir o dropdown
                    navigator.find_and_click(
                        category_dropdown,
                        description="Abrir dropdown de categoria",
                        context=context
                    )
                    
                    # Esperar opções aparecerem
                    time.sleep(1)
                    
                    # Buscar a opção específica
                    category_option = navigator.find_element(
                        f"li:contains('{category}'), div[role='option']:contains('{category}')",
                        description=f"Opção de categoria: {category}",
                        context=context
                    )
                    
                    if category_option:
                        # Clicar na opção
                        navigator.find_and_click(
                            category_option,
                            description=f"Selecionar categoria {category}",
                            context=context
                        )
                        logger.info(f"Categoria selecionada: {category}")
                        return True
                    else:
                        logger.warning(f"Opção de categoria não encontrada: {category}")
                        
                        # Tentar buscar uma categoria similar se a exata não for encontrada
                        for existing_category in self.categories:
                            if navigator._description_matches(existing_category, category, 0.5):
                                similar_option = navigator.find_element(
                                    f"li:contains('{existing_category}'), div[role='option']:contains('{existing_category}')",
                                    description=f"Opção de categoria similar: {existing_category}",
                                    context=context
                                )
                                
                                if similar_option:
                                    navigator.find_and_click(
                                        similar_option,
                                        description=f"Selecionar categoria similar {existing_category}",
                                        context=context
                                    )
                                    logger.info(f"Categoria similar selecionada: {existing_category} (solicitada: {category})")
                                    return True
                        
                        # Se nenhuma categoria similar for encontrada, fechar o dropdown
                        navigator.find_and_click(
                            "body",
                            description="Fechar dropdown clicando fora",
                            context=context
                        )
                        return False
                
                logger.warning("Seletor de categoria não encontrado")
                return False
            
            # Para select padrão HTML
            navigator.find_and_click(
                category_dropdown,
                description="Abrir seletor de categoria",
                context=context
            )
            
            # Esperar opções aparecerem
            time.sleep(0.5)
            
            # Selecionar a opção
            option_selector = f"option:contains('{category}')"
            navigator.find_and_click(
                option_selector,
                description=f"Opção de categoria: {category}",
                context=context
            )
            
            logger.info(f"Categoria selecionada via select padrão: {category}")
            return True
                
        except Exception as e:
            logger.error(f"Erro ao selecionar categoria: {e}")
            return False