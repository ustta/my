import logging
import time
import random
import json
import os
from typing import Dict, Any, List, Optional, Tuple
import datetime

# Configurando logger
logger = logging.getLogger(__name__)

class HumanInterventionDetector:
    """
    Detector de sistemas anti-bot e necessidade de intervenção humana
    
    Esta classe é responsável por monitorar padrões de detecção de bots,
    identificar situações que exigem intervenção e adaptar o comportamento
    para evitar detecção.
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Inicializa o detector de intervenção humana
        
        Args:
            config: Configurações opcionais para o detector
        """
        self.config = config or {}
        
        # Indicadores de risco
        self.risk_factors = {
            'unusual_redirects': 0.0,
            'unexpected_captchas': 0.0,
            'javascript_challenges': 0.0,
            'fingerprinting_attempts': 0.0,
            'browser_validation': 0.0,
            'timing_analysis': 0.0
        }
        
        # Histórico de detecções
        self.detection_history = []
        
        # Padrões conhecidos de sistemas anti-bot
        self.known_antibot_patterns = self._load_antibot_patterns()
        
        # Estado atual
        self.current_risk_level = 0.0
        self.last_assessment_time = datetime.datetime.now()
        self.evasion_mode = "normal"  # normal, cautious, stealth
        
        # Limite para intervenção
        self.intervention_threshold = self.config.get('intervention_threshold', 0.75)
        
        # Histórico de URLs para detectar redirects inesperados
        self.url_history = []
        
        # Contador de captchas
        self.captcha_occurrences = 0
        
    def _load_antibot_patterns(self) -> Dict[str, Any]:
        """
        Carrega padrões conhecidos de sistemas anti-bot
        
        Returns:
            Dicionário com padrões conhecidos
        """
        patterns = {
            # Hotmart específico
            'hotmart': {
                'fingerprinting': [
                    'fp.js',
                    'fingerprint2.js',
                    'botdetector',
                    'devicefingerprint'
                ],
                'challenge_endpoints': [
                    '/challenge',
                    '/verify',
                    '/check',
                    '/validate'
                ],
                'suspicious_scripts': [
                    'captcha',
                    'recaptcha',
                    'hcaptcha',
                    'cloudflare',
                    'distil',
                    'imperva',
                    'akamai',
                    'datadome'
                ],
                'timing_checks': [
                    'performance.timing',
                    'performance.now',
                    'Date.now',
                    'setTimeout',
                    'setInterval'
                ]
            },
            # Técnicas gerais
            'general': {
                'browser_checks': [
                    'navigator.webdriver',
                    'navigator.userAgent',
                    'navigator.plugins',
                    'navigator.languages',
                    'Notification.permission',
                    'document.hidden',
                    'window.chrome'
                ],
                'canvas_fingerprinting': [
                    'HTMLCanvasElement.prototype.toDataURL',
                    'CanvasRenderingContext2D.prototype.getImageData'
                ],
                'webgl_fingerprinting': [
                    'WebGLRenderingContext.prototype.getSupportedExtensions',
                    'WebGLRenderingContext.prototype.getParameter'
                ],
                'audio_fingerprinting': [
                    'AudioContext.prototype.createOscillator',
                    'OfflineAudioContext'
                ]
            }
        }
        
        # Tentar carregar padrões personalizados de arquivo
        try:
            patterns_path = self.config.get('antibot_patterns_path', 'config/antibot_patterns.json')
            if os.path.exists(patterns_path):
                with open(patterns_path, 'r') as f:
                    custom_patterns = json.load(f)
                    
                    # Mesclar com padrões existentes
                    for platform, categories in custom_patterns.items():
                        if platform in patterns:
                            for category, items in categories.items():
                                if category in patterns[platform]:
                                    patterns[platform][category].extend(items)
                                else:
                                    patterns[platform][category] = items
                        else:
                            patterns[platform] = categories
        except Exception as e:
            logger.warning(f"Não foi possível carregar padrões anti-bot personalizados: {str(e)}")
        
        return patterns
    
    def analyze_page(self, driver=None, html: Optional[str] = None, scripts: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Analisa a página atual para detectar sistemas anti-bot
        
        Args:
            driver: WebDriver (opcional)
            html: Conteúdo HTML da página (opcional)
            scripts: Lista de scripts na página (opcional)
            
        Returns:
            Resultado da análise com nível de risco
        """
        # Resetar fatores de risco pontuais
        self.risk_factors['unusual_redirects'] = 0.0
        self.risk_factors['javascript_challenges'] = 0.0
        self.risk_factors['fingerprinting_attempts'] = 0.0
        self.risk_factors['browser_validation'] = 0.0
        
        result = {
            'risk_level': 0.0,
            'detected_patterns': [],
            'evasion_recommendations': [],
            'intervention_needed': False
        }
        
        if driver is None and html is None:
            logger.warning("Nenhum driver ou HTML fornecido para análise")
            return result
        
        # Extrair HTML e scripts se driver for fornecido
        if driver is not None:
            current_url = driver.current_url
            
            # Verificar redirecionamentos suspeitos
            self._check_url_patterns(current_url)
            
            # Verificar histórico de URLs para redirecionamentos inesperados
            if self.url_history and current_url != self.url_history[-1]:
                if not self._is_expected_navigation(self.url_history[-1], current_url):
                    self.risk_factors['unusual_redirects'] += 0.3
                    result['detected_patterns'].append('redirect_unexpected')
                    result['evasion_recommendations'].append('slow_down_navigation')
            
            # Adicionar URL ao histórico
            self.url_history.append(current_url)
            if len(self.url_history) > 20:
                self.url_history.pop(0)
            
            try:
                html = driver.page_source
                
                # Extrair scripts
                scripts = []
                script_elements = driver.find_elements_by_tag_name('script')
                for script in script_elements:
                    try:
                        script_src = script.get_attribute('src')
                        if script_src:
                            scripts.append(script_src)
                    except:
                        pass
            except Exception as e:
                logger.warning(f"Erro ao extrair conteúdo da página: {str(e)}")
        
        # Analisar HTML e scripts
        if html:
            detected = self._analyze_html_content(html)
            result['detected_patterns'].extend(detected)
            
            if detected:
                self.risk_factors['fingerprinting_attempts'] += 0.15 * len(detected)
        
        if scripts:
            script_detections = self._analyze_scripts(scripts)
            result['detected_patterns'].extend(script_detections)
            
            if script_detections:
                self.risk_factors['fingerprinting_attempts'] += 0.2 * len(script_detections)
                self.risk_factors['browser_validation'] += 0.15 * len(script_detections)
        
        # Verificar execução de JavaScript
        if driver is not None:
            js_indicators = self._check_javascript_environment(driver)
            result['detected_patterns'].extend(js_indicators)
            
            if js_indicators:
                self.risk_factors['javascript_challenges'] += 0.25 * len(js_indicators)
                result['evasion_recommendations'].append('mask_automation_indicators')
        
        # Calcular nível de risco geral
        risk_level = sum(self.risk_factors.values()) / len(self.risk_factors)
        
        # Ajustar com base no histórico (risco persistente)
        if self.detection_history:
            historical_risk = sum(self.detection_history) / len(self.detection_history)
            risk_level = risk_level * 0.7 + historical_risk * 0.3
        
        # Atualizar estado atual
        self.current_risk_level = risk_level
        self.detection_history.append(risk_level)
        
        # Manter histórico limitado
        if len(self.detection_history) > 10:
            self.detection_history.pop(0)
        
        # Atualizar modo de evasão
        self._update_evasion_mode()
        
        # Verificar necessidade de intervenção
        intervention_needed = risk_level >= self.intervention_threshold
        
        # Preparar resultado
        result['risk_level'] = risk_level
        result['evasion_mode'] = self.evasion_mode
        result['intervention_needed'] = intervention_needed
        
        # Registrar análise
        logger.debug(f"Análise anti-bot: risco={risk_level:.2f}, modo={self.evasion_mode}, intervenção={intervention_needed}")
        
        return result
    
    def _analyze_html_content(self, html: str) -> List[str]:
        """
        Analisa o conteúdo HTML para detectar padrões anti-bot
        
        Args:
            html: Conteúdo HTML da página
            
        Returns:
            Lista de padrões detectados
        """
        detected_patterns = []
        
        # Verificar padrões Hotmart
        for pattern_type, patterns in self.known_antibot_patterns['hotmart'].items():
            for pattern in patterns:
                if pattern in html:
                    detected_patterns.append(f"hotmart_{pattern_type}_{pattern}")
        
        # Verificar CAPTCHA
        if 'captcha' in html.lower() or 'recaptcha' in html.lower() or 'hcaptcha' in html.lower():
            detected_patterns.append('captcha_detected')
            self.captcha_occurrences += 1
            self.risk_factors['unexpected_captchas'] += 0.5
        
        # Verificar iframes ocultos (comum em sistemas anti-bot)
        if 'iframe' in html.lower() and ('visibility:hidden' in html.lower() or 'display:none' in html.lower()):
            detected_patterns.append('hidden_iframe')
            self.risk_factors['fingerprinting_attempts'] += 0.3
        
        return detected_patterns
    
    def _analyze_scripts(self, scripts: List[str]) -> List[str]:
        """
        Analisa scripts para detectar padrões anti-bot
        
        Args:
            scripts: Lista de scripts ou URLs de scripts
            
        Returns:
            Lista de padrões detectados
        """
        detected_patterns = []
        
        for script in scripts:
            # Verificar padrões de fingerprinting conhecidos
            for fingerprint in self.known_antibot_patterns['hotmart']['fingerprinting']:
                if fingerprint in script.lower():
                    detected_patterns.append(f"fingerprinting_{fingerprint}")
            
            # Verificar scripts suspeitos
            for suspicious in self.known_antibot_patterns['hotmart']['suspicious_scripts']:
                if suspicious in script.lower():
                    detected_patterns.append(f"suspicious_script_{suspicious}")
            
            # Verificar provedores anti-bot conhecidos
            antibot_providers = ['cloudflare', 'akamai', 'imperva', 'distil', 'datadome', 'perimeterx', 'shapesecurity']
            for provider in antibot_providers:
                if provider in script.lower():
                    detected_patterns.append(f"antibot_provider_{provider}")
        
        return detected_patterns
    
    def _check_javascript_environment(self, driver) -> List[str]:
        """
        Verifica o ambiente JavaScript para detectar verificações anti-bot
        
        Args:
            driver: WebDriver
            
        Returns:
            Lista de indicadores detectados
        """
        indicators = []
        
        try:
            # Verificar modificações em propriedades de navigator
            webdriver_present = driver.execute_script("return navigator.webdriver !== undefined")
            if webdriver_present:
                indicators.append('webdriver_flag_present')
            
            # Verificar funções de timing
            timing_check = driver.execute_script("""
                let checks = [];
                if (performance && performance.timing) checks.push('performance.timing');
                if (performance && performance.now) checks.push('performance.now');
                return checks;
            """)
            
            if timing_check:
                indicators.extend([f"timing_check_{check}" for check in timing_check])
                self.risk_factors['timing_analysis'] += 0.2
            
            # Verificar fingerprinting de canvas
            canvas_fingerprinting = driver.execute_script("""
                const canvas = document.createElement('canvas');
                if (!canvas || !canvas.getContext) return false;
                
                let overridden = false;
                const originalFn = HTMLCanvasElement.prototype.toDataURL;
                if (originalFn.toString().indexOf('native code') === -1) {
                    overridden = true;
                }
                
                return overridden;
            """)
            
            if canvas_fingerprinting:
                indicators.append('canvas_fingerprinting_detected')
        
        except Exception as e:
            logger.warning(f"Erro ao verificar ambiente JavaScript: {str(e)}")
        
        return indicators
    
    def _is_expected_navigation(self, previous_url: str, current_url: str) -> bool:
        """
        Verifica se um redirecionamento é esperado ou suspeito
        
        Args:
            previous_url: URL anterior
            current_url: URL atual
            
        Returns:
            True se for navegação esperada, False se for suspeita
        """
        # Implementação simplificada, poderia ser mais sofisticada
        # Verificar se é apenas mudança de protocolo ou www
        if previous_url.replace('http://', '').replace('https://', '').replace('www.', '') == \
           current_url.replace('http://', '').replace('https://', '').replace('www.', ''):
            return True
        
        # Verificar se é redirecionamento para url em mesmo domínio
        prev_domain = previous_url.split('/')[2] if '://' in previous_url else previous_url.split('/')[0]
        curr_domain = current_url.split('/')[2] if '://' in current_url else current_url.split('/')[0]
        
        if prev_domain == curr_domain:
            return True
        
        # Verificar se é redirecionamento conhecido
        known_redirects = [
            ('hotmart.com', 'members.hotmart.com'),
            ('hotmart.com', 'api.hotmart.com'),
            ('hotmart.com', 'payment.hotmart.com'),
            ('hotmart.com', 'auth.hotmart.com')
        ]
        
        for src, dst in known_redirects:
            if src in prev_domain and dst in curr_domain:
                return True
        
        return False
    
    def _check_url_patterns(self, url: str) -> List[str]:
        """
        Verifica padrões suspeitos na URL
        
        Args:
            url: URL para verificar
            
        Returns:
            Lista de padrões suspeitos
        """
        suspicious_patterns = []
        
        # Verificar padrões suspeitos
        suspicious_url_patterns = self.known_antibot_patterns['hotmart']['challenge_endpoints']
        for pattern in suspicious_url_patterns:
            if pattern in url:
                suspicious_patterns.append(f"challenge_url_{pattern}")
                self.risk_factors['javascript_challenges'] += 0.4
        
        # Verificar parâmetros suspeitos
        suspicious_params = ['token', 'verify', 'challenge', 'captcha', 'check', 'security']
        if '?' in url:
            query_params = url.split('?')[1].split('&')
            for param in query_params:
                param_name = param.split('=')[0].lower()
                if param_name in suspicious_params:
                    suspicious_patterns.append(f"suspicious_param_{param_name}")
                    self.risk_factors['browser_validation'] += 0.3
        
        return suspicious_patterns
    
    def _update_evasion_mode(self) -> None:
        """
        Atualiza o modo de evasão com base no nível de risco atual
        """
        if self.current_risk_level < 0.3:
            self.evasion_mode = "normal"
        elif self.current_risk_level < 0.7:
            self.evasion_mode = "cautious"
        else:
            self.evasion_mode = "stealth"
    
    def get_evasion_strategy(self) -> Dict[str, Any]:
        """
        Obtém estratégia de evasão com base no modo atual
        
        Returns:
            Dicionário com a estratégia de evasão
        """
        strategy = {
            'mode': self.evasion_mode,
            'behavioral_changes': {},
            'browser_changes': [],
            'timing_changes': {},
        }
        
        if self.evasion_mode == "normal":
            # Comportamento quase normal
            strategy['behavioral_changes'] = {
                'delay_factor': 1.0,
                'error_rate': 0.05,
                'hesitation_factor': 0.2,
                'movement_randomness': 0.3
            }
            strategy['timing_changes'] = {
                'min_action_delay': 0.8,
                'max_action_delay': 3.0,
                'typing_speed_factor': 1.0
            }
        
        elif self.evasion_mode == "cautious":
            # Comportamento mais humano e cauteloso
            strategy['behavioral_changes'] = {
                'delay_factor': 1.5,
                'error_rate': 0.1,
                'hesitation_factor': 0.4,
                'movement_randomness': 0.5
            }
            strategy['browser_changes'] = [
                'mask_webdriver',
                'simulate_plugins',
                'randomize_dimensions'
            ]
            strategy['timing_changes'] = {
                'min_action_delay': 1.5,
                'max_action_delay': 4.5,
                'typing_speed_factor': 0.8
            }
        
        elif self.evasion_mode == "stealth":
            # Comportamento extremamente furtivo
            strategy['behavioral_changes'] = {
                'delay_factor': 2.0,
                'error_rate': 0.15,
                'hesitation_factor': 0.6,
                'movement_randomness': 0.7
            }
            strategy['browser_changes'] = [
                'mask_webdriver',
                'simulate_plugins',
                'randomize_dimensions',
                'spoof_user_agent',
                'emulate_mouse_trail',
                'simulate_focus_blur',
                'add_audio_context'
            ]
            strategy['timing_changes'] = {
                'min_action_delay': 2.0,
                'max_action_delay': 6.0,
                'typing_speed_factor': 0.6,
                'random_pauses': True
            }
        
        return strategy
    
    def detect_captcha(self, driver=None, html: Optional[str] = None) -> Tuple[bool, str]:
        """
        Detecta a presença de CAPTCHAs na página
        
        Args:
            driver: WebDriver (opcional)
            html: Conteúdo HTML da página (opcional)
            
        Returns:
            Tupla (captcha_presente, tipo_captcha)
        """
        captcha_present = False
        captcha_type = "unknown"
        
        if driver is None and html is None:
            logger.warning("Nenhum driver ou HTML fornecido para detecção de CAPTCHA")
            return False, captcha_type
        
        # Extrair HTML se driver for fornecido
        if driver is not None:
            try:
                html = driver.page_source
            except Exception as e:
                logger.warning(f"Erro ao extrair HTML para detecção de CAPTCHA: {str(e)}")
                return False, captcha_type
        
        # Verificação de reCAPTCHA
        if 'google.com/recaptcha' in html or 'g-recaptcha' in html:
            captcha_present = True
            captcha_type = "recaptcha"
            
            # Incrementar contador
            self.captcha_occurrences += 1
            self.risk_factors['unexpected_captchas'] += 0.5
        
        # Verificação de hCaptcha
        elif 'hcaptcha.com' in html or 'h-captcha' in html:
            captcha_present = True
            captcha_type = "hcaptcha"
            
            # Incrementar contador
            self.captcha_occurrences += 1
            self.risk_factors['unexpected_captchas'] += 0.5
        
        # Verificação de captcha alfanumérico
        elif ('captcha' in html.lower() and 
              ('enter the characters' in html.lower() or 
               'digite os caracteres' in html.lower() or 
               'type the characters' in html.lower())):
            captcha_present = True
            captcha_type = "text"
            
            # Incrementar contador
            self.captcha_occurrences += 1
            self.risk_factors['unexpected_captchas'] += 0.3
        
        # Verificar elementos visuais se driver disponível
        if not captcha_present and driver is not None:
            try:
                # Procurar elementos de CAPTCHA
                captcha_elements = driver.find_elements_by_xpath(
                    "//*[contains(@class, 'captcha') or contains(@id, 'captcha') or contains(@name, 'captcha')]"
                )
                
                if captcha_elements:
                    captcha_present = True
                    captcha_type = "visual"
                    
                    # Incrementar contador
                    self.captcha_occurrences += 1
                    self.risk_factors['unexpected_captchas'] += 0.3
                    
                # Verificar iframe de reCAPTCHA
                recaptcha_frames = driver.find_elements_by_xpath("//iframe[contains(@src, 'recaptcha')]")
                if recaptcha_frames:
                    captcha_present = True
                    captcha_type = "recaptcha"
                    
                    # Incrementar contador
                    self.captcha_occurrences += 1
                    self.risk_factors['unexpected_captchas'] += 0.5
            
            except Exception as e:
                logger.warning(f"Erro ao procurar elementos visuais de CAPTCHA: {str(e)}")
        
        if captcha_present:
            logger.info(f"CAPTCHA detectado: tipo={captcha_type}")
        
        return captcha_present, captcha_type
    
    def get_risk_assessment(self) -> Dict[str, Any]:
        """
        Obtém uma avaliação completa do risco atual de detecção
        
        Returns:
            Dicionário com avaliação de risco
        """
        # Calcular tempo desde última avaliação
        time_since_last = (datetime.datetime.now() - self.last_assessment_time).total_seconds()
        
        # Declinar ligeiramente o risco com o tempo (recuperação natural)
        if time_since_last > 60 and not self.detection_history:  # Só diminui se não houver detecções recentes
            decay_factor = min(time_since_last / 3600, 0.5)  # No máximo 50% de decaimento
            
            for factor in self.risk_factors:
                self.risk_factors[factor] = max(0, self.risk_factors[factor] - decay_factor * 0.1)
            
            # Recalcular risco atual
            self.current_risk_level = sum(self.risk_factors.values()) / len(self.risk_factors)
            self._update_evasion_mode()
        
        # Preparar avaliação
        assessment = {
            'overall_risk': self.current_risk_level,
            'evasion_mode': self.evasion_mode,
            'intervention_needed': self.current_risk_level >= self.intervention_threshold,
            'risk_factors': {k: round(v, 2) for k, v in self.risk_factors.items()},
            'captcha_frequency': self.captcha_occurrences,
            'recommended_actions': []
        }
        
        # Adicionar recomendações com base nos fatores de risco
        if self.risk_factors['unusual_redirects'] > 0.3:
            assessment['recommended_actions'].append('slow_down_navigation')
        
        if self.risk_factors['unexpected_captchas'] > 0.3:
            assessment['recommended_actions'].append('prepare_captcha_solving')
        
        if self.risk_factors['fingerprinting_attempts'] > 0.4:
            assessment['recommended_actions'].append('enhance_browser_cloaking')
        
        if self.risk_factors['javascript_challenges'] > 0.4:
            assessment['recommended_actions'].append('mask_automation_indicators')
        
        if self.risk_factors['browser_validation'] > 0.4:
            assessment['recommended_actions'].append('randomize_browser_properties')
        
        if self.risk_factors['timing_analysis'] > 0.3:
            assessment['recommended_actions'].append('randomize_timing')
        
        # Atualizar timestamp
        self.last_assessment_time = datetime.datetime.now()
        
        return assessment
    
    def should_rotate_identity(self) -> bool:
        """
        Determina se é hora de rotacionar identidade/fingerprint
        
        Returns:
            True se deveria rotacionar, False caso contrário
        """
        # Decisão baseada no histórico de risco
        if len(self.detection_history) >= 5:
            # Se o risco está constantemente alto
            if all(risk > 0.6 for risk in self.detection_history[-3:]):
                return True
            
            # Se houve um aumento rápido e significativo
            if self.detection_history[-1] > 0.7 and self.detection_history[-1] - self.detection_history[-2] > 0.3:
                return True
        
        # Decisão baseada em captchas
        if self.captcha_occurrences >= 3:
            return True
        
        return False
    
    def reset_detection_state(self) -> None:
        """
        Reinicializa o estado de detecção após rotação de identidade
        """
        # Manter histórico, mas resetar contadores atuais
        self.risk_factors = {k: 0.0 for k in self.risk_factors}
        self.current_risk_level = 0.0
        self.captcha_occurrences = 0
        self.evasion_mode = "cautious"  # Começar cauteloso após reset
        self.last_assessment_time = datetime.datetime.now()
        
        logger.info("Estado de detecção reinicializado")


def create_human_intervention_detector(config: Dict[str, Any] = None) -> HumanInterventionDetector:
    """
    Cria uma instância configurada do detector de intervenção humana
    
    Args:
        config: Configurações opcionais para o detector
        
    Returns:
        Instância do HumanInterventionDetector
    """
    return HumanInterventionDetector(config)