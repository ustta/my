import os
import logging
import json
from datetime import datetime
from logging.handlers import RotatingFileHandler

# Create logs directory if it doesn't exist
os.makedirs('logs', exist_ok=True)

def setup_logger(session_id=None):
    """
    Set up and configure logger for a session.
    
    Args:
        session_id: Optional session ID for identification
        
    Returns:
        Configured logger instance
    """
    logger_name = f"hotmart_uploader_{session_id}" if session_id else "hotmart_uploader"
    logger = logging.getLogger(logger_name)
    
    # Avoid duplicate handlers if logger exists
    if logger.handlers:
        return logger
    
    logger.setLevel(logging.DEBUG)
    
    # Create log file name based on session_id
    log_file = f"logs/{logger_name}.log"
    
    # Create file handler for logging to file
    file_handler = RotatingFileHandler(
        log_file, 
        maxBytes=10*1024*1024,  # 10MB
        backupCount=5
    )
    file_handler.setLevel(logging.DEBUG)
    
    # Create console handler for logging to console
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    
    # Create formatter and add it to the handlers
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)
    
    # Add handlers to logger
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    return logger

def log_to_json(session_id, level, message, timestamp=None):
    """
    Log a message to a JSON file for the web interface.
    
    Args:
        session_id: Session identifier
        level: Log level (INFO, WARNING, ERROR, etc.)
        message: Log message
        timestamp: Optional timestamp
    """
    if not timestamp:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    log_entry = {
        "timestamp": timestamp,
        "level": level,
        "message": message
    }
    
    log_file = f"logs/{session_id}_web.json"
    
    try:
        # Load existing logs if file exists
        if os.path.exists(log_file):
            with open(log_file, 'r', encoding='utf-8') as f:
                logs = json.load(f)
        else:
            logs = []
        
        # Append new log entry
        logs.append(log_entry)
        
        # Write back to file
        with open(log_file, 'w', encoding='utf-8') as f:
            json.dump(logs, f, ensure_ascii=False, indent=2)
            
    except Exception as e:
        print(f"Error writing to JSON log: {str(e)}")

def get_logs(session_id, max_count=None):
    """
    Retrieve logs for a specific session.
    
    Args:
        session_id: Session identifier
        max_count: Maximum number of log entries to return
        
    Returns:
        List of log entries
    """
    log_file = f"logs/{session_id}_web.json"
    
    try:
        if os.path.exists(log_file):
            with open(log_file, 'r', encoding='utf-8') as f:
                logs = json.load(f)
                
            # Return latest logs if max_count is specified
            if max_count and max_count > 0:
                return logs[-max_count:]
            return logs
        else:
            # Try to read from text log file as fallback
            text_log_file = f"logs/hotmart_uploader_{session_id}.log"
            if os.path.exists(text_log_file):
                logs = []
                with open(text_log_file, 'r', encoding='utf-8') as f:
                    for line in f.readlines():
                        parts = line.strip().split(' - ', 3)
                        if len(parts) >= 4:
                            timestamp = parts[0]
                            level = parts[2]
                            message = parts[3]
                            logs.append({
                                "timestamp": timestamp,
                                "level": level,
                                "message": message
                            })
                
                # Save as JSON for future use
                with open(log_file, 'w', encoding='utf-8') as f:
                    json.dump(logs, f, ensure_ascii=False, indent=2)
                
                # Return latest logs if max_count is specified
                if max_count and max_count > 0:
                    return logs[-max_count:]
                return logs
            else:
                return []
    except Exception as e:
        print(f"Error reading logs: {str(e)}")
        return []

# Logger class that also logs to JSON for web interface
class WebLogger:
    def __init__(self, session_id):
        self.session_id = session_id
        self.logger = setup_logger(session_id)
    
    def info(self, message):
        self.logger.info(message)
        log_to_json(self.session_id, "INFO", message)
    
    def warning(self, message):
        self.logger.warning(message)
        log_to_json(self.session_id, "WARNING", message)
    
    def error(self, message):
        self.logger.error(message)
        log_to_json(self.session_id, "ERROR", message)
    
    def debug(self, message):
        self.logger.debug(message)
        log_to_json(self.session_id, "DEBUG", message)
