import datetime
import uuid
import json
from sqlalchemy.ext.mutable import MutableDict, MutableList
from werkzeug.security import generate_password_hash, check_password_hash
from app import db
from flask_login import UserMixin
from flask_dance.consumer.storage.sqla import OAuthConsumerMixin
from sqlalchemy import UniqueConstraint


class User(UserMixin, db.Model):
    """Modelo de usuário para gerenciar acesso ao sistema"""
    id = db.Column(db.Integer, primary_key=True)  # Mantemos como Integer para compatibilidade
    replit_id = db.Column(db.String, unique=True, nullable=True)  # ID do Replit para autenticação
    email = db.Column(db.String(120), unique=True, nullable=True)
    username = db.Column(db.String(64), unique=True, nullable=True)
    password_hash = db.Column(db.String(256), nullable=True)
    first_name = db.Column(db.String(100), nullable=True)
    last_name = db.Column(db.String(100), nullable=True)
    profile_image_url = db.Column(db.String, nullable=True)
    role = db.Column(db.String(20), default="user")  # admin, user
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)
    auth_type = db.Column(db.String(20), default="local")  # local, replit
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def is_admin(self):
        return self.role == "admin"
        
    def get_id(self):
        return str(self.id)
    
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'profile_image_url': self.profile_image_url,
            'role': self.role,
            'is_active': self.active,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

# Modelo OAuth necessário para autenticação Replit
class OAuth(OAuthConsumerMixin, db.Model):
    user_id = db.Column(db.Integer, db.ForeignKey(User.id))
    browser_session_key = db.Column(db.String, nullable=False)
    user = db.relationship(User)

    __table_args__ = (UniqueConstraint(
        'user_id',
        'browser_session_key',
        'provider',
        name='uq_user_browser_session_key_provider',
    ),)

class Product(db.Model):
    """Modelo para produtos a serem enviados para Hotmart"""
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    price = db.Column(db.Float, nullable=False, default=97.0)
    category = db.Column(db.String(100), nullable=True)
    format_type = db.Column(db.String(100), nullable=True)
    language = db.Column(db.String(50), nullable=True)
    file_path = db.Column(db.String(500), nullable=True)
    file_name = db.Column(db.String(255), nullable=True)
    file_size = db.Column(db.Float, nullable=True)  # Tamanho em MB
    
    # Dados Hotmart
    hotmart_id = db.Column(db.String(100), nullable=True)
    hotmart_url = db.Column(db.String(500), nullable=True)
    
    # Estratégia de preço
    pricing_strategy = db.Column(MutableDict.as_mutable(db.JSON), nullable=True)
    
    # Estado atual
    status = db.Column(db.String(50), default="pending")  # pending, processing, uploaded, failed
    upload_attempts = db.Column(db.Integer, default=0)
    last_attempt = db.Column(db.DateTime, nullable=True)
    error_details = db.Column(db.Text, nullable=True)
    
    # Campos de auditoria
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    
    def __repr__(self):
        return f'<Product {self.title}>'
    
    def to_dict(self):
        """Converte o modelo para dicionário para respostas API"""
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'price': self.price,
            'category': self.category,
            'format_type': self.format_type,
            'language': self.language,
            'file_name': self.file_name,
            'file_size': self.file_size,
            'hotmart_id': self.hotmart_id,
            'hotmart_url': self.hotmart_url,
            'pricing_strategy': self.pricing_strategy,
            'status': self.status,
            'upload_attempts': self.upload_attempts,
            'last_attempt': self.last_attempt.isoformat() if self.last_attempt else None,
            'error_details': self.error_details,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class UploadSession(db.Model):
    """Modelo para rastrear sessões de upload"""
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.String(100), unique=True, nullable=False, default=lambda: str(uuid.uuid4()))
    status = db.Column(db.String(50), default="active")  # active, paused, completed, failed
    start_time = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    end_time = db.Column(db.DateTime, nullable=True)
    total_products = db.Column(db.Integer, default=0)
    successful_uploads = db.Column(db.Integer, default=0)
    failed_uploads = db.Column(db.Integer, default=0)
    
    # Produtos associados (relação muitos-para-muitos)
    product_association = db.relationship('SessionProduct', backref='session', lazy='dynamic', cascade='all, delete-orphan')
    
    # Configurações da sessão
    config = db.Column(MutableDict.as_mutable(db.JSON), nullable=True)
    
    # Informações de segurança
    browser_fingerprint = db.Column(db.String(255), nullable=True)
    proxy_used = db.Column(db.String(255), nullable=True)
    
    # Informações de auditoria
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)
    
    def __repr__(self):
        return f'<UploadSession {self.session_id}>'
    
    def to_dict(self):
        """Converte o modelo para dicionário para respostas API"""
        return {
            'id': self.id,
            'session_id': self.session_id,
            'status': self.status,
            'start_time': self.start_time.isoformat() if self.start_time else None,
            'end_time': self.end_time.isoformat() if self.end_time else None,
            'total_products': self.total_products,
            'successful_uploads': self.successful_uploads,
            'failed_uploads': self.failed_uploads,
            'config': self.config,
            'duration': self.calculate_duration(),
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    def calculate_duration(self):
        """Calcula a duração da sessão em segundos"""
        if not self.end_time:
            return None
        
        duration = (self.end_time - self.start_time).total_seconds()
        return round(duration)

class SessionProduct(db.Model):
    """Modelo para associação entre sessões e produtos"""
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey('upload_session.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    status = db.Column(db.String(50), default="pending")  # pending, processing, uploaded, failed
    processed_at = db.Column(db.DateTime, nullable=True)
    error_details = db.Column(db.Text, nullable=True)
    
    # Definir relação com o produto
    product = db.relationship('Product', backref='session_associations')
    
    def to_dict(self):
        return {
            'id': self.id,
            'session_id': self.session_id,
            'product_id': self.product_id,
            'status': self.status,
            'processed_at': self.processed_at.isoformat() if self.processed_at else None,
            'error_details': self.error_details
        }

class UIElement(db.Model):
    """Modelo para armazenar elementos UI e seus seletores"""
    id = db.Column(db.Integer, primary_key=True)
    element_name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    page_url_pattern = db.Column(db.String(500), nullable=False)
    selector_strategy = db.Column(MutableDict.as_mutable(db.JSON), nullable=False)
    last_used = db.Column(db.DateTime, nullable=True)
    success_count = db.Column(db.Integer, default=0)
    failure_count = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)
    
    def __repr__(self):
        return f'<UIElement {self.element_name}>'
    
    def to_dict(self):
        """Converte o modelo para dicionário para respostas API"""
        return {
            'id': self.id,
            'element_name': self.element_name,
            'description': self.description,
            'page_url_pattern': self.page_url_pattern,
            'selector_strategy': self.selector_strategy,
            'last_used': self.last_used.isoformat() if self.last_used else None,
            'success_count': self.success_count,
            'failure_count': self.failure_count,
            'success_rate': self.calculate_success_rate(),
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def calculate_success_rate(self):
        """Calcula a taxa de sucesso para este elemento"""
        total = self.success_count + self.failure_count
        if total == 0:
            return None
        
        return round((self.success_count / total) * 100, 2)

class SystemConfig(db.Model):
    """Modelo para armazenar configuração do sistema"""
    id = db.Column(db.Integer, primary_key=True)
    config_name = db.Column(db.String(100), unique=True, nullable=False)
    config_value = db.Column(MutableDict.as_mutable(db.JSON), nullable=True)
    updated_at = db.Column(db.DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)
    
    def __repr__(self):
        return f'<SystemConfig {self.config_name}>'

class TaskQueue(db.Model):
    """Modelo para gerenciamento de fila de tarefas"""
    id = db.Column(db.Integer, primary_key=True)
    task_type = db.Column(db.String(50), nullable=False)
    priority = db.Column(db.Integer, default=5)  # 1-10, 10 sendo o mais alto
    status = db.Column(db.String(50), default="pending")  # pending, processing, completed, failed
    payload = db.Column(MutableDict.as_mutable(db.JSON), nullable=False)
    result = db.Column(MutableDict.as_mutable(db.JSON), nullable=True)
    error = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)
    scheduled_for = db.Column(db.DateTime, nullable=True)
    
    def __repr__(self):
        return f'<TaskQueue {self.task_type}>'
    
    def to_dict(self):
        """Converte o modelo para dicionário para respostas API"""
        return {
            'id': self.id,
            'task_type': self.task_type,
            'priority': self.priority,
            'status': self.status,
            'payload': self.payload,
            'result': self.result,
            'error': self.error,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'scheduled_for': self.scheduled_for.isoformat() if self.scheduled_for else None
        }