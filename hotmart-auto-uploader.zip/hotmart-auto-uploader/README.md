# Hotmart Auto-Uploader

Sistema automatizado para uploads na Hotmart com simulação realista de comportamento humano, interface web e CLI.

## Características

- **Simulação de Comportamento Humano**: Evita detecção usando padrões humanos realistas
- **Interface Web**: Dashboard para controle e gerenciamento
- **Interface CLI**: Acesso via terminal para operações automatizadas
- **Antidetecção**: Mecanismos avançados para evitar bloqueios
- **Análise Adaptativa**: Aprende e se adapta às mudanças da plataforma
- **Tratamento de CAPTCHAs**: Resolução automática de desafios
- **Gestão de Sessões**: Controle e acompanhamento de múltiplas sessões

## Requisitos

- Python 3.9+
- PostgreSQL
- Node.js (opcional, para determinadas funcionalidades)
- ChromeDriver (para automação do navegador)

## Instalação

1. Clone o repositório:
```bash
git clone https://github.com/seu-usuario/hotmart-auto-uploader.git
cd hotmart-auto-uploader
```

2. Instale as dependências:
```bash
pip install -r requirements.txt
```

3. Configure o banco de dados PostgreSQL:
```bash
export DATABASE_URL=postgresql://usuario:senha@localhost/hotmart_uploader
```

4. Inicialize o banco de dados:
```bash
python cli.py init-db
```

5. Execute a aplicação web:
```bash
gunicorn --bind 0.0.0.0:5000 main:app
```

## Uso via CLI

```bash
# Ver ajuda
python cli.py --help

# Adicionar um produto
python cli.py add-product --title "Curso XYZ" --price 97.00 --file /caminho/para/arquivo.zip

# Iniciar uma sessão de upload
python cli.py create-session --products 1,2,3

# Verificar status
python cli.py list-sessions
```

## Uso via Interface Web

1. Acesse `http://localhost:5000` em seu navegador
2. Faça login com suas credenciais
3. Use o dashboard para gerenciar produtos e sessões

## Configuração

- `/config/stealth_config.json`: Configurações para evasão de detecção
- Configurações adicionais disponíveis na interface web

## Segurança

- Este software foi desenvolvido apenas para fins educacionais e uso legítimo
- O uso impróprio pode violar os termos de serviço da Hotmart
- Os usuários são responsáveis por como utilizam esta ferramenta

## Suporte à API OpenAI

Para habilitar recursos avançados com IA:

1. Adicione sua chave da API OpenAI nas configurações do sistema
2. Ative o modo de inteligência adaptativa

## Licença

Este projeto está licenciado sob a MIT License.