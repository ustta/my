#!/bin/bash

# Script de instalação para o Hotmart Auto-Uploader
echo "=== Iniciando instalação do Hotmart Auto-Uploader ==="

# Verificar requisitos
command -v python3 >/dev/null 2>&1 || { echo "Python 3 não encontrado. Por favor, instale o Python 3.9+"; exit 1; }
command -v pip >/dev/null 2>&1 || { echo "Pip não encontrado. Por favor, instale o pip"; exit 1; }

# Criar ambiente virtual
echo "Criando ambiente virtual..."
python3 -m venv venv

# Ativar ambiente virtual
echo "Ativando ambiente virtual..."
source venv/bin/activate

# Instalar dependências
echo "Instalando dependências..."
pip install -r requirements.txt

# Verificar variáveis de ambiente
if [ -z "$DATABASE_URL" ]; then
    echo "AVISO: Variável DATABASE_URL não está definida."
    echo "Por favor, defina a variável de ambiente DATABASE_URL com sua conexão PostgreSQL."
    echo "Exemplo: export DATABASE_URL=postgresql://usuario:senha@localhost/hotmart_uploader"
fi

# Verificar diretórios necessários
mkdir -p config data logs static/css static/js templates uploads

# Verificar configurações do banco de dados
echo "Verificando banco de dados..."
if [ -n "$DATABASE_URL" ]; then
    # Inicializar banco de dados se DATABASE_URL estiver definido
    python cli.py init-db
    if [ $? -eq 0 ]; then
        echo "Banco de dados inicializado com sucesso!"
    else
        echo "ERRO: Falha ao inicializar o banco de dados. Verifique sua conexão PostgreSQL."
    fi
else
    echo "Pulando inicialização do banco de dados. Configure DATABASE_URL primeiro."
fi

echo ""
echo "=== Instalação concluída! ==="
echo ""
echo "Para iniciar a aplicação web:"
echo "  source venv/bin/activate"
echo "  gunicorn --bind 0.0.0.0:5000 main:app"
echo ""
echo "Para usar a interface CLI:"
echo "  source venv/bin/activate"
echo "  python cli.py --help"
echo ""
echo "IMPORTANTE: Configure sua chave de API OpenAI nas configurações do sistema"
echo "para habilitar recursos de inteligência adaptativa."
echo ""