"""
Script de inicialização da aplicação Hotmart Auto-Uploader
"""

from app import app
import routes
import logging

# Configurar logging
logging.basicConfig(level=logging.DEBUG,
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Verificar se o aplicativo está sendo executado diretamente
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)