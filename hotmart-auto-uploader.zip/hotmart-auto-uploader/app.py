import os
import logging
from datetime import datetime
from flask import Flask, redirect, url_for, request, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from flask_socketio import SocketIO
from werkzeug.security import generate_password_hash
from werkzeug.middleware.proxy_fix import ProxyFix

# Configuração de logging
logging.basicConfig(level=logging.INFO,
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                   handlers=[
                       logging.FileHandler('logs/app.log'),
                       logging.StreamHandler()
                   ])

logger = logging.getLogger('app')

# Criar pasta de logs se não existir
if not os.path.exists('logs'):
    os.makedirs('logs')
    
# Criar pasta de uploads se não existir
if not os.path.exists('uploads'):
    os.makedirs('uploads')
    
# Criar pasta de dados se não existir
if not os.path.exists('data'):
    os.makedirs('data')

# Classe base para SQLAlchemy
class Base(DeclarativeBase):
    pass

# Inicialização do Flask
app = Flask(__name__)
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)
app.secret_key = os.environ.get('SESSION_SECRET', 'hotmart-auto-uploader-secret-key')

# Configurações de uploads
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100MB max

# Configurações do banco de dados
database_url = os.environ.get('DATABASE_URL')
if not database_url:
    if not os.path.exists('data'):
        os.makedirs('data')
    database_url = "sqlite:///data/hotmart_uploader.db"

app.config['SQLALCHEMY_DATABASE_URI'] = database_url
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'pool_pre_ping': True,
    'pool_recycle': 300,
}

# Inicialização do banco de dados
db = SQLAlchemy(model_class=Base)
db.init_app(app)

# Inicialização do Socket.IO
socketio = SocketIO(app, cors_allowed_origins="*")

# As rotas estão definidas diretamente no módulo routes
# Portanto, não usamos blueprints nessa implementação

# Inicializar banco de dados e criar usuário admin se não existir
with app.app_context():
    # Criar tabelas do banco de dados
    import models
    db.create_all()
    logger.info("Tabelas do banco de dados criadas com sucesso")
    
    # Verificar e criar diretórios necessários
    for dir_path in ['uploads', 'logs', 'data']:
        if not os.path.exists(dir_path):
            os.makedirs(dir_path)
    
    # Criar usuário admin caso não exista
    from models import User
    admin_user = User.query.filter_by(username='admin').first()
    if not admin_user:
        admin_user = User()
        admin_user.username = 'admin'
        admin_user.email = 'admin@example.com'
        admin_user.password_hash = generate_password_hash('admin123')
        admin_user.role = 'admin'
        admin_user.active = True
        admin_user.created_at = datetime.utcnow()
        
        db.session.add(admin_user)
        db.session.commit()
        logger.info("Usuário admin criado com sucesso")
    
    # Verificar conexão com o banco de dados
    try:
        from sqlalchemy import text
        db.session.execute(text("SELECT 1")).scalar()
        logger.info("Conexão com o banco de dados estabelecida com sucesso")
    except Exception as e:
        logger.error(f"Erro ao conectar ao banco de dados: {str(e)}")
    
    logger.info("Aplicação inicializada com sucesso")

# Tratar erros 404
@app.errorhandler(404)
def page_not_found(e):
    return redirect(url_for('dashboard'))

# Tratar erros 500
@app.errorhandler(500)
def server_error(e):
    return jsonify(error=str(e)), 500

if __name__ == "__main__":
    socketio.run(app, host="0.0.0.0", port=5000, debug=True, use_reloader=True, log_output=True)