from flask import session, render_template, redirect, url_for, flash, request, jsonify, send_from_directory
from app import app, db
from replit_auth import require_login, make_replit_blueprint
from flask_login import current_user
from models import Product, UploadSession, SessionProduct, UIElement, SystemConfig, TaskQueue
import os
import logging
import datetime

# Configurar logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Registrar o blueprint do Replit Auth
app.register_blueprint(make_replit_blueprint(), url_prefix="/auth")

# Tornar a sessão permanente
@app.before_request
def make_session_permanent():
    session.permanent = True

# Rotas para páginas
@app.route('/')
def dashboard():
    """Página principal do dashboard"""
    try:
        # Iniciar com valores padrão
        products_count = 0
        uploaded_count = 0
        pending_count = 0
        failed_count = 0
        active_sessions = []
        recent_sessions = []
        
        # Estatísticas do sistema (com valores default)
        system_stats = {
            'risk_level': 2,  # Valor padrão baixo
            'operation_mode': 'stealth',
            'captcha_count': 0,
            'js_challenges': 0,
            'unusual_redirects': 0,
            'recommendations': []
        }
        
        # Verificar se OpenAI está configurado (padrão: falso)
        openai_enabled = False
        
        # Executar cada consulta em uma transação separada para evitar que uma falha afete todas as outras
        # Estatísticas dos produtos
        try:
            products_count = db.session.query(db.func.count(Product.id)).scalar() or 0
            uploaded_count = db.session.query(db.func.count(Product.id)).filter(Product.status=='uploaded').scalar() or 0
            pending_count = db.session.query(db.func.count(Product.id)).filter(Product.status=='pending').scalar() or 0
            failed_count = db.session.query(db.func.count(Product.id)).filter(Product.status=='failed').scalar() or 0
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            logger.error(f"Erro ao contar produtos: {str(e)}")
        
        # Sessões ativas
        try:
            active_sessions = db.session.query(UploadSession).filter(
                UploadSession.status=='active'
            ).order_by(UploadSession.start_time.desc()).limit(5).all()
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            logger.error(f"Erro ao buscar sessões ativas: {str(e)}")
            active_sessions = []
        
        # Sessões recentes    
        try:
            recent_sessions = db.session.query(UploadSession).order_by(
                UploadSession.start_time.desc()
            ).limit(5).all()
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            logger.error(f"Erro ao buscar sessões recentes: {str(e)}")
            recent_sessions = []
        
        # Configuração do sistema
        try:
            sys_config = db.session.query(SystemConfig).filter(
                SystemConfig.config_name=='system_stats'
            ).first()
            if sys_config and sys_config.config_value:
                # Use update para manter os valores default se não existirem no banco
                system_stats.update(sys_config.config_value)
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            logger.error(f"Erro ao carregar estatísticas do sistema: {str(e)}")
        
        # Configuração da OpenAI
        try:
            openai_config = db.session.query(SystemConfig).filter(
                SystemConfig.config_name=='openai_settings'
            ).first()
            if openai_config and openai_config.config_value and 'api_key' in openai_config.config_value:
                openai_enabled = bool(openai_config.config_value.get('api_key'))
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            logger.error(f"Erro ao verificar configuração da OpenAI: {str(e)}")
            
        # Renderizar o template com todos os dados coletados
        return render_template('index.html', 
                              products_count=products_count,
                              uploaded_count=uploaded_count,
                              pending_count=pending_count,
                              failed_count=failed_count,
                              active_sessions=active_sessions,
                              recent_sessions=recent_sessions,
                              system_stats=system_stats,
                              openai_enabled=openai_enabled)
    except Exception as e:
        logger.error(f"Erro ao carregar dashboard: {str(e)}")
        flash(f"Erro ao carregar dashboard: {str(e)}", "danger")
        # Renderizar com valores padrão em caso de erro geral
        return render_template('index.html', 
                              products_count=0,
                              uploaded_count=0,
                              pending_count=0,
                              failed_count=0,
                              active_sessions=[],
                              recent_sessions=[],
                              system_stats={
                                  'risk_level': 0,
                                  'operation_mode': 'desconhecido',
                                  'captcha_count': 0,
                                  'js_challenges': 0,
                                  'recommendations': []
                              },
                              openai_enabled=False)

@app.route('/produtos')
@require_login
def products():
    """Lista de produtos"""
    try:
        products = Product.query.order_by(Product.created_at.desc()).all()
        return render_template('produtos.html', products=products)
    except Exception as e:
        logger.error(f"Erro ao listar produtos: {str(e)}")
        flash(f"Erro ao listar produtos: {str(e)}", "danger")
        return render_template('produtos.html', products=[])

@app.route('/produtos/novo', methods=['GET', 'POST'])
@require_login
def new_product():
    """Formulário para novo produto"""
    if request.method == 'POST':
        try:
            # Extrair dados do formulário
            title = request.form.get('title')
            description = request.form.get('description')
            price = float(request.form.get('price', 97.0))
            category = request.form.get('category')
            format_type = request.form.get('format_type')
            language = request.form.get('language', 'pt-BR')
            
            # Criar novo produto
            product = Product()
            product.title = title
            product.description = description
            product.price = price
            product.category = category
            product.format_type = format_type
            product.language = language
            product.status = 'pending'
            product.created_by = current_user.id
            
            # Processar arquivo, se existir
            if 'file' in request.files:
                file = request.files['file']
                if file.filename:
                    # Salvar arquivo
                    upload_folder = os.path.join(app.root_path, 'uploads')
                    if not os.path.exists(upload_folder):
                        os.makedirs(upload_folder)
                    
                    filepath = os.path.join(upload_folder, file.filename)
                    file.save(filepath)
                    
                    product.file_path = filepath
                    product.file_name = file.filename
                    product.file_size = os.path.getsize(filepath) / (1024 * 1024)  # Tamanho em MB
            
            # Processar estratégia de preço
            pricing_strategy = {
                'base_price': price,
                'discount_enabled': request.form.get('discount_enabled') == 'on',
                'discount_value': float(request.form.get('discount_value', 0)),
                'discount_type': request.form.get('discount_type', 'percent'),
                'installments_enabled': request.form.get('installments_enabled') == 'on',
                'max_installments': int(request.form.get('max_installments', 12))
            }
            product.pricing_strategy = pricing_strategy
            
            # Salvar no banco de dados
            db.session.add(product)
            db.session.commit()
            
            flash("Produto criado com sucesso!", "success")
            return redirect(url_for('products'))
        except Exception as e:
            logger.error(f"Erro ao criar produto: {str(e)}")
            flash(f"Erro ao criar produto: {str(e)}", "danger")
    
    # Carregar categorias e formatos disponíveis
    categories = ['Educação', 'Finanças', 'Saúde', 'Bem-estar', 'Marketing', 'Tecnologia', 'Outros']
    formats = ['E-book', 'Curso', 'Audiobook', 'Software', 'Template', 'Vídeo', 'Outros']
    
    return render_template('product_form.html', product=None, categories=categories, formats=formats)

@app.route('/sessoes/nova', methods=['GET', 'POST'])
@require_login
def new_session():
    """Criação de nova sessão de upload"""
    if request.method == 'POST':
        try:
            # Criar nova sessão
            session = UploadSession()
            session.status = 'active'
            session.start_time = datetime.datetime.utcnow()
            
            # Configurações da sessão
            config = {
                'max_simultaneous': int(request.form.get('max_simultaneous', 1)),
                'stealth_mode': request.form.get('stealth_mode') == 'on',
                'wait_between': int(request.form.get('wait_between', 30)),
                'retry_failed': request.form.get('retry_failed') == 'on',
                'max_retries': int(request.form.get('max_retries', 3)),
                'browser_profile': request.form.get('browser_profile', 'default')
            }
            session.config = config
            
            # Salvar sessão
            db.session.add(session)
            db.session.commit()
            
            # Adicionar produtos selecionados
            selected_products = request.form.getlist('products')
            for product_id in selected_products:
                sp = SessionProduct()
                sp.session_id = session.id
                sp.product_id = int(product_id)
                sp.status = 'pending'
                db.session.add(sp)
            
            # Atualizar contagem
            session.total_products = len(selected_products)
            db.session.commit()
            
            # Criar tarefa na fila
            task = TaskQueue()
            task.task_type = 'upload_session'
            task.priority = 10
            task.status = 'pending'
            task.payload = {'session_id': session.id}
            
            db.session.add(task)
            db.session.commit()
            
            flash("Sessão de upload criada com sucesso!", "success")
            return redirect(url_for('sessions'))
        except Exception as e:
            logger.error(f"Erro ao criar sessão: {str(e)}")
            flash(f"Erro ao criar sessão: {str(e)}", "danger")
    
    # Buscar produtos pendentes
    products = Product.query.filter_by(status='pending').all()
    
    # Carregar perfis de navegador disponíveis
    browser_profiles = ['default', 'Windows/Chrome', 'Mac/Safari', 'Linux/Firefox', 'Android/Mobile', 'iOS/Mobile']
    
    return render_template('session_form.html', products=products, browser_profiles=browser_profiles)

@app.route('/sessoes')
@require_login
def sessions():
    """Lista de sessões de upload"""
    try:
        sessions = UploadSession.query.order_by(UploadSession.created_at.desc()).all()
        return render_template('sessions.html', sessions=sessions)
    except Exception as e:
        logger.error(f"Erro ao listar sessões: {str(e)}")
        flash(f"Erro ao listar sessões: {str(e)}", "danger")
        return render_template('sessions.html', sessions=[])

@app.route('/sessoes/<int:session_id>')
@require_login
def session_detail(session_id):
    """Detalhes de uma sessão específica"""
    try:
        session = UploadSession.query.get_or_404(session_id)
        products = db.session.query(Product, SessionProduct).join(
            SessionProduct, Product.id == SessionProduct.product_id
        ).filter(SessionProduct.session_id == session_id).all()
        
        return render_template('session_detail.html', session=session, products=products)
    except Exception as e:
        logger.error(f"Erro ao mostrar sessão {session_id}: {str(e)}")
        flash(f"Erro ao mostrar sessão: {str(e)}", "danger")
        return redirect(url_for('sessions'))

@app.route('/logs')
@require_login
def logs():
    """Visualização de logs do sistema"""
    try:
        # Ler os últimos logs
        log_entries = []
        log_path = os.path.join(app.root_path, 'logs', 'app.log')
        
        if os.path.exists(log_path):
            with open(log_path, 'r') as f:
                log_lines = f.readlines()
                # Pegar as últimas 200 linhas
                log_entries = log_lines[-200:]
        
        return render_template('logs.html', log_entries=log_entries)
    except Exception as e:
        logger.error(f"Erro ao ler logs: {str(e)}")
        flash(f"Erro ao ler logs: {str(e)}", "danger")
        return render_template('logs.html', log_entries=[])

@app.route('/configuracoes', methods=['GET', 'POST'])
@require_login
def settings():
    """Configurações do sistema"""
    if request.method == 'POST':
        try:
            # Salvar configurações gerais
            system_config = SystemConfig.query.filter_by(config_name='system_settings').first()
            if not system_config:
                system_config = SystemConfig()
                system_config.config_name = 'system_settings'
            
            system_config.config_value = {
                'operation_mode': request.form.get('operation_mode', 'stealth'),
                'proxy_enabled': request.form.get('proxy_enabled') == 'on',
                'proxy_url': request.form.get('proxy_url', ''),
                'default_wait_time': int(request.form.get('default_wait_time', 30)),
                'auto_retry': request.form.get('auto_retry') == 'on',
                'max_retries': int(request.form.get('max_retries', 3))
            }
            
            # Salvar configurações da OpenAI
            openai_config = SystemConfig.query.filter_by(config_name='openai_settings').first()
            if not openai_config:
                openai_config = SystemConfig()
                openai_config.config_name = 'openai_settings'
            
            openai_config.config_value = {
                'api_key': request.form.get('openai_api_key', ''),
                'model': request.form.get('openai_model', 'gpt-4-vision-preview'),
                'max_tokens': int(request.form.get('openai_max_tokens', 4000)),
                'temperature': float(request.form.get('openai_temperature', 0.5))
            }
            
            db.session.add(system_config)
            db.session.add(openai_config)
            db.session.commit()
            
            flash("Configurações salvas com sucesso!", "success")
        except Exception as e:
            logger.error(f"Erro ao salvar configurações: {str(e)}")
            flash(f"Erro ao salvar configurações: {str(e)}", "danger")
    
    # Carregar configurações
    settings = {}
    openai_settings = {}
    
    system_config = SystemConfig.query.filter_by(config_name='system_settings').first()
    if system_config and system_config.config_value:
        settings = system_config.config_value
    
    openai_config = SystemConfig.query.filter_by(config_name='openai_settings').first()
    if openai_config and openai_config.config_value:
        openai_settings = openai_config.config_value
    
    return render_template('settings.html', settings=settings, openai_settings=openai_settings)

@app.route('/uploads/<path:filename>')
@require_login
def download_file(filename):
    """Download de arquivos"""
    upload_folder = os.path.join(app.root_path, 'uploads')
    return send_from_directory(upload_folder, filename, as_attachment=True)

# Tratamento de erros
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(e):
    return render_template('500.html'), 500