import os
import datetime
import json
import logging
from flask import Blueprint, request, jsonify, current_app as app
from werkzeug.utils import secure_filename
from models import db, Product, UploadSession, UIElement, SystemConfig, TaskQueue, SessionProduct
from sqlalchemy import desc, or_

# Configurar logger
logger = logging.getLogger(__name__)

# Definir blueprint
api_bp = Blueprint('api', __name__)

# Middleware para verificar chave API em todos os endpoints
@api_bp.before_request
def validate_api_access():
    # Implementar futuramente se necessário
    pass

# API status
@api_bp.route('/status', methods=['GET'])
def api_status():
    # Verificar estado de sistemas críticos
    db_status = check_database_status()
    
    # Verificar configuração da API OpenAI
    openai_config = SystemConfig.query.filter_by(config_name='openai_api').first()
    openai_api_key_configured = False
    if openai_config and openai_config.config_value:
        openai_api_key_configured = bool(openai_config.config_value.get('api_key'))
    
    # Verificar estatísticas do sistema
    system_config = SystemConfig.query.filter_by(config_name='system_stats').first()
    system_stats = {}
    if system_config and system_config.config_value:
        system_stats = system_config.config_value
    
    return jsonify({
        'status': 'success',
        'timestamp': datetime.datetime.utcnow().isoformat(),
        'version': '1.0.0',
        'database': {
            'status': 'connected' if db_status else 'error',
            'errors': [] if db_status else ['Não foi possível conectar ao banco de dados']
        },
        'system_config': {
            'openai_api_key_configured': openai_api_key_configured
        },
        'statistics': system_stats
    })

def check_database_status():
    """Verifica o status da conexão com o banco de dados"""
    try:
        # Tentar realizar uma consulta simples
        from sqlalchemy import text
        db.session.execute(text("SELECT 1")).scalar()
        return True
    except Exception as e:
        logger.error(f"Erro ao verificar status do banco de dados: {str(e)}")
        return False

# === Endpoints de Produtos ===

# Listar produtos
@api_bp.route('/products', methods=['GET'])
def get_products():
    try:
        # Parâmetros de filtro
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        status = request.args.get('status', '')
        category = request.args.get('category', '')
        search = request.args.get('search', '')
        
        # Construir query
        query = Product.query
        
        if status:
            query = query.filter_by(status=status)
        
        if category:
            query = query.filter_by(category=category)
        
        if search:
            query = query.filter(or_(
                Product.title.ilike(f'%{search}%'),
                Product.description.ilike(f'%{search}%')
            ))
        
        # Ordenar
        query = query.order_by(desc(Product.created_at))
        
        # Paginar
        products_page = query.paginate(page=page, per_page=per_page)
        
        # Formatar resultado
        result = {
            'status': 'success',
            'page': products_page.page,
            'per_page': products_page.per_page,
            'total': products_page.total,
            'total_pages': products_page.pages,
            'has_next': products_page.has_next,
            'has_prev': products_page.has_prev,
            'items': [p.to_dict() for p in products_page.items]
        }
        
        return jsonify(result)
    
    except Exception as e:
        logger.error(f"Erro ao listar produtos: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': f"Erro ao listar produtos: {str(e)}"
        }), 500

# Detalhes do produto
@api_bp.route('/products/<int:product_id>', methods=['GET'])
def get_product(product_id):
    try:
        product = Product.query.get_or_404(product_id)
        return jsonify({
            'status': 'success',
            'product': product.to_dict()
        })
    
    except Exception as e:
        logger.error(f"Erro ao obter produto {product_id}: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': f"Erro ao obter produto: {str(e)}"
        }), 500

# Criar produto
@api_bp.route('/products', methods=['POST'])
def create_product():
    try:
        data = request.json
        
        # Validar dados obrigatórios
        if not data.get('title'):
            return jsonify({
                'status': 'error',
                'message': 'O título do produto é obrigatório'
            }), 400
        
        # Criar novo produto
        product = Product()
        product.title = data.get('title')
        product.description = data.get('description')
        product.price = float(data.get('price', 97.0))
        product.category = data.get('category')
        product.format_type = data.get('format_type')
        product.language = data.get('language')
        product.file_name = data.get('file_name')
        product.file_path = data.get('file_path')
        product.file_size = data.get('file_size')
        product.pricing_strategy = data.get('pricing_strategy')
        product.status = 'pending'
        product.created_at = datetime.datetime.utcnow()
        
        # Salvar no banco de dados
        db.session.add(product)
        db.session.commit()
        
        return jsonify({
            'status': 'success',
            'message': 'Produto criado com sucesso',
            'product': product.to_dict()
        }), 201
    
    except Exception as e:
        logger.error(f"Erro ao criar produto: {str(e)}")
        db.session.rollback()
        return jsonify({
            'status': 'error',
            'message': f"Erro ao criar produto: {str(e)}"
        }), 500

# Atualizar produto
@api_bp.route('/products/<int:product_id>', methods=['PUT', 'PATCH'])
def update_product(product_id):
    try:
        product = Product.query.get_or_404(product_id)
        data = request.json
        
        # Atualizar campos
        if 'title' in data:
            product.title = data['title']
        
        if 'description' in data:
            product.description = data['description']
        
        if 'price' in data:
            product.price = float(data['price'])
        
        if 'category' in data:
            product.category = data['category']
        
        if 'format_type' in data:
            product.format_type = data['format_type']
        
        if 'language' in data:
            product.language = data['language']
        
        if 'file_name' in data:
            product.file_name = data['file_name']
        
        if 'file_path' in data:
            product.file_path = data['file_path']
        
        if 'file_size' in data:
            product.file_size = data['file_size']
        
        if 'pricing_strategy' in data:
            product.pricing_strategy = data['pricing_strategy']
        
        if 'status' in data:
            product.status = data['status']
        
        # Atualizar timestamp
        product.updated_at = datetime.datetime.utcnow()
        
        # Salvar mudanças
        db.session.commit()
        
        return jsonify({
            'status': 'success',
            'message': 'Produto atualizado com sucesso',
            'product': product.to_dict()
        })
    
    except Exception as e:
        logger.error(f"Erro ao atualizar produto {product_id}: {str(e)}")
        db.session.rollback()
        return jsonify({
            'status': 'error',
            'message': f"Erro ao atualizar produto: {str(e)}"
        }), 500

# Excluir produto
@api_bp.route('/products/<int:product_id>', methods=['DELETE'])
def delete_product(product_id):
    try:
        product = Product.query.get_or_404(product_id)
        
        # Verificar se está associado a alguma sessão ativa
        active_associations = SessionProduct.query \
            .join(UploadSession, SessionProduct.session_id == UploadSession.id) \
            .filter(SessionProduct.product_id == product_id) \
            .filter(UploadSession.status == 'active') \
            .first()
        
        if active_associations:
            return jsonify({
                'status': 'error',
                'message': 'Não é possível excluir um produto associado a uma sessão ativa'
            }), 400
        
        # Tentar excluir arquivo físico se existir
        if product.file_path and os.path.exists(product.file_path):
            try:
                os.remove(product.file_path)
            except Exception as e:
                logger.warning(f"Erro ao excluir arquivo físico: {str(e)}")
        
        # Excluir do banco de dados
        db.session.delete(product)
        db.session.commit()
        
        return jsonify({
            'status': 'success',
            'message': 'Produto excluído com sucesso'
        })
    
    except Exception as e:
        logger.error(f"Erro ao excluir produto {product_id}: {str(e)}")
        db.session.rollback()
        return jsonify({
            'status': 'error',
            'message': f"Erro ao excluir produto: {str(e)}"
        }), 500

# Upload de arquivo para produto
@api_bp.route('/products/<int:product_id>/upload', methods=['POST'])
def upload_product_file(product_id):
    try:
        product = Product.query.get_or_404(product_id)
        
        # Verificar se arquivo foi enviado
        if 'file' not in request.files:
            return jsonify({
                'status': 'error',
                'message': 'Nenhum arquivo enviado'
            }), 400
        
        file = request.files['file']
        
        # Verificar se arquivo tem nome
        if file.filename == '':
            return jsonify({
                'status': 'error',
                'message': 'Arquivo sem nome'
            }), 400
        
        # Salvar arquivo
        if file:
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            
            # Atualizar informações do produto
            product.file_name = filename
            product.file_path = file_path
            product.file_size = os.path.getsize(file_path) / (1024 * 1024)  # Tamanho em MB
            product.updated_at = datetime.datetime.utcnow()
            
            db.session.commit()
            
            return jsonify({
                'status': 'success',
                'message': 'Arquivo enviado com sucesso',
                'file_info': {
                    'name': filename,
                    'size': product.file_size,
                    'path': file_path
                }
            })
        
        return jsonify({
            'status': 'error',
            'message': 'Erro ao processar arquivo'
        }), 500
    
    except Exception as e:
        logger.error(f"Erro ao fazer upload para produto {product_id}: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': f"Erro ao fazer upload: {str(e)}"
        }), 500

# === Endpoints de Sessões ===

# Listar sessões
@api_bp.route('/sessions', methods=['GET'])
def get_sessions():
    try:
        # Parâmetros de filtro
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        status = request.args.get('status', '')
        
        # Construir query
        query = UploadSession.query
        
        if status:
            query = query.filter_by(status=status)
        
        # Ordenar
        query = query.order_by(desc(UploadSession.created_at))
        
        # Paginar
        sessions_page = query.paginate(page=page, per_page=per_page)
        
        # Formatar resultado
        result = {
            'status': 'success',
            'page': sessions_page.page,
            'per_page': sessions_page.per_page,
            'total': sessions_page.total,
            'total_pages': sessions_page.pages,
            'has_next': sessions_page.has_next,
            'has_prev': sessions_page.has_prev,
            'items': [s.to_dict() for s in sessions_page.items]
        }
        
        return jsonify(result)
    
    except Exception as e:
        logger.error(f"Erro ao listar sessões: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': f"Erro ao listar sessões: {str(e)}"
        }), 500

# Detalhes da sessão
@api_bp.route('/sessions/<int:session_id>', methods=['GET'])
def get_session(session_id):
    try:
        session = UploadSession.query.get_or_404(session_id)
        
        # Obter produtos associados
        products = []
        associations = SessionProduct.query.filter_by(session_id=session_id).all()
        
        for assoc in associations:
            product = Product.query.get(assoc.product_id)
            if product:
                product_data = product.to_dict()
                product_data['session_status'] = assoc.status
                products.append(product_data)
        
        return jsonify({
            'status': 'success',
            'session': session.to_dict(),
            'products': products
        })
    
    except Exception as e:
        logger.error(f"Erro ao obter sessão {session_id}: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': f"Erro ao obter sessão: {str(e)}"
        }), 500

# Criar sessão
@api_bp.route('/sessions', methods=['POST'])
def create_session():
    try:
        data = request.json
        
        # Validar dados obrigatórios
        if not data.get('product_ids') or not isinstance(data.get('product_ids'), list):
            return jsonify({
                'status': 'error',
                'message': 'Informe os IDs dos produtos para upload'
            }), 400
        
        # Configurações com valores padrão
        config = {
            'human_behavior': data.get('human_behavior', True),
            'use_proxy': data.get('use_proxy', False),
            'delay_min': data.get('delay_min', 1.0),
            'delay_max': data.get('delay_max', 3.0),
            'retry_on_fail': data.get('retry_on_fail', True),
            'max_retries': data.get('max_retries', 3),
            'use_adaptive_intelligence': data.get('use_adaptive_intelligence', True)
        }
        
        # Criar nova sessão
        session = UploadSession()
        session.session_id = str(datetime.datetime.utcnow().timestamp())
        session.status = 'active'
        session.total_products = len(data['product_ids'])
        session.config = config
        session.start_time = datetime.datetime.utcnow()
        
        db.session.add(session)
        db.session.flush()  # Para obter o ID
        
        # Associar produtos
        for product_id in data['product_ids']:
            # Verificar se produto existe
            product = Product.query.get(product_id)
            if not product:
                continue
                
            product_association = SessionProduct()
            product_association.session_id = session.id
            product_association.product_id = product_id
            product_association.status = 'pending'
            db.session.add(product_association)
        
        # Criar tarefa na fila
        task = TaskQueue()
        task.task_type = 'session_upload'
        task.priority = 10  # Alta prioridade
        task.status = 'pending'
        task.payload = {
            'session_id': session.id,
            'config': config
        }
        task.scheduled_for = datetime.datetime.utcnow()
        
        db.session.add(task)
        db.session.commit()
        
        return jsonify({
            'status': 'success',
            'message': 'Sessão criada com sucesso',
            'session': session.to_dict()
        }), 201
    
    except Exception as e:
        logger.error(f"Erro ao criar sessão: {str(e)}")
        db.session.rollback()
        return jsonify({
            'status': 'error',
            'message': f"Erro ao criar sessão: {str(e)}"
        }), 500

# Atualizar sessão
@api_bp.route('/sessions/<int:session_id>', methods=['PUT', 'PATCH'])
def update_session(session_id):
    try:
        session = UploadSession.query.get_or_404(session_id)
        data = request.json
        
        # Atualizar status
        if 'status' in data:
            valid_statuses = ['active', 'paused', 'completed', 'failed']
            if data['status'] in valid_statuses:
                session.status = data['status']
                
                # Se estiver completando ou falhando, definir end_time
                if data['status'] in ['completed', 'failed'] and not session.end_time:
                    session.end_time = datetime.datetime.utcnow()
            else:
                return jsonify({
                    'status': 'error',
                    'message': f"Status inválido. Valores permitidos: {', '.join(valid_statuses)}"
                }), 400
        
        # Atualizar contadores
        if 'successful_uploads' in data:
            session.successful_uploads = data['successful_uploads']
        
        if 'failed_uploads' in data:
            session.failed_uploads = data['failed_uploads']
        
        # Atualizar configurações
        if 'config' in data and isinstance(data['config'], dict):
            # Mesclar com configuração existente
            current_config = session.config or {}
            current_config.update(data['config'])
            session.config = current_config
        
        # Salvar mudanças
        db.session.commit()
        
        return jsonify({
            'status': 'success',
            'message': 'Sessão atualizada com sucesso',
            'session': session.to_dict()
        })
    
    except Exception as e:
        logger.error(f"Erro ao atualizar sessão {session_id}: {str(e)}")
        db.session.rollback()
        return jsonify({
            'status': 'error',
            'message': f"Erro ao atualizar sessão: {str(e)}"
        }), 500

# Cancelar sessão
@api_bp.route('/sessions/<int:session_id>/cancel', methods=['POST'])
def cancel_session(session_id):
    try:
        session = UploadSession.query.get_or_404(session_id)
        
        # Verificar se sessão pode ser cancelada
        if session.status not in ['active', 'paused']:
            return jsonify({
                'status': 'error',
                'message': 'Apenas sessões ativas ou pausadas podem ser canceladas'
            }), 400
        
        # Atualizar sessão
        session.status = 'failed'
        session.end_time = datetime.datetime.utcnow()
        
        # Atualizar produtos associados que ainda estão pendentes
        pending_products = SessionProduct.query.filter_by(session_id=session_id, status='pending').all()
        for product_assoc in pending_products:
            product_assoc.status = 'failed'
        
        # Atualizar tarefas relacionadas
        pending_tasks = TaskQueue.query.filter(
            TaskQueue.payload.contains({"session_id": session_id}),
            TaskQueue.status.in_(['pending', 'processing'])
        ).all()
        
        for task in pending_tasks:
            task.status = 'failed'
            task.error = 'Sessão cancelada pelo usuário'
        
        db.session.commit()
        
        return jsonify({
            'status': 'success',
            'message': 'Sessão cancelada com sucesso'
        })
    
    except Exception as e:
        logger.error(f"Erro ao cancelar sessão {session_id}: {str(e)}")
        db.session.rollback()
        return jsonify({
            'status': 'error',
            'message': f"Erro ao cancelar sessão: {str(e)}"
        }), 500

# === Endpoints de Configuração ===

# Obter configuração
@api_bp.route('/config/<string:config_name>', methods=['GET'])
def get_config(config_name):
    try:
        config = SystemConfig.query.filter_by(config_name=config_name).first()
        
        if not config:
            return jsonify({
                'status': 'error',
                'message': 'Configuração não encontrada'
            }), 404
        
        return jsonify({
            'status': 'success',
            'config': {
                'name': config.config_name,
                'value': config.config_value
            }
        })
    
    except Exception as e:
        logger.error(f"Erro ao obter configuração {config_name}: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': f"Erro ao obter configuração: {str(e)}"
        }), 500

# Atualizar configuração
@api_bp.route('/config/<string:config_name>', methods=['PUT'])
def update_config(config_name):
    try:
        data = request.json
        
        if 'value' not in data:
            return jsonify({
                'status': 'error',
                'message': 'Valor da configuração não fornecido'
            }), 400
        
        # Verificar se configuração existe
        config = SystemConfig.query.filter_by(config_name=config_name).first()
        
        if not config:
            # Criar nova configuração
            config = SystemConfig()
            config.config_name = config_name
        
        # Atualizar valor
        config.config_value = data['value']
        config.updated_at = datetime.datetime.utcnow()
        
        db.session.add(config)
        db.session.commit()
        
        return jsonify({
            'status': 'success',
            'message': 'Configuração atualizada com sucesso',
            'config': {
                'name': config.config_name,
                'value': config.config_value
            }
        })
    
    except Exception as e:
        logger.error(f"Erro ao atualizar configuração {config_name}: {str(e)}")
        db.session.rollback()
        return jsonify({
            'status': 'error',
            'message': f"Erro ao atualizar configuração: {str(e)}"
        }), 500

# === Endpoints para Elementos UI ===

# Listar elementos UI
@api_bp.route('/ui-elements', methods=['GET'])
def get_ui_elements():
    try:
        elements = UIElement.query.all()
        
        return jsonify({
            'status': 'success',
            'elements': [element.to_dict() for element in elements]
        })
    
    except Exception as e:
        logger.error(f"Erro ao listar elementos UI: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': f"Erro ao listar elementos UI: {str(e)}"
        }), 500

# Obter elemento UI específico
@api_bp.route('/ui-elements/<int:element_id>', methods=['GET'])
def get_ui_element(element_id):
    try:
        element = UIElement.query.get_or_404(element_id)
        
        return jsonify({
            'status': 'success',
            'element': element.to_dict()
        })
    
    except Exception as e:
        logger.error(f"Erro ao obter elemento UI {element_id}: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': f"Erro ao obter elemento UI: {str(e)}"
        }), 500

# Criar elemento UI
@api_bp.route('/ui-elements', methods=['POST'])
def create_ui_element():
    try:
        data = request.json
        
        # Validar dados obrigatórios
        required_fields = ['element_name', 'page_url_pattern', 'selector_strategy']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'status': 'error',
                    'message': f"Campo obrigatório: {field}"
                }), 400
        
        # Criar novo elemento
        element = UIElement()
        element.element_name = data['element_name']
        element.description = data.get('description')
        element.page_url_pattern = data['page_url_pattern']
        element.selector_strategy = data['selector_strategy']
        element.created_at = datetime.datetime.utcnow()
        
        db.session.add(element)
        db.session.commit()
        
        return jsonify({
            'status': 'success',
            'message': 'Elemento UI criado com sucesso',
            'element': element.to_dict()
        }), 201
    
    except Exception as e:
        logger.error(f"Erro ao criar elemento UI: {str(e)}")
        db.session.rollback()
        return jsonify({
            'status': 'error',
            'message': f"Erro ao criar elemento UI: {str(e)}"
        }), 500

# Atualizar elemento UI
@api_bp.route('/ui-elements/<int:element_id>', methods=['PUT'])
def update_ui_element(element_id):
    try:
        element = UIElement.query.get_or_404(element_id)
        data = request.json
        
        # Atualizar campos
        if 'element_name' in data:
            element.element_name = data['element_name']
        
        if 'description' in data:
            element.description = data['description']
        
        if 'page_url_pattern' in data:
            element.page_url_pattern = data['page_url_pattern']
        
        if 'selector_strategy' in data:
            element.selector_strategy = data['selector_strategy']
        
        if 'success_count' in data:
            element.success_count = data['success_count']
        
        if 'failure_count' in data:
            element.failure_count = data['failure_count']
        
        # Atualizar timestamp
        element.updated_at = datetime.datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'status': 'success',
            'message': 'Elemento UI atualizado com sucesso',
            'element': element.to_dict()
        })
    
    except Exception as e:
        logger.error(f"Erro ao atualizar elemento UI {element_id}: {str(e)}")
        db.session.rollback()
        return jsonify({
            'status': 'error',
            'message': f"Erro ao atualizar elemento UI: {str(e)}"
        }), 500

# === Endpoints para Logs ===

# Obter logs
@api_bp.route('/logs', methods=['GET'])
def get_logs():
    try:
        # Ler arquivo de log
        log_content = ""
        try:
            log_file = 'logs/app.log'
            if os.path.exists(log_file):
                with open(log_file, 'r') as f:
                    log_content = f.read()
        except Exception as e:
            return jsonify({
                'status': 'error',
                'message': f"Erro ao ler logs: {str(e)}"
            }), 500
        
        return jsonify({
            'status': 'success',
            'log_content': log_content
        })
    
    except Exception as e:
        logger.error(f"Erro ao obter logs: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': f"Erro ao obter logs: {str(e)}"
        }), 500

# Limpar logs
@api_bp.route('/logs/clear', methods=['POST'])
def clear_logs():
    try:
        log_file = 'logs/app.log'
        
        # Limpar arquivo de log
        with open(log_file, 'w') as f:
            f.write(f"Logs limpos em {datetime.datetime.now()}\n")
        
        return jsonify({
            'status': 'success',
            'message': 'Logs limpos com sucesso'
        })
    
    except Exception as e:
        logger.error(f"Erro ao limpar logs: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': f"Erro ao limpar logs: {str(e)}"
        }), 500

# === Endpoints para Estatísticas de Detecção ===

# Obter estatísticas de detecção
@api_bp.route('/detection/stats', methods=['GET'])
def get_detection_stats():
    try:
        # Obter estatísticas de detecção do sistema
        stats_config = SystemConfig.query.filter_by(config_name='detection_stats').first()
        
        if not stats_config or not stats_config.config_value:
            # Criar estatísticas iniciais se não existirem
            stats = {
                'risk_level': 0.0,
                'captcha_count': 0,
                'evasion_mode': 'normal',
                'unusual_redirects': 0,
                'js_challenges': 0,
                'recommendations': []
            }
        else:
            stats = stats_config.config_value
        
        return jsonify({
            'status': 'success',
            **stats
        })
    
    except Exception as e:
        logger.error(f"Erro ao obter estatísticas de detecção: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': f"Erro ao obter estatísticas de detecção: {str(e)}"
        }), 500

# Atualizar estatísticas de detecção
@api_bp.route('/detection/stats', methods=['PUT'])
def update_detection_stats():
    try:
        data = request.json
        
        # Obter configuração atual
        stats_config = SystemConfig.query.filter_by(config_name='detection_stats').first()
        
        if not stats_config:
            stats_config = SystemConfig(config_name='detection_stats')
        
        # Atualizar valores
        stats_config.config_value = data
        stats_config.updated_at = datetime.datetime.utcnow()
        
        db.session.add(stats_config)
        db.session.commit()
        
        return jsonify({
            'status': 'success',
            'message': 'Estatísticas de detecção atualizadas com sucesso'
        })
    
    except Exception as e:
        logger.error(f"Erro ao atualizar estatísticas de detecção: {str(e)}")
        db.session.rollback()
        return jsonify({
            'status': 'error',
            'message': f"Erro ao atualizar estatísticas de detecção: {str(e)}"
        }), 500

# === Endpoints para Status da IA ===

# Obter status da IA adaptativa
@api_bp.route('/ai/status', methods=['GET'])
def get_ai_status():
    try:
        # Verificar configuração da API OpenAI
        openai_config = SystemConfig.query.filter_by(config_name='openai_api').first()
        
        ai_enabled = False
        api_available = False
        
        if openai_config and openai_config.config_value:
            ai_enabled = openai_config.config_value.get('enabled', False)
            api_available = bool(openai_config.config_value.get('api_key'))
        
        # Obter estatísticas de uso da IA
        ai_stats = SystemConfig.query.filter_by(config_name='ai_stats').first()
        
        stats = {
            'learned_elements': 0,
            'fixes_applied': 0,
            'last_analysis': None
        }
        
        if ai_stats and ai_stats.config_value:
            stats.update(ai_stats.config_value)
        
        return jsonify({
            'status': 'success',
            'ai_enabled': ai_enabled,
            'api_available': api_available,
            **stats
        })
    
    except Exception as e:
        logger.error(f"Erro ao obter status da IA: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': f"Erro ao obter status da IA: {str(e)}"
        }), 500