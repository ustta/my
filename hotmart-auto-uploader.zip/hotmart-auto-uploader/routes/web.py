from datetime import datetime
from flask import render_template, redirect, url_for, flash, request, jsonify, send_from_directory
from sqlalchemy import desc
from werkzeug.utils import secure_filename
import os
import logging

from app import app
from models import User, Product, UploadSession, SessionProduct, SystemConfig

# Configurar logging
logger = logging.getLogger(__name__)

@app.route('/')
def dashboard():
    """Página principal do dashboard"""
    try:
        # Estatísticas gerais
        products_count = Product.query.count()
        uploaded_count = Product.query.filter_by(status="uploaded").count()
        pending_count = Product.query.filter_by(status="pending").count()
        failed_count = Product.query.filter_by(status="failed").count()
        
        # Sessões ativas
        active_sessions = UploadSession.query.filter_by(status="active").all()
        
        # Sessões recentes
        recent_sessions = UploadSession.query.order_by(desc(UploadSession.created_at)).limit(5).all()
        
        # Status do sistema
        system_config = SystemConfig.query.filter_by(config_name="system_status").first()
        system_stats = system_config.config_value if system_config else {}
        
        # Verificar se a API OpenAI está configurada
        openai_config = SystemConfig.query.filter_by(config_name="openai_settings").first()
        openai_enabled = False
        if openai_config and openai_config.config_value:
            openai_api_key = openai_config.config_value.get('api_key')
            openai_enabled = bool(openai_api_key)
        
        return render_template('index.html', 
                               products_count=products_count,
                               uploaded_count=uploaded_count,
                               pending_count=pending_count,
                               failed_count=failed_count,
                               active_sessions=active_sessions,
                               recent_sessions=recent_sessions,
                               system_stats=system_stats,
                               openai_enabled=openai_enabled)
    except Exception as e:
        logger.error(f"Erro ao carregar dashboard: {str(e)}")
        flash(f"Erro ao carregar dashboard: {str(e)}", "danger")
        return render_template('index.html', 
                              products_count=0,
                              uploaded_count=0,
                              pending_count=0,
                              failed_count=0,
                              active_sessions=[],
                              recent_sessions=[],
                              system_stats={},
                              openai_enabled=False)

@app.route('/produtos')
def products():
    """Lista de produtos"""
    try:
        products = Product.query.order_by(desc(Product.created_at)).all()
        return render_template('produtos.html', products=products)
    except Exception as e:
        logger.error(f"Erro ao listar produtos: {str(e)}")
        flash(f"Erro ao listar produtos: {str(e)}", "danger")
        return render_template('produtos.html', products=[])

@app.route('/produto/novo', methods=['GET', 'POST'])
def new_product():
    """Formulário para novo produto"""
    if request.method == 'POST':
        try:
            # Processar formulário
            product = Product(
                title=request.form.get('title'),
                description=request.form.get('description'),
                price=float(request.form.get('price', 97.0)),
                category=request.form.get('category'),
                format_type=request.form.get('format_type'),
                language=request.form.get('language')
            )
            
            # Arquivo do produto
            if 'product_file' in request.files:
                file = request.files['product_file']
                if file and file.filename:
                    filename = secure_filename(file.filename)
                    uploads_dir = os.path.join(app.root_path, 'uploads')
                    if not os.path.exists(uploads_dir):
                        os.makedirs(uploads_dir)
                    
                    file_path = os.path.join(uploads_dir, filename)
                    file.save(file_path)
                    
                    product.file_path = file_path
                    product.file_name = filename
                    product.file_size = os.path.getsize(file_path) / (1024 * 1024)  # Tamanho em MB
            
            app.config['db'].session.add(product)
            app.config['db'].session.commit()
            
            flash("Produto adicionado com sucesso!", "success")
            return redirect(url_for('products'))
        
        except Exception as e:
            logger.error(f"Erro ao adicionar produto: {str(e)}")
            flash(f"Erro ao adicionar produto: {str(e)}", "danger")
            return render_template('product_form.html')
    
    return render_template('product_form.html')

@app.route('/produto/<int:product_id>/editar', methods=['GET', 'POST'])
def edit_product(product_id):
    """Edição de produto existente"""
    product = Product.query.get_or_404(product_id)
    
    if request.method == 'POST':
        try:
            # Atualizar dados do produto
            product.title = request.form.get('title', product.title)
            product.description = request.form.get('description', product.description)
            product.price = float(request.form.get('price', product.price))
            product.category = request.form.get('category', product.category)
            product.format_type = request.form.get('format_type', product.format_type)
            product.language = request.form.get('language', product.language)
            
            # Arquivo do produto (se foi atualizado)
            if 'product_file' in request.files:
                file = request.files['product_file']
                if file and file.filename:
                    filename = secure_filename(file.filename)
                    uploads_dir = os.path.join(app.root_path, 'uploads')
                    if not os.path.exists(uploads_dir):
                        os.makedirs(uploads_dir)
                    
                    # Remover arquivo antigo se existir
                    if product.file_path and os.path.exists(product.file_path):
                        os.remove(product.file_path)
                    
                    file_path = os.path.join(uploads_dir, filename)
                    file.save(file_path)
                    
                    product.file_path = file_path
                    product.file_name = filename
                    product.file_size = os.path.getsize(file_path) / (1024 * 1024)  # Tamanho em MB
            
            app.config['db'].session.commit()
            
            flash("Produto atualizado com sucesso!", "success")
            return redirect(url_for('products'))
        
        except Exception as e:
            logger.error(f"Erro ao atualizar produto: {str(e)}")
            flash(f"Erro ao atualizar produto: {str(e)}", "danger")
    
    return render_template('product_form.html', product=product)

@app.route('/sessao/nova', methods=['GET', 'POST'])
def new_session():
    """Criação de nova sessão de upload"""
    if request.method == 'POST':
        try:
            # Criar nova sessão
            session = UploadSession(
                status="active",
                total_products=0,
                successful_uploads=0,
                failed_uploads=0
            )
            
            # Configurações da sessão
            session.config = {
                'stealth_mode': request.form.get('stealth_mode', 'normal'),
                'retry_on_error': request.form.get('retry_on_error') == 'on',
                'max_retries': int(request.form.get('max_retries', 3)),
                'delay_between_uploads': int(request.form.get('delay_between_uploads', 60)),
                'human_simulation_level': request.form.get('human_simulation_level', 'medium')
            }
            
            app.config['db'].session.add(session)
            app.config['db'].session.flush()
            
            # Associar produtos à sessão
            product_ids = request.form.getlist('products')
            for product_id in product_ids:
                product_assoc = SessionProduct(
                    session_id=session.id,
                    product_id=int(product_id),
                    status="pending"
                )
                app.config['db'].session.add(product_assoc)
                session.total_products += 1
            
            app.config['db'].session.commit()
            
            flash("Sessão de upload criada com sucesso!", "success")
            return redirect(url_for('session_detail', session_id=session.id))
        
        except Exception as e:
            logger.error(f"Erro ao criar sessão: {str(e)}")
            flash(f"Erro ao criar sessão: {str(e)}", "danger")
    
    # Obter produtos pendentes para listar no form
    products = Product.query.filter_by(status="pending").all()
    return render_template('session_form.html', products=products)

@app.route('/sessoes')
def sessions():
    """Lista de sessões de upload"""
    try:
        sessions = UploadSession.query.order_by(desc(UploadSession.created_at)).all()
        return render_template('sessions.html', sessions=sessions)
    except Exception as e:
        logger.error(f"Erro ao listar sessões: {str(e)}")
        flash(f"Erro ao listar sessões: {str(e)}", "danger")
        return render_template('sessions.html', sessions=[])

@app.route('/sessao/<int:session_id>')
def session_detail(session_id):
    """Detalhes de uma sessão específica"""
    try:
        session = UploadSession.query.get_or_404(session_id)
        # Obter produtos associados
        products = SessionProduct.query.filter_by(session_id=session.id).all()
        return render_template('session_detail.html', session=session, products=products)
    except Exception as e:
        logger.error(f"Erro ao mostrar detalhes da sessão: {str(e)}")
        flash(f"Erro ao carregar sessão: {str(e)}", "danger")
        return redirect(url_for('sessions'))

@app.route('/logs')
def logs():
    """Visualização de logs do sistema"""
    try:
        # Ler arquivo de logs mais recente
        logs_dir = os.path.join(app.root_path, 'logs')
        if not os.path.exists(logs_dir):
            os.makedirs(logs_dir)
            
        log_files = [f for f in os.listdir(logs_dir) if f.endswith('.log')]
        log_files.sort(reverse=True)  # Organizar por mais recente
        
        log_content = ""
        if log_files:
            latest_log = os.path.join(logs_dir, log_files[0])
            with open(latest_log, 'r') as f:
                # Ler as últimas 1000 linhas para não sobrecarregar a página
                log_content = ''.join(f.readlines()[-1000:])
        
        return render_template('logs.html', logs=log_content, log_files=log_files)
    except Exception as e:
        logger.error(f"Erro ao visualizar logs: {str(e)}")
        flash(f"Erro ao visualizar logs: {str(e)}", "danger")
        return render_template('logs.html', logs="Erro ao carregar logs.", log_files=[])

@app.route('/configuracoes', methods=['GET', 'POST'])
def settings():
    """Configurações do sistema"""
    if request.method == 'POST':
        try:
            # Obter configuração atual
            system_config = SystemConfig.query.filter_by(config_name="system_settings").first()
            if not system_config:
                system_config = SystemConfig(config_name="system_settings")
            
            # Atualizar configurações
            system_config.config_value = {
                'default_stealth_mode': request.form.get('default_stealth_mode', 'normal'),
                'detection_alert_threshold': int(request.form.get('detection_alert_threshold', 70)),
                'enable_adaptive_intelligence': request.form.get('enable_adaptive_intelligence') == 'on',
                'auto_retry_failed': request.form.get('auto_retry_failed') == 'on',
                'max_concurrent_sessions': int(request.form.get('max_concurrent_sessions', 1))
            }
            
            app.config['db'].session.add(system_config)
            app.config['db'].session.commit()
            
            # Atualizar configuração OpenAI se fornecida
            openai_api_key = request.form.get('openai_api_key')
            if openai_api_key:
                openai_config = SystemConfig.query.filter_by(config_name="openai_settings").first()
                if not openai_config:
                    openai_config = SystemConfig(config_name="openai_settings")
                
                openai_config.config_value = {
                    'api_key': openai_api_key,
                    'model': request.form.get('openai_model', 'gpt-4'),
                    'temperature': float(request.form.get('openai_temperature', 0.7))
                }
                
                app.config['db'].session.add(openai_config)
                app.config['db'].session.commit()
            
            flash("Configurações atualizadas com sucesso!", "success")
            return redirect(url_for('settings'))
        
        except Exception as e:
            logger.error(f"Erro ao salvar configurações: {str(e)}")
            flash(f"Erro ao salvar configurações: {str(e)}", "danger")
    
    # Obter configurações atuais
    system_config = SystemConfig.query.filter_by(config_name="system_settings").first()
    openai_config = SystemConfig.query.filter_by(config_name="openai_settings").first()
    
    settings = system_config.config_value if system_config else {}
    openai_settings = openai_config.config_value if openai_config else {}
    
    return render_template('settings.html', settings=settings, openai_settings=openai_settings)

@app.route('/download/<path:filename>')
def download_file(filename):
    """Download de arquivos"""
    uploads_dir = os.path.join(app.root_path, 'uploads')
    return send_from_directory(directory=uploads_dir, path=filename, as_attachment=True)